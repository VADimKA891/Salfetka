<?php
require_once 'config.php';
require_once 'db_functions.php';
require_once 'ldap_auth.php';

// Определяем LDAP-константы из .env
if (!defined('LDAP_ENABLED')) {
    define('LDAP_ENABLED', getenv('LDAP_ENABLED') === 'true');
    define('LDAP_HOST', getenv('LDAP_HOST') ?: 'ldap://your-ldap.kuzstu.ru');
    define('LDAP_PORT', getenv('LDAP_PORT') ?: 389);
    define('LDAP_BASE_DN', getenv('LDAP_BASE_DN') ?: 'dc=kuzstu,dc=ru');
    define('LDAP_USER_ATTR', getenv('LDAP_USER_ATTR') ?: 'sAMAccountName');
    define('LDAP_GROUP_TEACHER', getenv('LDAP_GROUP_TEACHER') ?: 'CN=Teachers,OU=Groups,DC=kuzstu,DC=ru');
    define('LDAP_GROUP_ADMIN', getenv('LDAP_GROUP_ADMIN') ?: 'CN=Admins,OU=Groups,DC=kuzstu,DC=ru');
}

if (isAuthenticated()) {
    header('Location: index.php');
    exit;
}

$error = '';

function generateCaptchaCode($len = 6) {
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $code = '';
    for ($i = 0; $i < $len; $i++) {
        $code .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $code;
}

if (!isset($_SESSION['captcha_code'])) {
    $_SESSION['captcha_code'] = generateCaptchaCode();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $captcha = trim($_POST['captcha'] ?? '');
    $ip = $_SERVER['REMOTE_ADDR'];

    if ($username && $password && $captcha) {
        if (strtoupper($captcha) !== strtoupper($_SESSION['captcha_code'])) {
            $error = 'Неверный код с картинки';
            $_SESSION['captcha_code'] = generateCaptchaCode();
        } else {
            try {
                $db = getDB(); // используем PDO из config.php
                if (isIpBlocked($ip)) {
                    $error = 'Ваш IP-адрес заблокирован. Обратитесь к администратору.';
                    logEvent("Попытка входа с заблокированного IP $ip", "WARNING", "auth");
                } else {
                    $ldap_user = null;
                    if (LDAP_ENABLED) {
                        $ldap_user = authenticate_ldap($username, $password);
                    }
                    if ($ldap_user) {
                        $user = getUserByLogin($username);
                        if (!$user) {
                            $role_id = ($ldap_user['role'] == 'admin') ? ROLE_ADMIN : (($ldap_user['role'] == 'teacher') ? ROLE_TEACHER : ROLE_STUDENT);
                            addUser($username, '', $role_id, $ldap_user['dn']);
                            $user = getUserByLogin($username);
                        } else {
                            $new_role = ($ldap_user['role'] == 'admin') ? ROLE_ADMIN : (($ldap_user['role'] == 'teacher') ? ROLE_TEACHER : ROLE_STUDENT);
                            if ($user['role_id'] != $new_role) {
                                $db = getDB();
                                $stmt = $db->prepare("UPDATE users SET role_id = ?, ldap_dn = ? WHERE id = ?");
                                $stmt->execute([$new_role, $ldap_user['dn'], $user['id']]);
                                $user['role_id'] = $new_role;
                            }
                        }
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $username;
                        $_SESSION['role_id'] = $user['role_id'];
                        $_SESSION['last_activity'] = time();
                        updateUserLastActivity($user['id']);
                        logEventToDB($user['id'], 'login', "Успешный вход через LDAP", $ip);
                        header('Location: index.php');
                        exit;
                    } else {
                        // Локальная аутентификация
                        $user = getUserByLogin($username);
                        if ($user && password_verify($password, $user['password_hash'])) {
                            $_SESSION['user_id'] = $user['id'];
                            $_SESSION['username'] = $username;
                            $_SESSION['role_id'] = $user['role_id'];
                            $_SESSION['last_activity'] = time();
                            updateUserLastActivity($user['id']);
                            logEventToDB($user['id'], 'login', "Успешный локальный вход", $ip);
                            header('Location: index.php');
                            exit;
                        }
                    }
                    $error = 'Неверный логин или пароль';
                    logEventToDB(null, 'auth_failed', "Неудачная попытка входа для $username с IP $ip", $ip);
                }
            } catch (Exception $e) {
                $error = 'Ошибка системы. Попробуйте позже.';
                logEvent("Ошибка входа: " . $e->getMessage(), "ERROR", "auth");
            }
            $_SESSION['captcha_code'] = generateCaptchaCode();
        }
    } else {
        $error = 'Заполните все поля';
        $_SESSION['captcha_code'] = generateCaptchaCode();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Вход | КузГТУ</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg, #0033A0 0%, #001F66 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-card {
            background: white;
            border-radius: 32px;
            width: 420px;
            max-width: 100%;
            padding: 40px 35px;
            box-shadow: 0 25px 45px rgba(0,0,0,0.2);
            text-align: center;
        }
        .logo img { height: 60px; margin-bottom: 20px; }
        h2 { color: #0033A0; margin-bottom: 8px; font-weight: 500; }
        .sub { color: #6B7280; margin-bottom: 30px; font-size: 0.85rem; }
        .error { background: #FEE2E2; color: #B91C1C; padding: 12px; border-radius: 16px; margin-bottom: 20px; font-size: 0.85rem; }
        input { width: 100%; padding: 14px 18px; margin: 10px 0; border: 1px solid #D1D9E6; border-radius: 40px; font-size: 1rem; transition: 0.2s; }
        input:focus { outline: none; border-color: #0033A0; box-shadow: 0 0 0 3px rgba(0,51,160,0.1); }
        .captcha-row { display: flex; gap: 10px; align-items: center; margin: 15px 0; }
        .captcha-box {
            background: #F0F4FA;
            font-family: monospace;
            font-size: 28px;
            letter-spacing: 8px;
            padding: 10px;
            border-radius: 20px;
            text-align: center;
            flex: 1;
            cursor: pointer;
            font-weight: bold;
            color: #0033A0;
        }
        .btn-icon {
            background: #EFF3F8;
            border: none;
            border-radius: 40px;
            padding: 8px 14px;
            cursor: pointer;
            font-size: 1.2rem;
            transition: 0.2s;
        }
        .btn-icon:hover { background: #E2E8F0; }
        button[type="submit"] {
            background: #0033A0;
            color: white;
            font-weight: 600;
            border: none;
            width: 100%;
            padding: 14px;
            border-radius: 40px;
            font-size: 1rem;
            margin-top: 15px;
            cursor: pointer;
            transition: 0.2s;
        }
        button[type="submit"]:hover { background: #002277; }
        .footer { margin-top: 25px; font-size: 0.7rem; color: #9CA3AF; }
    </style>
</head>
<body>
<div class="login-card">
    <div class="logo">
        <img src="https://kuzstu.ru/local/templates/kuzstu/images/logo.svg" alt="КузГТУ" onerror="this.src='https://via.placeholder.com/60?text=KuzGTU'">
    </div>
    <h2>Вход в систему</h2>
    <div class="sub">Кузбасский государственный технический университет</div>
    
    <?php if ($error): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
    
    <form method="post">
        <input type="text" name="username" placeholder="Логин (доменный)" autofocus required>
        <input type="password" name="password" placeholder="Пароль" required>
        <div class="captcha-row">
            <div class="captcha-box" onclick="refreshCaptcha()" id="captchaText"><?= $_SESSION['captcha_code'] ?></div>
            <button type="button" class="btn-icon" onclick="refreshCaptcha()" title="Обновить">⟳</button>
            <button type="button" class="btn-icon" onclick="speakCaptcha()" title="Озвучить">🔊</button>
        </div>
        <input type="text" name="captcha" placeholder="Введите код с картинки" required>
        <button type="submit">Войти</button>
    </form>
    <div class="footer">© КузГТУ, <?= date('Y') ?></div>
</div>
<script>
function refreshCaptcha() {
    fetch('request_handler.php?action=refresh_captcha')
        .then(r => r.json())
        .then(data => document.getElementById('captchaText').innerText = data.code)
        .catch(() => location.reload());
}
function speakCaptcha() {
    let code = document.getElementById('captchaText').innerText;
    if (code && window.speechSynthesis) {
        let utterance = new SpeechSynthesisUtterance(code.split('').join(' '));
        utterance.lang = 'ru-RU';
        utterance.rate = 0.8;
        window.speechSynthesis.speak(utterance);
    }
}
</script>
</body>
</html>