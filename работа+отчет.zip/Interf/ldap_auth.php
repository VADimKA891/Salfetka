<?php
function authenticate_ldap($username, $password) {
    if (!LDAP_ENABLED) return false;
    
    // Формируем URI: ldap://хост:порт
    $ldapUri = LDAP_HOST . ':' . LDAP_PORT;
    $ldapconn = ldap_connect($ldapUri);
    if (!$ldapconn) return false;
    
    ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($ldapconn, LDAP_OPT_REFERRALS, 0);
    
    $dn = LDAP_USER_ATTR . "=" . ldap_escape($username, "", LDAP_ESCAPE_DN) . "," . LDAP_BASE_DN;
    $bind = @ldap_bind($ldapconn, $dn, $password);
    if (!$bind) {
        ldap_close($ldapconn);
        return false;
    }
    
    $search = ldap_search($ldapconn, LDAP_BASE_DN, "(" . LDAP_USER_ATTR . "=" . ldap_escape($username) . ")", ['memberOf']);
    $entries = ldap_get_entries($ldapconn, $search);
    $role = 'student';
    if ($entries['count'] > 0 && isset($entries[0]['memberof'])) {
        $groups = $entries[0]['memberof'];
        foreach ($groups as $group) {
            if (strpos($group, LDAP_GROUP_ADMIN) !== false) { $role = 'admin'; break; }
            if (strpos($group, LDAP_GROUP_TEACHER) !== false) $role = 'teacher';
        }
    }
    ldap_close($ldapconn);
    return ['username' => $username, 'role' => $role, 'dn' => $dn];
}
?>