<?php
require_once 'config.php';
require_once 'db_functions.php';
if (!isAuthenticated()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$db = getDB();

// События за последние 7 дней по дням
$stmt = $db->query("SELECT DATE(start_time) as date, COUNT(*) as count FROM activity_log WHERE start_time >= NOW() - INTERVAL 7 DAY GROUP BY DATE(start_time)");
$daily = $stmt->fetchAll();

// События за 24 часа
$stmt = $db->query("SELECT COUNT(*) FROM activity_log WHERE start_time >= NOW() - INTERVAL 1 DAY");
$eventsLastDay = $stmt->fetchColumn();

// Заблокированные IP
$stmt = $db->query("SELECT COUNT(*) FROM blacklist_ips");
$blockedCount = $stmt->fetchColumn();

// Топ-5 приложений за 7 дней
$stmt = $db->query("SELECT app_name, COUNT(*) as cnt FROM activity_log WHERE start_time >= NOW() - INTERVAL 7 DAY GROUP BY app_name ORDER BY cnt DESC LIMIT 5");
$topApps = $stmt->fetchAll();

// Системные ресурсы (CPU, RAM, Disk)
$isWindows = strtoupper(substr(PHP_OS, 0, 3)) === 'WIN';
$load = [0,0,0];
if ($isWindows) {
    $cpuRaw = shell_exec('wmic cpu get loadpercentage /value');
    if ($cpuRaw && preg_match('/LoadPercentage=(\d+)/', $cpuRaw, $m)) $load = [($m[1]/100), ($m[1]/100), ($m[1]/100)];
} else {
    if (function_exists('sys_getloadavg')) $load = sys_getloadavg();
}
$memory = ['total' => 'N/A', 'used' => 0, 'free' => 0, 'percent' => 0];
if ($isWindows) {
    $memRaw = shell_exec('wmic OS get TotalVisibleMemorySize,FreePhysicalMemory /value');
    if ($memRaw && preg_match('/TotalVisibleMemorySize=(\d+)/', $memRaw, $t) && preg_match('/FreePhysicalMemory=(\d+)/', $memRaw, $f)) {
        $total_kb = (int)$t[1]; $free_kb = (int)$f[1]; $used_kb = $total_kb - $free_kb;
        $memory = ['total' => round($total_kb/1024,1), 'used' => round($used_kb/1024,1), 'free' => round($free_kb/1024,1), 'percent' => round(($used_kb/$total_kb)*100,1)];
    }
} else {
    if (file_exists('/proc/meminfo')) {
        $meminfo = file_get_contents('/proc/meminfo');
        preg_match('/MemTotal:\s+(\d+)/', $meminfo, $t);
        preg_match('/MemAvailable:\s+(\d+)/', $meminfo, $a);
        if (isset($t[1], $a[1])) {
            $total_kb = (int)$t[1]; $avail_kb = (int)$a[1]; $used_kb = $total_kb - $avail_kb;
            $memory = ['total' => round($total_kb/1024,1), 'used' => round($used_kb/1024,1), 'free' => round($avail_kb/1024,1), 'percent' => round(($used_kb/$total_kb)*100,1)];
        }
    }
}
$disk_total = disk_total_space('/');
$disk_free = disk_free_space('/');
$disk_used = $disk_total - $disk_free;
$disk_percent = $disk_total > 0 ? round(($disk_used / $disk_total) * 100, 1) : 0;

header('Content-Type: application/json');
echo json_encode([
    'daily' => $daily,
    'eventsLastDay' => (int)$eventsLastDay,
    'blockedCount' => (int)$blockedCount,
    'topApps' => $topApps,
    'load' => array_map(fn($v)=>round($v,2), $load),
    'memory' => $memory,
    'disk' => ['total' => round($disk_total/1024/1024/1024,2), 'used' => round($disk_used/1024/1024/1024,2), 'free' => round($disk_free/1024/1024/1024,2), 'percent' => $disk_percent]
]);
?>