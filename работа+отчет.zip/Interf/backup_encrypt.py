import os
import subprocess
import datetime
from dotenv import load_dotenv
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

load_dotenv()
BACKUP_DIR = "C:/backups"
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY', '0123456789abcdef0123456789abcdef').encode()
DB_CONFIG = {
    'host': os.getenv('DB_HOST'),
    'port': int(os.getenv('DB_PORT')),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME')
}

def backup_database():
    timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    dump_file = os.path.join(BACKUP_DIR, f'db_dump_{timestamp}.sql')
    cmd = f'mysqldump -h {DB_CONFIG["host"]} -P {DB_CONFIG["port"]} -u {DB_CONFIG["user"]} -p{DB_CONFIG["password"]} {DB_CONFIG["database"]} > "{dump_file}"'
    subprocess.run(cmd, shell=True)
    return dump_file

def encrypt_file(file_path):
    iv = os.urandom(16)
    cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CFB(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    with open(file_path, 'rb') as f:
        plaintext = f.read()
    ciphertext = encryptor.update(plaintext) + encryptor.finalize()
    encrypted_path = file_path + '.enc'
    with open(encrypted_path, 'wb') as f:
        f.write(iv + ciphertext)
    os.remove(file_path)
    return encrypted_path

def main():
    os.makedirs(BACKUP_DIR, exist_ok=True)
    db_file = backup_database()
    enc_db = encrypt_file(db_file)
    print(f"Backup encrypted: {enc_db}")

if __name__ == "__main__":
    main()