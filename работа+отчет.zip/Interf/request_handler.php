<?php
require_once 'config.php';
require_once 'db_functions.php';

$action = $_POST['action'] ?? $_GET['action'] ?? '';

// CSV-экспорт не требует JSON-заголовка, остальное — да
if (!in_array($action, ['export_csv', 'export_blacklist_csv'])) {
    header('Content-Type: application/json; charset=utf-8');
}

$db = getDB();

switch ($action) {

    // ── Обновление капчи ─────────────────────────────────────────────────
    case 'refresh_captcha':
        $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        $code  = '';
        for ($i = 0; $i < 6; $i++) $code .= $chars[random_int(0, strlen($chars) - 1)];
        $_SESSION['captcha_code'] = $code;
        echo json_encode(['code' => $code]);
        break;

    // ── Разблокировка IP ──────────────────────────────────────────────────
    case 'unblock_ip':
        if (!isAuthenticated() || $_SESSION['role_id'] != ROLE_ADMIN) {
            echo json_encode(['success' => false, 'message' => 'Нет прав']); break;
        }
        $ip = trim($_POST['ip'] ?? '');
        if (!$ip) { echo json_encode(['success' => false, 'message' => 'IP не указан']); break; }
        // Валидация формата IP
        if (!filter_var($ip, FILTER_VALIDATE_IP)) {
            echo json_encode(['success' => false, 'message' => 'Некорректный формат IP']); break;
        }
        $stmt = $db->prepare("DELETE FROM blacklist_ips WHERE ip_address = ?");
        $stmt->execute([$ip]);
        logEvent("IP $ip разблокирован администратором {$_SESSION['username']}", "INFO", "security");
        logEventToDB((int)$_SESSION['user_id'], 'ip_unblocked', "Разблокирован IP $ip");
        echo json_encode(['success' => true, 'message' => "IP $ip разблокирован"]);
        break;

    // ── Список чёрного списка ─────────────────────────────────────────────
    case 'list_blacklist':
        if (!isAuthenticated() || $_SESSION['role_id'] != ROLE_ADMIN) {
            echo json_encode([]); break;
        }
        $stmt = $db->query("SELECT ip_address, source, created_at FROM blacklist_ips ORDER BY created_at DESC");
        echo json_encode($stmt->fetchAll());
        break;

    // ── Активные сессии (счётчик) ─────────────────────────────────────────
    case 'active_sessions':
        if (!isAuthenticated()) { echo json_encode(['count' => 0]); break; }
        $sessions = getActiveSessions(10);
        echo json_encode(['count' => count($sessions), 'users' => $sessions]);
        break;

    // ── Экспорт activity_log в CSV ────────────────────────────────────────
    case 'export_csv':
        if (!isAuthenticated()) { http_response_code(403); exit; }
        $stmt = $db->query(
            "SELECT a.start_time, a.device_name, u.username, a.event_type,
                    a.app_name, a.window_title, a.url, a.duration
             FROM activity_log a LEFT JOIN users u ON a.user_id = u.id
             ORDER BY a.start_time DESC LIMIT 20000"
        );
        $rows     = $stmt->fetchAll();
        $filename = "activity_" . date('Y-m-d_His') . ".csv";
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache');
        // BOM для корректного отображения в Excel
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        if (!empty($rows)) {
            fputcsv($out, array_keys($rows[0]), ';');
            foreach ($rows as $row) fputcsv($out, $row, ';');
        }
        fclose($out);
        logEventToDB((int)$_SESSION['user_id'], 'export_csv', 'Экспорт activity_log в CSV');
        exit;

    // ── Экспорт blacklist_ips в CSV ───────────────────────────────────────
    case 'export_blacklist_csv':
        if (!isAuthenticated() || $_SESSION['role_id'] != ROLE_ADMIN) {
            http_response_code(403); exit;
        }
        $stmt     = $db->query("SELECT ip_address, source, created_at FROM blacklist_ips ORDER BY created_at DESC");
        $rows     = $stmt->fetchAll();
        $filename = "blacklist_" . date('Y-m-d_His') . ".csv";
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo "\xEF\xBB\xBF";
        $out = fopen('php://output', 'w');
        fputcsv($out, ['IP-адрес', 'Источник', 'Дата добавления'], ';');
        foreach ($rows as $row) fputcsv($out, $row, ';');
        fclose($out);
        exit;

    // ── Добавление пользователя ───────────────────────────────────────────
    case 'add_user':
        if (!isAuthenticated() || $_SESSION['role_id'] != ROLE_ADMIN) {
            echo json_encode(['success' => false, 'message' => 'Нет прав']); break;
        }
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $role_id  = (int)($_POST['role_id'] ?? ROLE_STUDENT);
        if (!$username || !$password) {
            echo json_encode(['success' => false, 'message' => 'Заполните все поля']); break;
        }
        if (strlen($password) < 6) {
            echo json_encode(['success' => false, 'message' => 'Пароль минимум 6 символов']); break;
        }
        $hash = password_hash($password, PASSWORD_BCRYPT);
        try {
            addUser($username, $hash, $role_id);
            logEventToDB((int)$_SESSION['user_id'], 'user_added', "Добавлен пользователь $username (роль: $role_id)");
            echo json_encode(['success' => true, 'message' => "Пользователь $username добавлен"]);
        } catch (PDOException $e) {
            echo json_encode(['success' => false, 'message' => 'Логин уже занят']);
        }
        break;

    // ── Удаление пользователя ─────────────────────────────────────────────
    case 'delete_user':
        if (!isAuthenticated() || $_SESSION['role_id'] != ROLE_ADMIN) {
            echo json_encode(['success' => false, 'message' => 'Нет прав']); break;
        }
        $id = (int)($_POST['id'] ?? 0);
        if (!$id) { echo json_encode(['success' => false, 'message' => 'Некорректный ID']); break; }
        $stmt = $db->prepare("DELETE FROM users WHERE id = ? AND username != 'admin'");
        $stmt->execute([$id]);
        if ($stmt->rowCount() > 0) {
            logEventToDB((int)$_SESSION['user_id'], 'user_deleted', "Удалён пользователь ID=$id");
            echo json_encode(['success' => true, 'message' => 'Пользователь удалён']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Пользователь не найден или защищён']);
        }
        break;

    default:
        echo json_encode(['error' => 'Unknown action']);
}
