<?php
require_once 'config.php';

// ══════════════════════════════════════════════════════════════════════════
//  ПОЛЬЗОВАТЕЛИ
// ══════════════════════════════════════════════════════════════════════════

function getUserByLogin(string $username): array|false {
    $db = getDB();
    $stmt = $db->prepare("SELECT id, username, password_hash, role_id, ldap_dn FROM users WHERE username = ?");
    $stmt->execute([$username]);
    return $stmt->fetch();
}

function getUserById(int $id): array|false {
    $db = getDB();
    $stmt = $db->prepare("SELECT id, username, role_id FROM users WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function addUser(string $username, string $password_hash, int $role_id, ?string $ldap_dn = null): bool {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO users (username, password_hash, role_id, ldap_dn) VALUES (?, ?, ?, ?)");
    return $stmt->execute([$username, $password_hash, $role_id, $ldap_dn]);
}

function updateUserLastActivity(int $user_id): void {
    $db = getDB();
    $stmt = $db->prepare("UPDATE users SET last_activity = NOW() WHERE id = ?");
    $stmt->execute([$user_id]);
}

function getActiveSessions(int $minutes = 10): array {
    $db = getDB();
    $stmt = $db->prepare(
        "SELECT u.username, u.role_id, u.last_activity
         FROM users u
         WHERE u.last_activity > DATE_SUB(NOW(), INTERVAL ? MINUTE)"
    );
    $stmt->execute([$minutes]);
    return $stmt->fetchAll();
}

// ══════════════════════════════════════════════════════════════════════════
//  ЖУРНАЛ СОБЫТИЙ (event_log)
// ══════════════════════════════════════════════════════════════════════════

/**
 * Запись события в БД.
 * Защита: prepared statements — SQL-инъекции невозможны.
 */
function logEventToDB(?int $user_id, string $event_type, string $description,
                       ?string $ip = null, ?string $user_agent = null): void {
    $db = getDB();
    if (!$ip)         $ip         = $_SERVER['REMOTE_ADDR']     ?? '';
    if (!$user_agent) $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $stmt = $db->prepare(
        "INSERT INTO event_log (user_id, event_type, description, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->execute([$user_id, $event_type, $description, $ip, $user_agent]);
}

// ══════════════════════════════════════════════════════════════════════════
//  УВЕДОМЛЕНИЯ
// ══════════════════════════════════════════════════════════════════════════

function addNotification(int $user_id, string $message): bool {
    $db = getDB();
    $stmt = $db->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
    return $stmt->execute([$user_id, $message]);
}

function getUnreadNotifications(int $user_id): array {
    $db = getDB();
    $stmt = $db->prepare(
        "SELECT id, message, created_at FROM notifications
         WHERE user_id = ? AND is_read = 0
         ORDER BY created_at DESC"
    );
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function markNotificationRead(int $id): bool {
    $db = getDB();
    $stmt = $db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ?");
    return $stmt->execute([$id]);
}

// ══════════════════════════════════════════════════════════════════════════
//  ЧЁРНЫЙ СПИСОК IP
// ══════════════════════════════════════════════════════════════════════════

function isIpBlocked(string $ip): bool {
    $db = getDB();
    $stmt = $db->prepare("SELECT 1 FROM blacklist_ips WHERE ip_address = ?");
    $stmt->execute([$ip]);
    return $stmt->fetch() !== false;
}

function addBlockedIp(string $ip, string $source = 'rkn'): bool {
    $db = getDB();
    if (!isIpBlocked($ip)) {
        $stmt = $db->prepare("INSERT INTO blacklist_ips (ip_address, source) VALUES (?, ?)");
        return $stmt->execute([$ip, $source]);
    }
    return false;
}

// ══════════════════════════════════════════════════════════════════════════
//  АКТИВНОСТЬ ПК (activity_log)
// ══════════════════════════════════════════════════════════════════════════

function insertActivity(int $user_id, string $device_name, string $event_type,
                        string $app_name, string $window_title, string $url,
                        string $start_time, float $duration, mixed $data = null): bool {
    $db = getDB();
    $json_data = $data ? json_encode($data, JSON_UNESCAPED_UNICODE) : null;
    $stmt = $db->prepare(
        "INSERT INTO activity_log
            (user_id, device_name, event_type, app_name, window_title, url, start_time, duration, data)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)"
    );
    return $stmt->execute([$user_id, $device_name, $event_type, $app_name,
                            $window_title, $url, $start_time, $duration, $json_data]);
}

function getActivityForAdmin(int $limit, int $offset, string $device_filter = ''): array {
    $db = getDB();
    $sql    = "SELECT a.*, u.username FROM activity_log a LEFT JOIN users u ON a.user_id = u.id";
    $params = [];
    if ($device_filter !== '') {
        $sql     .= " WHERE a.device_name LIKE ?";
        $params[] = "%$device_filter%";
    }
    $sql .= " ORDER BY a.start_time DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll();
}

function getActivityCount(string $device_filter = ''): int {
    $db = getDB();
    if ($device_filter !== '') {
        $stmt = $db->prepare("SELECT COUNT(*) FROM activity_log WHERE device_name LIKE ?");
        $stmt->execute(["%$device_filter%"]);
    } else {
        $stmt = $db->query("SELECT COUNT(*) FROM activity_log");
    }
    return (int)$stmt->fetchColumn();
}
