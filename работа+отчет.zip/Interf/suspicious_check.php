<?php
/**
 * suspicious_check.php — Запускается по cron каждые 5 минут.
 * Пример crontab: * /5 * * * * php /var/www/html/suspicious_check.php
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db_functions.php';

$db = getDB();

// ── 1. Блокировка IP с частыми неудачными входами (>5 за 10 минут) ─────────
$stmt = $db->query(
    "SELECT ip_address, COUNT(*) as cnt
     FROM event_log
     WHERE event_type = 'auth_failed'
       AND created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE)
     GROUP BY ip_address
     HAVING cnt > 5"
);
$rows = $stmt->fetchAll();

foreach ($rows as $row) {
    $ip = $row['ip_address'];

    // Добавляем в чёрный список (функция сама проверит дубли)
    $added = addBlockedIp($ip, 'suspicious');

    if ($added) {
        // Уведомляем всех преподавателей и администраторов
        $msg      = "Подозрительная активность с IP $ip — автоматическая блокировка ({$row['cnt']} неудачных входов за 10 мин).";
        $notifStmt = $db->prepare(
            "INSERT INTO notifications (user_id, message)
             SELECT id, ? FROM users WHERE role_id IN (1, 2)"
        );
        $notifStmt->execute([$msg]);

        logEvent("Заблокирован подозрительный IP $ip (cnt={$row['cnt']})", "WARNING", "suspicious");
        logEventToDB(null, 'ip_blocked', "Авто-блокировка IP $ip по подозрительной активности", $ip);

        echo "[BLOCK] $ip — {$row['cnt']} попыток\n";
    }
}

// ── 2. Фиксация сессий, активных > 45 минут (нарушение таймаута) ────────────
$timeoutStmt = $db->query(
    "SELECT id, username
     FROM users
     WHERE last_activity < DATE_SUB(NOW(), INTERVAL 45 MINUTE)
       AND last_activity IS NOT NULL"
);
$timedOut = $timeoutStmt->fetchAll();

foreach ($timedOut as $row) {
    logEventToDB((int)$row['id'], 'timeout', "Сессия пользователя {$row['username']} превысила 45 минут");
}

// ── 3. Фиксация входа/выхода и времени простоя ──────────────────────────────
// (логируется автоматически через login.php и logout.php — здесь только архив)
$idleStmt = $db->query(
    "SELECT u.username,
            TIMESTAMPDIFF(MINUTE, u.last_activity, NOW()) AS idle_min
     FROM users u
     WHERE u.last_activity IS NOT NULL
       AND TIMESTAMPDIFF(MINUTE, u.last_activity, NOW()) BETWEEN 10 AND 44"
);
$idleUsers = $idleStmt->fetchAll();

foreach ($idleUsers as $row) {
    // Тихо логируем простой — не бьём тревогу, просто записываем
    logEvent("Пользователь {$row['username']} неактивен {$row['idle_min']} мин", "INFO", "idle");
}

echo "=== suspicious_check завершён ===\n";
