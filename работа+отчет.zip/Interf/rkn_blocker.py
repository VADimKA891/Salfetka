#!/usr/bin/env python3
"""
rkn_blocker.py — Загрузка IP из реестра РКН и их блокировка.
Запускается по cron, например раз в сутки:
    0 3 * * * /usr/bin/python3 /var/www/html/rkn_blocker.py >> /var/log/rkn_blocker.log 2>&1
"""

import os
import re
import platform
import subprocess
import pymysql
import requests
from dotenv import load_dotenv

load_dotenv()

DB_CONFIG = {
    'host':     os.getenv('DB_HOST'),
    'port':     int(os.getenv('DB_PORT', 3306)),
    'user':     os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME'),
    'charset':  'utf8mb4',
}

# Список источников IP РКН (можно добавить альтернативные)
RKN_SOURCES = [
    "https://raw.githubusercontent.com/zapret-info/z-i/master/dump.csv",   # GitHub-зеркало
    "http://eais.rkn.gov.ru/service/getxml?type=ip",                        # Официальный (нестабильный)
]


def get_rkn_ips() -> set[str]:
    """Пытается получить список IP РКН из доступных источников."""
    for url in RKN_SOURCES:
        try:
            resp = requests.get(url, timeout=30)
            resp.raise_for_status()
            ips = set(re.findall(r'\b(\d{1,3}(?:\.\d{1,3}){3})\b', resp.text))
            if ips:
                print(f"[OK] Получено {len(ips)} IP из {url}")
                return ips
        except Exception as e:
            print(f"[WARN] {url}: {e}")
    return set()


def block_ip_windows(ip: str) -> None:
    subprocess.run(f'netsh advfirewall firewall add rule name="BLOCK_RKN_{ip}" dir=in  action=block remoteip={ip}', shell=True, capture_output=True)
    subprocess.run(f'netsh advfirewall firewall add rule name="BLOCK_RKN_{ip}_out" dir=out action=block remoteip={ip}', shell=True, capture_output=True)


def block_ip_linux(ip: str) -> None:
    subprocess.run(f'sudo iptables -A INPUT  -s {ip} -j DROP', shell=True, capture_output=True)
    subprocess.run(f'sudo iptables -A OUTPUT -d {ip} -j DROP', shell=True, capture_output=True)


def main() -> None:
    print("=== rkn_blocker запущен ===")
    ips = get_rkn_ips()
    if not ips:
        print("[ERROR] Не удалось получить список IP РКН. Выход.")
        return

    conn   = pymysql.connect(**DB_CONFIG)
    cursor = conn.cursor()
    os_type = platform.system()
    blocked_count = 0

    for ip in ips:
        try:
            cursor.execute(
                "INSERT IGNORE INTO blacklist_ips (ip_address, source) VALUES (%s, 'rkn')",
                (ip,)
            )
            if cursor.rowcount > 0:
                conn.commit()
                if os_type == "Windows":
                    block_ip_windows(ip)
                else:
                    block_ip_linux(ip)
                blocked_count += 1
                if blocked_count % 100 == 0:
                    print(f"  ... заблокировано {blocked_count}")
        except pymysql.Error as e:
            print(f"[DB ERROR] {ip}: {e}")

    cursor.close()
    conn.close()
    print(f"[DONE] Добавлено в блокировку: {blocked_count} новых IP из {len(ips)} полученных")


if __name__ == "__main__":
    main()
