<?php
error_reporting(E_ALL);
date_default_timezone_set('Europe/Moscow');

// ── Загрузка .env ──────────────────────────────────────────────────────────
if (file_exists(__DIR__ . '/.env')) {
    $lines = file(__DIR__ . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') === false) continue;
        [$key, $value] = explode('=', $line, 2);
        putenv(trim($key) . '=' . trim($value));
        $_ENV[trim($key)] = trim($value);
    }
}

// ── Вывод ошибок ───────────────────────────────────────────────────────────
if (getenv('DISPLAY_ERRORS') == '1') {
    ini_set('display_errors', 1);
} else {
    ini_set('display_errors', 0);
    ini_set('log_errors', 1);
    ini_set('error_log', __DIR__ . '/php_errors.log');
}

// ── Роли ───────────────────────────────────────────────────────────────────
define('ROLE_ADMIN',   1);
define('ROLE_TEACHER', 2);
define('ROLE_STUDENT', 3);

// ── Сессия ─────────────────────────────────────────────────────────────────
$timeout = (int)getenv('SESSION_TIMEOUT') ?: 45;
ini_set('session.gc_maxlifetime', $timeout * 60);
session_set_cookie_params([
    'lifetime' => $timeout * 60,
    'path'     => '/',
    'secure'   => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_name('KUZSTU_SESSION');
if (session_status() === PHP_SESSION_NONE) session_start();

// ── Таймаут сессии ─────────────────────────────────────────────────────────
function checkSessionTimeout() {
    $timeout = (int)getenv('SESSION_TIMEOUT') ?: 45;
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout * 60)) {
        logEvent("Сессия истекла для пользователя " . ($_SESSION['username'] ?? 'unknown'), "INFO", "session");
        session_unset();
        session_destroy();
        header('Location: login.php?timeout=1');
        exit;
    }
    $_SESSION['last_activity'] = time();
}

// ── Логирование в файл ─────────────────────────────────────────────────────
function logEvent($message, $level = "INFO", $category = "application") {
    $log_file = __DIR__ . '/app.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] [$level] [$category] $message\n", FILE_APPEND | LOCK_EX);
}

// ── Проверка аутентификации ────────────────────────────────────────────────
function isAuthenticated() {
    return isset($_SESSION['user_id']);
}

// ── Проверка доступа по роли ───────────────────────────────────────────────
function canAccess($role_id, $required_role) {
    if ($role_id == ROLE_ADMIN) return true;
    if ($required_role == ROLE_STUDENT) return true;
    if ($required_role == ROLE_TEACHER && $role_id == ROLE_TEACHER) return true;
    return false;
}

// ── XSS-санитизация ────────────────────────────────────────────────────────
function sanitize($input) {
    return htmlspecialchars((string)$input, ENT_QUOTES, 'UTF-8');
}

/**
 * Подключение к БД через PDO (singleton).
 * ВАЖНО: используем PDO — защита от SQL-инъекций через prepared statements.
 */
function getDB(): PDO {
    static $conn = null;
    if ($conn === null) {
        $host = getenv('DB_HOST');
        $port = (int)(getenv('DB_PORT') ?: 3306);
        $user = getenv('DB_USER');
        $pass = getenv('DB_PASSWORD');
        $name = getenv('DB_NAME');

        if (!$host || !$user || !$name) {
            throw new RuntimeException("Не заданы переменные окружения для БД");
        }

        $dsn = "mysql:host=$host;port=$port;dbname=$name;charset=utf8mb4";
        $conn = new PDO($dsn, $user, $pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    }
    return $conn;
}

/**
 * Алиас для обратной совместимости (старый код использовал connectToDatabase()).
 */
function connectToDatabase(): PDO {
    return getDB();
}
