<?php
require_once 'config.php';
require_once 'db_functions.php';

checkSessionTimeout();

if (!isAuthenticated() || ($_SESSION['role_id'] != ROLE_ADMIN && $_SESSION['role_id'] != ROLE_TEACHER)) {
    header('Location: index.php');
    exit;
}

$db      = getDB();
$user_id = (int)$_SESSION['user_id'];

// ── Отметить прочитанным ───────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['mark_read'])) {
    $id = (int)$_POST['id'];
    markNotificationRead($id);   // ← правильный вызов, без $conn
    header('Location: notifications.php');
    exit;
}

// ── Все уведомления пользователя ──────────────────────────────────────────
$stmt = $db->prepare(
    "SELECT id, message, is_read, created_at
     FROM notifications
     WHERE user_id = ?
     ORDER BY created_at DESC"
);
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Уведомления | КузГТУ</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
<div class="container">
    <div class="header">
        <div class="logo">
            <img src="https://kuzstu.ru/local/templates/kuzstu/images/logo.svg" alt="КузГТУ" onerror="this.src='https://via.placeholder.com/44?text=KuzGTU'">
            <div class="logo-text"><h1>КузГТУ</h1><p>Уведомления</p></div>
        </div>
        <div class="user-info">
            <a href="index.php" class="btn-logout"><i class="fas fa-arrow-left"></i> На главную</a>
        </div>
    </div>

    <div class="card">
        <h3><i class="fas fa-bell"></i> Все уведомления</h3>

        <?php if (empty($notifications)): ?>
            <p class="text-muted" style="text-align:center; padding:40px 0">Уведомлений нет</p>
        <?php endif; ?>

        <?php foreach ($notifications as $n): ?>
        <div style="
            margin: 12px 0;
            padding: 14px 18px;
            border-radius: 12px;
            border-left: 4px solid <?= $n['is_read'] ? 'var(--gray-200)' : 'var(--blue)' ?>;
            background: <?= $n['is_read'] ? 'var(--gray-50)' : 'var(--blue-pale)' ?>;
        ">
            <small class="text-muted"><?= sanitize($n['created_at']) ?></small>
            <p style="margin-top:4px"><?= sanitize($n['message']) ?></p>
            <?php if (!$n['is_read']): ?>
            <form method="post" style="display:inline; margin-top:8px">
                <input type="hidden" name="id" value="<?= (int)$n['id'] ?>">
                <button type="submit" name="mark_read" class="btn-sm">
                    <i class="fas fa-check"></i> Отметить прочитанным
                </button>
            </form>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
</body>
</html>
