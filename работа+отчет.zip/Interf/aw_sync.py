#!/usr/bin/env python3
"""
Синхронизация данных ActivityWatch со студенческого ПК в центральную БД.
Использует обратный SSH-туннель, который пробрасывает порт студента на localhost:5601.
"""

import os
import json
from datetime import datetime, timedelta
import pymysql
from aw_client import ActivityWatchClient
from dotenv import load_dotenv

# Загружаем переменные из .env
load_dotenv()

# Конфигурация БД из .env
DB_CONFIG = {
    'host': os.getenv('DB_HOST'),
    'port': int(os.getenv('DB_PORT', 3306)),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME'),
    'charset': 'utf8mb4'
}

# Список устройств (студентов)
DEVICES = [
    {
        'name': 'r45notebook',
        'user_id': 2,
        'host': 'localhost',
        'port': 5601,
    },
]

def sync_device(device):
    conn = None
    try:
        client = ActivityWatchClient(host=device['host'], port=device['port'])
        conn = pymysql.connect(**DB_CONFIG)
        cursor = conn.cursor()
        
        cursor.execute(
            "SELECT MAX(start_time) FROM activity_log WHERE device_name = %s",
            (device['name'],)
        )
        last = cursor.fetchone()[0]
        if last is None:
            last = datetime.now() - timedelta(days=7)
        print(f"[{device['name']}] Синхронизация с {last}")
        
        buckets = client.get_buckets()
        window_bucket = None
        for bid in buckets:
            if 'aw-watcher-window' in bid:
                window_bucket = bid
                break
        
        if not window_bucket:
            print(f"[{device['name']}] Bucket 'aw-watcher-window' не найден")
            return
        
        events = client.get_events(window_bucket, start=last, end=datetime.now())
        print(f"[{device['name']}] Найдено событий: {len(events)}")
        
        for ev in events:
            data = ev['data']
            app = data.get('app', '')
            title = data.get('title', '')
            event_type = 'web' if ('http://' in title or 'https://' in title) else 'window'
            url = title if event_type == 'web' else ''
            
            # Преобразование duration в секунды (float)
            duration_raw = ev.get('duration', 0)
            if duration_raw is None:
                duration = 0.0
            elif isinstance(duration_raw, timedelta):
                duration = duration_raw.total_seconds()
            else:
                duration = float(duration_raw)
            
            cursor.execute("""
                INSERT INTO activity_log 
                (user_id, device_name, event_type, app_name, window_title, url, start_time, duration, data)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """, (
                device['user_id'],
                device['name'],
                event_type,
                app,
                title,
                url,
                ev['timestamp'],
                duration,
                json.dumps(data)
            ))
        
        conn.commit()
        print(f"[{device['name']}] Успешно синхронизировано {len(events)} событий")
        
    except Exception as e:
        print(f"[{device['name']}] Ошибка: {e}")
    finally:
        if conn:
            conn.close()

def main():
    print("=== Синхронизация ActivityWatch ===")
    for dev in DEVICES:
        sync_device(dev)
    print("=== Готово ===")

if __name__ == '__main__':
    main()