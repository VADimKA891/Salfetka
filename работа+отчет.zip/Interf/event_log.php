<?php
require_once 'config.php';
require_once 'db_functions.php';
checkSessionTimeout();
if (!isAuthenticated() || ($_SESSION['role_id'] != ROLE_ADMIN && $_SESSION['role_id'] != ROLE_TEACHER)) {
    echo "Нет доступа";
    exit;
}

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 50;
$offset = ($page - 1) * $limit;

$db = getDB();

// Общее количество
$stmt = $db->query("SELECT COUNT(*) FROM event_log");
$total = $stmt->fetchColumn();
$totalPages = ceil($total / $limit);

// Данные с пагинацией
$stmt = $db->prepare("SELECT el.*, u.username FROM event_log el LEFT JOIN users u ON el.user_id = u.id ORDER BY el.created_at DESC LIMIT :limit OFFSET :offset");
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$logs = $stmt->fetchAll();
?>
<div class="glass-card">
    <h3>Журнал событий</h3>
    <div class="table-wrapper">
        <table class="data-table">
            <thead><tr><th>Время</th><th>Пользователь</th><th>Тип</th><th>Описание</th><th>IP</th></tr></thead>
            <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= $log['created_at'] ?></td>
                    <td><?= htmlspecialchars($log['username'] ?? '—') ?></td>
                    <td><?= $log['event_type'] ?></td>
                    <td><?= htmlspecialchars($log['description']) ?></td>
                    <td><?= $log['ip_address'] ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=logs&p=<?= $i ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>