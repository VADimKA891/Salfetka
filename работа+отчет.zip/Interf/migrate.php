<?php
/**
 * migrate.php — Создание структуры БД.
 * Запускать ОДИН раз: php migrate.php
 */
require_once 'config.php';

$db = getDB();

$tables = [

'users' => "CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    username      VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL DEFAULT '',
    role_id       TINYINT NOT NULL DEFAULT 3,
    ldap_dn       VARCHAR(512),
    last_activity DATETIME,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

'event_log' => "CREATE TABLE IF NOT EXISTS event_log (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT,
    event_type  VARCHAR(50) NOT NULL,
    description TEXT,
    ip_address  VARCHAR(45),
    user_agent  VARCHAR(512),
    created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_event_type (event_type),
    INDEX idx_ip (ip_address),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

'activity_log' => "CREATE TABLE IF NOT EXISTS activity_log (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id      INT,
    device_name  VARCHAR(100),
    event_type   VARCHAR(50),
    app_name     VARCHAR(255),
    window_title VARCHAR(512),
    url          TEXT,
    start_time   DATETIME,
    duration     FLOAT DEFAULT 0,
    data         JSON,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user (user_id),
    INDEX idx_device (device_name),
    INDEX idx_start (start_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

'notifications' => "CREATE TABLE IF NOT EXISTS notifications (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    user_id    INT NOT NULL,
    message    TEXT NOT NULL,
    is_read    TINYINT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_unread (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

'blacklist_ips' => "CREATE TABLE IF NOT EXISTS blacklist_ips (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45) NOT NULL UNIQUE,
    source     VARCHAR(50) DEFAULT 'manual',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ip (ip_address)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

];

foreach ($tables as $name => $sql) {
    try {
        $db->exec($sql);
        echo "[OK] Таблица '$name' готова.\n";
    } catch (PDOException $e) {
        echo "[ОШИБКА] Таблица '$name': " . $e->getMessage() . "\n";
    }
}

// Создаём администратора по умолчанию, если таблица пустая
$count = (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn();
if ($count === 0) {
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $db->prepare("INSERT INTO users (username, password_hash, role_id) VALUES ('admin', ?, 1)");
    $stmt->execute([$hash]);
    echo "[OK] Создан пользователь admin / пароль: admin123 — СРАЗУ СМЕНИТЕ!\n";
}

echo "\n=== Миграция завершена ===\n";
