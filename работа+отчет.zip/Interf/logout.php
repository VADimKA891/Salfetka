<?php
/**
 * logout.php — Выход из системы с логированием.
 * ТЗ п.10: Фиксация входа/выхода и времени работы.
 */
require_once 'config.php';

if (isAuthenticated()) {
    require_once 'db_functions.php';

    $user_id  = (int)$_SESSION['user_id'];
    $username = $_SESSION['username'] ?? 'unknown';

    // Считаем время работы сессии
    $session_start = $_SESSION['last_activity'] ?? time();
    $worked_min    = (int)round((time() - $session_start) / 60);

    logEventToDB($user_id, 'logout', "Выход: $username, работал ~$worked_min мин");
    logEvent("Выход: $username (сессия ~$worked_min мин)", "INFO", "auth");
}

$_SESSION = [];
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]);
}
session_destroy();

header('Location: login.php');
exit;
