#!/usr/bin/env python3
"""
suspicious_monitor.py — Демон мониторинга подозрительной активности.
Запускается постоянно, проверяет БД каждые 60 секунд.
Блокирует IP на уровне ОС при >3 неудачных входах за минуту.

Запуск: python suspicious_monitor.py
"""

import os
import time
import platform
import subprocess
import pymysql
from dotenv import load_dotenv

# Загружаем переменные из .env (файл должен лежать рядом)
load_dotenv()

DB_CONFIG = {
    'host':     os.getenv('DB_HOST'),
    'port':     int(os.getenv('DB_PORT', 3306)),
    'user':     os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'database': os.getenv('DB_NAME'),
    'charset':  'utf8mb4',
}

# Порог: >3 неудачных входа за 1 минуту → блокировка
THRESHOLD    = 3
INTERVAL_MIN = 1
SLEEP_SEC    = 60


def block_ip(ip: str) -> None:
    """Блокируем IP на уровне ОС."""
    if platform.system() == "Windows":
        cmds = [
            f'netsh advfirewall firewall add rule name="SUSPICIOUS_{ip}" dir=in  action=block remoteip={ip}',
            f'netsh advfirewall firewall add rule name="SUSPICIOUS_{ip}_out" dir=out action=block remoteip={ip}',
        ]
    else:
        cmds = [
            f'sudo iptables -A INPUT  -s {ip} -j DROP',
            f'sudo iptables -A OUTPUT -d {ip} -j DROP',
        ]
    for cmd in cmds:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        if result.returncode != 0:
            print(f"  [WARN] Команда завершилась с ошибкой: {result.stderr.strip()}")


def main() -> None:
    print("=== suspicious_monitor запущен ===")
    conn = pymysql.connect(**DB_CONFIG)
    cursor = conn.cursor()

    while True:
        try:
            # Переподключение при разрыве
            conn.ping(reconnect=True)

            # Ищем подозрительные IP
            cursor.execute("""
                SELECT ip_address, COUNT(*) AS cnt
                FROM event_log
                WHERE event_type = 'auth_failed'
                  AND created_at > DATE_SUB(NOW(), INTERVAL %s MINUTE)
                GROUP BY ip_address
                HAVING cnt > %s
            """, (INTERVAL_MIN, THRESHOLD))
            rows = cursor.fetchall()

            for (ip, cnt) in rows:
                # Добавляем в БД (IGNORE если уже есть)
                cursor.execute(
                    "INSERT IGNORE INTO blacklist_ips (ip_address, source) VALUES (%s, 'monitor')",
                    (ip,)
                )
                added = cursor.rowcount > 0
                conn.commit()

                if added:
                    block_ip(ip)
                    print(f"[BLOCK] {ip} — {cnt} попыток за {INTERVAL_MIN} мин")

                    # Уведомляем преподавателей и администраторов
                    msg = f"Автоблокировка IP {ip} (подозрительная активность: {cnt} попыток)"
                    cursor.execute(
                        "INSERT INTO notifications (user_id, message) "
                        "SELECT id, %s FROM users WHERE role_id IN (1, 2)",
                        (msg,)
                    )
                    cursor.execute(
                        "INSERT INTO event_log (user_id, event_type, description, ip_address) "
                        "VALUES (NULL, 'ip_blocked', %s, %s)",
                        (msg, ip)
                    )
                    conn.commit()

        except pymysql.Error as e:
            print(f"[DB ERROR] {e}")
        except Exception as e:
            print(f"[ERROR] {e}")

        time.sleep(SLEEP_SEC)


if __name__ == "__main__":
    main()
