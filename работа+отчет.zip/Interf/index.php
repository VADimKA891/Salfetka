<?php
require_once 'config.php';
require_once 'db_functions.php';

checkSessionTimeout();
if (!isAuthenticated()) { header('Location: login.php'); exit; }

$role_id  = (int)$_SESSION['role_id'];
$username = $_SESSION['username'];
$unread   = ($role_id == ROLE_ADMIN || $role_id == ROLE_TEACHER)
    ? getUnreadNotifications((int)$_SESSION['user_id'])
    : [];
$page = $_GET['page'] ?? 'dashboard';

// Пагинация активности
$activityPage       = isset($_GET['apage']) ? max(1, (int)$_GET['apage']) : 1;
$activityLimit      = 50;
$activityOffset     = ($activityPage - 1) * $activityLimit;
$deviceFilter       = trim($_GET['device'] ?? '');
$activityTotal      = ($page == 'activity' && $role_id == ROLE_ADMIN) ? getActivityCount($deviceFilter) : 0;
$activityTotalPages = $activityTotal > 0 ? (int)ceil($activityTotal / $activityLimit) : 1;
$activities         = ($page == 'activity' && $role_id == ROLE_ADMIN)
    ? getActivityForAdmin($activityLimit, $activityOffset, $deviceFilter)
    : [];

$roleLabel = match($role_id) {
    ROLE_ADMIN   => 'Администратор',
    ROLE_TEACHER => 'Преподаватель',
    default      => 'Студент',
};
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>КузГТУ – Панель управления</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body>
<div class="container">

    <!-- ── ШАПКА ──────────────────────────────────────────────────────── -->
    <div class="header">
        <div class="logo">
            <img src="https://kuzstu.ru/local/templates/kuzstu/images/logo.svg" alt="КузГТУ"
                 onerror="this.src='https://via.placeholder.com/44?text=KuzGTU'">
            <div class="logo-text"><h1>КузГТУ</h1><p>Информационная система</p></div>
        </div>
        <div class="user-info">
            <span class="role"><?= sanitize($roleLabel) ?></span>
            <?php if ($role_id == ROLE_ADMIN || $role_id == ROLE_TEACHER): ?>
            <div class="notif-bell">
                <i class="fas fa-bell"></i>
                <span class="badge"><?= count($unread) ?></span>
                <div class="notif-dropdown">
                    <h4>Уведомления</h4>
                    <?php if (empty($unread)): ?>
                        <div>Нет новых уведомлений</div>
                    <?php endif; ?>
                    <?php foreach ($unread as $n): ?>
                        <div><small><?= sanitize($n['created_at']) ?></small><br><?= sanitize($n['message']) ?></div>
                    <?php endforeach; ?>
                    <a href="notifications.php">Все уведомления</a>
                </div>
            </div>
            <?php endif; ?>
            <a href="logout.php" class="btn-logout"><i class="fas fa-sign-out-alt"></i> Выход</a>
        </div>
    </div>

    <!-- ── НАВИГАЦИЯ ──────────────────────────────────────────────────── -->
    <div class="nav">
        <a href="?page=dashboard"   class="<?= $page=='dashboard'  ?'active':'' ?>"><i class="fas fa-tachometer-alt"></i> Панель</a>
        <?php if (canAccess($role_id, ROLE_TEACHER)): ?>
        <a href="?page=logs"        class="<?= $page=='logs'       ?'active':'' ?>"><i class="fas fa-list-alt"></i> Журнал событий</a>
        <?php endif; ?>
        <?php if ($role_id == ROLE_ADMIN): ?>
        <a href="?page=activity"    class="<?= $page=='activity'   ?'active':'' ?>"><i class="fas fa-desktop"></i> Активность ПК</a>
        <a href="?page=monitoring"  class="<?= $page=='monitoring' ?'active':'' ?>"><i class="fas fa-server"></i> Мониторинг</a>
        <a href="?page=blacklist"   class="<?= $page=='blacklist'  ?'active':'' ?>"><i class="fas fa-ban"></i> Чёрный список IP</a>
        <a href="?page=users"       class="<?= $page=='users'      ?'active':'' ?>"><i class="fas fa-users"></i> Пользователи</a>
        <?php endif; ?>
    </div>

    <!-- ── КОНТЕНТ ────────────────────────────────────────────────────── -->
    <div class="content">

    <?php if ($page == 'dashboard'): ?>
        <!-- Статистика -->
        <div class="stat-grid">
            <div class="stat-card"><i class="fas fa-users"></i><h3 id="online-count">—</h3><p>Активных (10 мин)</p></div>
            <div class="stat-card"><i class="fas fa-ban"></i><h3 id="blocked-count">—</h3><p>Заблокированных IP</p></div>
            <div class="stat-card"><i class="fas fa-history"></i><h3 id="event-count">—</h3><p>Событий за сутки</p></div>
            <div class="stat-card"><i class="fas fa-hourglass-half"></i><h3><?= (int)getenv('SESSION_TIMEOUT') ?: 45 ?></h3><p>Таймаут сессии (мин)</p></div>
        </div>

        <!-- Графики -->
        <div class="card">
            <h3><i class="fas fa-chart-line"></i> Активность за 7 дней</h3>
            <canvas id="activityChart" height="100"></canvas>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; flex-wrap:wrap;">
            <div class="card">
                <h3><i class="fas fa-chart-pie"></i> Топ приложений</h3>
                <canvas id="topAppsChart" height="180"></canvas>
            </div>
            <div class="card">
                <h3><i class="fas fa-microchip"></i> Системные ресурсы</h3>
                <div style="display:flex; gap:16px; flex-wrap:wrap; justify-content:space-around;">
                    <div style="text-align:center"><canvas id="cpuChart" width="130" height="130"></canvas><p class="text-xs text-muted" style="margin-top:6px">CPU Load</p></div>
                    <div style="text-align:center"><canvas id="ramChart" width="130" height="130"></canvas><p class="text-xs text-muted" style="margin-top:6px">RAM</p></div>
                    <div style="text-align:center"><canvas id="diskChart" width="130" height="130"></canvas><p class="text-xs text-muted" style="margin-top:6px">Диск</p></div>
                </div>
            </div>
        </div>

    <?php elseif ($page == 'logs' && canAccess($role_id, ROLE_TEACHER)): ?>
        <?php include 'event_log.php'; ?>

    <?php elseif ($page == 'activity' && $role_id == ROLE_ADMIN): ?>
        <div class="card">
            <h3><i class="fas fa-desktop"></i> Мониторинг активности ПК</h3>
            <div class="form-group">
                <form method="get" style="display:contents">
                    <input type="hidden" name="page" value="activity">
                    <input type="text" name="device" placeholder="Фильтр по устройству" value="<?= sanitize($deviceFilter) ?>">
                    <button type="submit" class="btn"><i class="fas fa-filter"></i> Применить</button>
                </form>
                <!-- Экспорт CSV -->
                <a href="request_handler.php?action=export_csv" class="btn btn-success">
                    <i class="fas fa-file-csv"></i> Экспорт в CSV
                </a>
            </div>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead><tr>
                        <th>Время</th><th>Устройство</th><th>Пользователь</th>
                        <th>Тип</th><th>Приложение</th><th>Заголовок окна</th><th>Длит. (сек)</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($activities as $act): ?>
                        <tr>
                            <td><?= sanitize($act['start_time']) ?></td>
                            <td><?= sanitize($act['device_name']) ?></td>
                            <td><?= sanitize($act['username'] ?? '—') ?></td>
                            <td><?= sanitize($act['event_type']) ?></td>
                            <td><?= sanitize(mb_strimwidth($act['app_name'] ?? '', 0, 30, '…')) ?></td>
                            <td><?= sanitize(mb_strimwidth($act['window_title'] ?? '', 0, 60, '…')) ?></td>
                            <td><?= round((float)$act['duration'], 1) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($activities)): ?>
                        <tr><td colspan="7" style="text-align:center; padding:30px; color:var(--gray-400)">Нет данных</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php if ($activityTotalPages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $activityTotalPages; $i++): ?>
                    <a href="?page=activity&apage=<?= $i ?>&device=<?= urlencode($deviceFilter) ?>"
                       class="page-link <?= $i == $activityPage ? 'active' : '' ?>"><?= $i ?></a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </div>

    <?php elseif ($page == 'monitoring' && $role_id == ROLE_ADMIN): ?>
        <div class="card">
            <h3><i class="fas fa-server"></i> Системные ресурсы (JSON)</h3>
            <pre id="sysinfo" style="background:var(--gray-100); padding:16px; border-radius:12px; font-size:.8rem; overflow:auto; max-height:400px">Загрузка...</pre>
        </div>

    <?php elseif ($page == 'blacklist' && $role_id == ROLE_ADMIN): ?>
        <div class="card">
            <h3><i class="fas fa-shield-alt"></i> Чёрный список IP</h3>
            <div class="form-group">
                <input type="text" id="unblockIpInput" placeholder="IP для ручной разблокировки">
                <button id="unblockIpBtn" class="btn"><i class="fas fa-unlock"></i> Разблокировать</button>
                <a href="request_handler.php?action=export_blacklist_csv" class="btn btn-success">
                    <i class="fas fa-file-csv"></i> Экспорт в CSV
                </a>
            </div>
            <div class="table-wrapper">
                <table class="data-table">
                    <thead><tr><th>IP-адрес</th><th>Источник</th><th>Дата добавления</th><th>Действие</th></tr></thead>
                    <tbody id="blacklistTable"><tr><td colspan="4" style="text-align:center;padding:20px">Загрузка...</td></tr></tbody>
                </table>
            </div>
        </div>

    <?php elseif ($page == 'users' && $role_id == ROLE_ADMIN): ?>
        <?php include 'users.php'; ?>

    <?php else: ?>
        <div class="card">
            <p style="text-align:center; padding:40px; color:var(--gray-400)">
                <i class="fas fa-lock" style="font-size:2rem; margin-bottom:12px; display:block"></i>
                Нет доступа к этой странице.
            </p>
        </div>
    <?php endif; ?>

    </div><!-- /content -->
</div><!-- /container -->

<!-- Toast -->
<div id="toast" class="toast hidden"></div>

<script>
// ── Toast ───────────────────────────────────────────────────────────────────
function showToast(message, isError = false) {
    const toast = $('#toast');
    toast.text(message)
         .css('background', isError ? '#dc2626' : '#059669')
         .removeClass('hidden');
    clearTimeout(window._toastTimer);
    window._toastTimer = setTimeout(() => toast.addClass('hidden'), 3500);
}

// ── Дашборд: статистика + графики ──────────────────────────────────────────
function fetchDashboardStats() {
    $.getJSON('system_stats.php', function(data) {
        $('#blocked-count').text(data.blockedCount ?? '—');
        $('#event-count').text(data.eventsLastDay ?? '—');

        // Активных пользователей
        $.getJSON('request_handler.php?action=active_sessions', function(s) {
            $('#online-count').text(s.count ?? '—');
        });

        // График активности за 7 дней
        const labels = (data.daily || []).map(d => d.date);
        const counts = (data.daily || []).map(d => d.count);
        if (window._actChart) window._actChart.destroy();
        const actCtx = document.getElementById('activityChart')?.getContext('2d');
        if (actCtx) window._actChart = new Chart(actCtx, {
            type: 'line',
            data: {
                labels,
                datasets: [{ label: 'Событий', data: counts,
                    borderColor: '#0033A0', backgroundColor: 'rgba(0,51,160,.08)',
                    tension: .35, fill: true, pointRadius: 4 }]
            },
            options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
        });

        // Топ приложений
        const appLabels = (data.topApps || []).map(a => a.app_name || 'Unknown');
        const appCounts = (data.topApps || []).map(a => parseInt(a.cnt));
        if (window._appsChart) window._appsChart.destroy();
        const appsCtx = document.getElementById('topAppsChart')?.getContext('2d');
        if (appsCtx) window._appsChart = new Chart(appsCtx, {
            type: 'doughnut',
            data: { labels: appLabels, datasets: [{ data: appCounts,
                backgroundColor: ['#0033A0','#3366CC','#6699FF','#99BBFF','#CCddFF'] }] },
            options: { plugins: { legend: { position: 'bottom' } } }
        });

        // Системные ресурсы
        function makeDonut(id, val, label) {
            if (window['_chart_'+id]) window['_chart_'+id].destroy();
            const ctx = document.getElementById(id)?.getContext('2d');
            if (!ctx) return;
            window['_chart_'+id] = new Chart(ctx, {
                type: 'doughnut',
                data: { labels: [label, 'Свободно'],
                    datasets: [{ data: [val, 100-val], backgroundColor: ['#0033A0', 'rgba(0,51,160,.1)'], borderWidth: 0 }] },
                options: { cutout: '72%', plugins: { legend: { display: false },
                    tooltip: { callbacks: { label: c => c.raw + '%' } } } }
            });
        }
        makeDonut('cpuChart', (data.load?.[0] ?? 0) * 100, 'CPU');
        makeDonut('ramChart', data.memory?.percent ?? 0, 'RAM');
        makeDonut('diskChart', data.disk?.percent ?? 0, 'Диск');

        // Мониторинг JSON
        if ($('#sysinfo').length) $('#sysinfo').text(JSON.stringify(data, null, 2));

    }).fail(() => showToast('Ошибка загрузки статистики', true));
}

// ── Чёрный список IP ────────────────────────────────────────────────────────
function loadBlacklist() {
    $.getJSON('request_handler.php?action=list_blacklist', function(data) {
        if (!data.length) {
            $('#blacklistTable').html('<tr><td colspan="4" style="text-align:center;padding:30px;color:var(--gray-400)">Список пуст</td></tr>');
            return;
        }
        let html = '';
        data.forEach(ip => {
            const src = ip.source === 'rkn' ? '<span class="status-badge status-blocked">РКН</span>'
                      : ip.source === 'suspicious' ? '<span class="status-badge status-warning">Авто</span>'
                      : '<span class="status-badge">Ручная</span>';
            html += `<tr>
                <td>${ip.ip_address}</td>
                <td>${src}</td>
                <td>${ip.created_at}</td>
                <td><button class="btn-sm unblock" data-ip="${ip.ip_address}">
                    <i class="fas fa-unlock"></i> Разблокировать
                </button></td>
            </tr>`;
        });
        $('#blacklistTable').html(html);
        $('.unblock').click(function() {
            const ip = $(this).data('ip');
            $.post('request_handler.php', { action: 'unblock_ip', ip }, function(res) {
                showToast(res.message, !res.success);
                loadBlacklist();
                fetchDashboardStats();
            }, 'json').fail(() => showToast('Ошибка сети', true));
        });
    });
}

// ── Инициализация ───────────────────────────────────────────────────────────
$(function() {
    if ($('#activityChart').length || $('#sysinfo').length) {
        fetchDashboardStats();
        setInterval(fetchDashboardStats, 60000);
    }
    if ($('#blacklistTable').length) loadBlacklist();

    $('#unblockIpBtn').click(function() {
        const ip = $('#unblockIpInput').val().trim();
        if (!ip) { showToast('Введите IP-адрес', true); return; }
        $.post('request_handler.php', { action: 'unblock_ip', ip }, function(res) {
            showToast(res.message, !res.success);
            loadBlacklist();
            $('#unblockIpInput').val('');
        }, 'json').fail(() => showToast('Ошибка сети', true));
    });
});
</script>
</body>
</html>
