<?php
require_once 'config.php';
require_once 'db_functions.php';
checkSessionTimeout();
if (!isAuthenticated() || $_SESSION['role_id'] != ROLE_ADMIN) {
    header('Location: index.php');
    exit;
}
$db = getDB();
$users = $db->query("SELECT id, username, role_id, created_at FROM users")->fetchAll();
?>
<div class="card">
    <h3><i class="fas fa-users"></i> Управление пользователями</h3>
    <div class="form-group">
        <input type="text" id="newUsername" placeholder="Логин">
        <input type="password" id="newPassword" placeholder="Пароль">
        <select id="newRole"><option value="3">Студент</option><option value="2">Преподаватель</option><option value="1">Администратор</option></select>
        <button id="addUserBtn" class="btn">Добавить</button>
    </div>
    <div class="table-wrapper">
        <table class="data-table">
            <thead><tr><th>ID</th><th>Логин</th><th>Роль</th><th>Дата создания</th><th>Действия</th></tr></thead>
            <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= htmlspecialchars($u['username']) ?></td>
                    <td><?= $u['role_id'] == 1 ? 'Админ' : ($u['role_id'] == 2 ? 'Преподаватель' : 'Студент') ?></td>
                    <td><?= $u['created_at'] ?></td>
                    <td><?php if ($u['username'] != 'admin'): ?><button class="btn-sm delUser" data-id="<?= $u['id'] ?>">Удалить</button><?php endif; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script>
$(function() {
    $('#addUserBtn').click(function() {
        const username = $('#newUsername').val();
        const password = $('#newPassword').val();
        const role = $('#newRole').val();
        if (username && password) {
            $.post('request_handler.php', { action: 'add_user', username, password, role_id: role }, function(res) {
                showToast(res.message);
                setTimeout(() => location.reload(), 1000);
            }, 'json').fail(() => showToast('Ошибка', true));
        } else showToast('Заполните поля', true);
    });
    $('.delUser').click(function() {
        const id = $(this).data('id');
        if (confirm('Удалить пользователя?')) {
            $.post('request_handler.php', { action: 'delete_user', id: id }, function(res) {
                showToast(res.message);
                setTimeout(() => location.reload(), 1000);
            }, 'json');
        }
    });
});
</script>