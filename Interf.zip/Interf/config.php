<?php
/**
 * КОНФИГУРАЦИОННЫЙ ФАЙЛ СИСТЕМЫ УПРАВЛЕНИЯ
 * Двойная база данных - Глобальная + Локальная
 */

// ============================================
// НАСТРОЙКИ БАЗ ДАННЫХ
// ============================================
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Europe/Moscow');

// Глобальная БД (производство)
define('DB_GLOBAL_HOST', '134.90.167.42:10306');
define('DB_GLOBAL_NAME', 'project_Raslovets');
define('DB_GLOBAL_USER', 'Raslovets');
define('DB_GLOBAL_PASS', '••••••••••••');
define('DB_GLOBAL_PASS_REAL', 'H)GcnttO]vG2Yy5i');

// Локальная БД (разработка)
define('DB_LOCAL_HOST', 'localhost');
define('DB_LOCAL_NAME', 'Tablica');
define('DB_LOCAL_USER', 'admin');
define('DB_LOCAL_PASS', '••••••••••••');
define('DB_LOCAL_PASS_REAL', 'admin');

// ============================================
// НАСТРОЙКИ ПРИЛОЖЕНИЯ
// ============================================
define('APP_NAME', 'Двойная база данных - Глобальная + Локальная');
define('APP_VERSION', '5.0');
define('APP_DEBUG', true);

// ============================================
// ИНИЦИАЛИЗАЦИЯ СЕССИИ (ТОЛЬКО ЗДЕСЬ!)
// ============================================
if (session_status() === PHP_SESSION_NONE) {
    session_name('DUAL_DB_SYSTEM');
    session_start();
}

// ============================================
// ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ
// ============================================

/**
 * Защита от XSS
 */
function sanitize($input) {
    return htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
}

/**
 * Форматирование цены
 */
function formatPrice($price) {
    return number_format($price, 0, ',', ' ') . ' ₽';
}

/**
 * Форматирование даты
 */
function formatDate($date, $format = 'd.m.Y H:i') {
    return date($format, strtotime($date));
}

/**
 * Получение типа объекта
 */
function getPropertyType($key) {
    $types = [
        'apartment' => 'Квартира',
        'house' => 'Дом',
        'commercial' => 'Коммерческая',
        'land' => 'Земельный участок'
    ];
    
    return $types[$key] ?? $key;
}

/**
 * Получение статуса объекта
 */
function getPropertyStatus($key) {
    $statuses = [
        'available' => 'Доступно',
        'sold' => 'Продано',
        'rented' => 'Сдано',
        'reserved' => 'Забронировано'
    ];
    
    return $statuses[$key] ?? $key;
}

/**
 * Получение статуса клиента
 */
function getClientStatus($key) {
    $statuses = [
        'active' => 'Активен',
        'inactive' => 'Неактивен',
        'potential' => 'Потенциальный',
        'vip' => 'VIP'
    ];
    
    return $statuses[$key] ?? $key;
}

/**
 * Получение статуса агента
 */
function getAgentStatus($key) {
    $statuses = [
        'active' => 'Активен',
        'inactive' => 'Неактивен',
        'on_leave' => 'В отпуске'
    ];
    
    return $statuses[$key] ?? $key;
}

/**
 * Получение статуса договора
 */
function getContractStatus($key) {
    $statuses = [
        'active' => 'Активен',
        'completed' => 'Завершен',
        'cancelled' => 'Отменен',
        'pending' => 'В ожидании'
    ];
    
    return $statuses[$key] ?? $key;
}

/**
 * Расчет общей стоимости клиентов
 */
function calculateClientsTotalValue($connection) {
    if (!$connection) return 0;
    
    $result = $connection->query("SELECT SUM(budget) as total FROM clients WHERE status = 'active'");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['total'] ?: 0;
    }
    
    return 0;
}

// ============================================
// ЛОГИРОВАНИЕ СОБЫТИЙ
// ============================================

/**
 * Логирование событий в системе
 * @param string $message Сообщение для лога
 * @param string $level Уровень логирования (INFO, ERROR, WARNING, DEBUG)
 * @param string $category Категория события
 */
function logEvent($message, $level = "INFO", $category = "application") {
    if (!defined('LOG_ENABLED') || !LOG_ENABLED) {
        return;
    }
    
    $log_file = __DIR__ . '/app.log';
    $timestamp = date('Y-m-d H:i:s');
    
    $log_message = sprintf(
        "[%s] [%s] [%s] %s\n",
        $timestamp,
        strtoupper($level),
        $category,
        $message
    );
    
    // Запись в файл лога
    file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);
    
    // Если включена отладка, также выводим в консоль (для CLI)
    if (APP_DEBUG && php_sapi_name() === 'cli') {
        echo $log_message;
    }
}

// Включение логирования
define('LOG_ENABLED', true);
define('LOG_FILE', __DIR__ . '/app.log');
?>