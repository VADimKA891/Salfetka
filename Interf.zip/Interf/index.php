<?php
/**
 * ГЛАВНАЯ СТРАНИЦА – Операции с недвижимостью
 * Дизайн: фиолетовый глясс-морфизм
 */

require_once 'config.php';
require_once 'db_functions.php';

$conn_global = null;
$global_error = null;
$global_stats = [];
$properties = [];

$conn_local = null;
$local_error = null;
$local_tables = [];
$local_stats = [];

// Подключение к глобальной БД
try {
    $conn_global = connectToGlobalDatabase();
    initGlobalDatabase($conn_global);
    $global_stats = getGlobalStats($conn_global);
    $properties = getGlobalProperties($conn_global);
} catch (Exception $e) {
    $global_error = $e->getMessage();
    $conn_global = null;
}

// Подключение к локальной БД
try {
    $conn_local = connectToLocalDatabase();
    $local_tables = getLocalTables($conn_local);
    $local_stats = getLocalStats($conn_local);
} catch (Exception $e) {
    $local_error = $e->getMessage();
    $conn_local = null;
    $local_tables = [];
}

// Данные для вкладок
if ($conn_global) {
    $clients = getClients($conn_global);
    $agents = getAgents($conn_global);
    $contracts = getContracts($conn_global);
    $recent_contracts = getRecentContracts($conn_global, 5);
    $contracts_stats = getContractsStats($conn_global);
    $clients_total_value = calculateClientsTotalValue($conn_global);
    
    // Для выпадающих списков в модальном окне договора
    $clients_list = getClientsList($conn_global);
    $agents_list = getAgentsList($conn_global);
    $properties_list = getPropertiesList($conn_global);
} else {
    $clients = $agents = $contracts = $recent_contracts = [];
    $contracts_stats = ['total_amount' => 0, 'active_count' => 0, 'completed_count' => 0];
    $clients_total_value = 0;
    $clients_list = $agents_list = $properties_list = [];
}

$current_tab = $_GET['tab'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Операции с недвижимостью</title>
    <link rel="icon" type="image/jpeg" href="https://static.vecteezy.com/system/resources/previews/024/787/838/non_2x/home-icon-design-template-free-vector.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</head>
<body>
<div class="container">
    <div class="app-card" style="padding: 30px;">
        <!-- Шапка -->
        <header class="header">
            <div class="header-top" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
                <div class="logo">
                    <div class="logo-icon">
                        <img src="https://static.vecteezy.com/system/resources/previews/024/787/838/non_2x/home-icon-design-template-free-vector.jpg" 
                             alt="Операции с недвижимостью" 
                             style="width: 50px; height: 50px; border-radius: 16px; object-fit: cover;">
                    </div>
                    <div class="logo-text">
                        <h1>Операции с недвижимостью</h1>
                        <p style="color: rgba(255,255,255,0.7);">Управление объектами, клиентами и агентами</p>
                    </div>
                </div>
            </div>

            <!-- Навигация -->
            <nav class="nav-tabs">
                <a href="?tab=dashboard" class="nav-tab <?= $current_tab == 'dashboard' ? 'active' : '' ?>"><i class="fas fa-tachometer-alt"></i> Панель</a>
                <a href="?tab=properties" class="nav-tab <?= $current_tab == 'properties' ? 'active' : '' ?>"><i class="fas fa-home"></i> Объекты</a>
                <a href="?tab=clients" class="nav-tab <?= $current_tab == 'clients' ? 'active' : '' ?>"><i class="fas fa-users"></i> Клиенты <span class="badge"><?= count($clients) ?></span></a>
                <a href="?tab=agents" class="nav-tab <?= $current_tab == 'agents' ? 'active' : '' ?>"><i class="fas fa-user-tie"></i> Агенты <span class="badge"><?= count($agents) ?></span></a>
                <a href="?tab=contracts" class="nav-tab <?= $current_tab == 'contracts' ? 'active' : '' ?>"><i class="fas fa-file-contract"></i> Договоры <span class="badge"><?= count($contracts) ?></span></a>
                <a href="tests.php" class="nav-tab"><i class="fas fa-vial"></i> Тесты</a>
            </nav>
        </header>

        <!-- Уведомления -->
        <?php if (isset($_SESSION['flash_message'])): ?>
        <div class="glass-card" style="margin: 20px 0; padding: 15px; border-left: 4px solid <?= $_SESSION['flash_type'] == 'success' ? '#4caf50' : '#f44336' ?>;">
            <i class="fas fa-<?= $_SESSION['flash_type'] == 'success' ? 'check-circle' : 'exclamation-triangle' ?>" style="margin-right: 10px;"></i>
            <?= $_SESSION['flash_message'] ?>
        </div>
        <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); endif; ?>

        <!-- Контент вкладок -->
        <main class="content-tabs">
            <!-- ГЛАВНАЯ ПАНЕЛЬ (С ДИАГРАММАМИ И ПОСЛЕДНИМИ ДОГОВОРАМИ) -->
            <div id="dashboard" class="tab-content <?= $current_tab == 'dashboard' ? 'active' : '' ?>" style="display: <?= $current_tab == 'dashboard' ? 'block' : 'none' ?>;">
                <h2><i class="fas fa-tachometer-alt"></i> Главная панель</h2>
                
                <div class="stat-grid">
                    <div class="stat-card"><i class="fas fa-home"></i><h3><?= count($properties) ?></h3><p>Объектов</p></div>
                    <div class="stat-card"><i class="fas fa-users"></i><h3><?= count($clients) ?></h3><p>Клиентов</p></div>
                    <div class="stat-card"><i class="fas fa-user-tie"></i><h3><?= count($agents) ?></h3><p>Агентов</p></div>
                    <div class="stat-card"><i class="fas fa-file-contract"></i><h3><?= count($contracts) ?></h3><p>Договоров</p></div>
                </div>
                
                <div class="stat-grid" style="grid-template-columns: repeat(3, 1fr);">
                    <div class="stat-card"><i class="fas fa-ruble-sign"></i><h3><?= formatPrice($contracts_stats['total_amount']) ?></h3><p>Общая сумма</p></div>
                    <div class="stat-card"><i class="fas fa-check-circle" style="color: #4caf50;"></i><h3><?= $contracts_stats['active_count'] ?></h3><p>Активных</p></div>
                    <div class="stat-card"><i class="fas fa-check-double" style="color: #ff9800;"></i><h3><?= $contracts_stats['completed_count'] ?></h3><p>Завершённых</p></div>
                </div>

                <!-- Диаграммы -->
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin: 30px 0;">
                    <div class="glass-card" style="padding: 20px;">
                        <h3><i class="fas fa-chart-pie"></i> Статусы объектов</h3>
                        <canvas id="propertyStatusChart" style="width:100%; max-height:250px;"></canvas>
                    </div>
                    <div class="glass-card" style="padding: 20px;">
                        <h3><i class="fas fa-chart-bar"></i> Типы недвижимости</h3>
                        <canvas id="propertyTypeChart" style="width:100%; max-height:250px;"></canvas>
                    </div>
                </div>

                <!-- Последние договоры -->
                <div class="glass-card" style="padding: 25px; margin-top: 20px;">
                    <h3><i class="fas fa-clock"></i> Последние договоры</h3>
                    <?php if (!empty($recent_contracts)): ?>
                    <div class="table-container" style="margin-top: 15px;">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Клиент</th>
                                    <th>Агент</th>
                                    <th>Объект</th>
                                    <th>Сумма</th>
                                    <th>Дата</th>
                                    <th>Статус</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent_contracts as $c): ?>
                                <tr>
                                    <td><?= $c['id'] ?></td>
                                    <td><?= sanitize($c['client_name']) ?></td>
                                    <td><?= sanitize($c['agent_name']) ?></td>
                                    <td><?= sanitize($c['property_title']) ?></td>
                                    <td><?= formatPrice($c['amount']) ?></td>
                                    <td><?= formatDate($c['contract_date']) ?></td>
                                    <td><span class="status-badge status-<?= $c['status'] ?>"><?= getContractStatus($c['status']) ?></span></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <p>Договоры отсутствуют</p>
                    <?php endif; ?>
                </div>

                <!-- Быстрые действия -->
                <div class="glass-card" style="padding: 25px; margin-top: 20px;">
                    <h3><i class="fas fa-bolt"></i> Быстрые действия</h3>
                    <div style="display: flex; gap: 15px; flex-wrap: wrap; margin-top: 20px;">
                        <a href="?tab=add_property" class="btn-purple"><i class="fas fa-plus"></i> Добавить объект</a>
                        <button onclick="showAddContractModal()" class="btn-purple"><i class="fas fa-file-contract"></i> Добавить договор</button>
                        <a href="tests.php" class="btn-purple"><i class="fas fa-vial"></i> Тестирование</a>
                    </div>
                </div>
            </div>

            <!-- ОБЪЕКТЫ НЕДВИЖИМОСТИ -->
            <div id="properties" class="tab-content <?= $current_tab == 'properties' ? 'active' : '' ?>" style="display: <?= $current_tab == 'properties' ? 'block' : 'none' ?>;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2><i class="fas fa-home"></i> Объекты недвижимости</h2>
                    <a href="?tab=add_property" class="btn-purple"><i class="fas fa-plus"></i> Добавить объект</a>
                </div>
                <?php if ($conn_global): ?>
                    <?php if (!empty($properties)): ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Название</th>
                                    <th>Адрес</th>
                                    <th>Цена</th>
                                    <th>Площадь</th>
                                    <th>Комнат</th>
                                    <th>Тип</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($properties as $p): ?>
                            <tr>
                                <td><?= $p['id'] ?></td>
                                <td><strong><?= sanitize($p['title']) ?></strong></td>
                                <td><?= sanitize($p['address']) ?></td>
                                <td><?= formatPrice($p['price']) ?></td>
                                <td><?= $p['area'] ?> м²</td>
                                <td><?= $p['rooms'] ?></td>
                                <td><?= getPropertyType($p['property_type']) ?></td>
                                <td><span class="status-badge status-<?= $p['status'] ?>"><?= getPropertyStatus($p['status']) ?></span></td>
                                <td>
                                    <div class="action-buttons">
                                        <button onclick="alert('Просмотр <?= $p['id'] ?>')" class="btn-sm btn-purple"><i class="fas fa-eye"></i></button>
                                        <button onclick="alert('Редактирование <?= $p['id'] ?>')" class="btn-sm btn-purple"><i class="fas fa-edit"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="glass-card" style="text-align:center; padding:50px;">
                        <i class="fas fa-home fa-3x" style="color:rgba(255,255,255,0.3);"></i>
                        <h3>Объектов недвижимости нет</h3>
                        <a href="?tab=add_property" class="btn-purple" style="margin-top:20px;">Добавить первый объект</a>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="glass-card error" style="background: rgba(244,67,54,0.2); border-left: 4px solid #f44336;">
                        <i class="fas fa-exclamation-triangle"></i> Ошибка подключения к базе данных
                    </div>
                <?php endif; ?>
            </div>

            <!-- КЛИЕНТЫ -->
            <div id="clients" class="tab-content <?= $current_tab == 'clients' ? 'active' : '' ?>" style="display: <?= $current_tab == 'clients' ? 'block' : 'none' ?>;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2><i class="fas fa-users"></i> Управление клиентами</h2>
                    <button onclick="showAddClientModal()" class="btn-purple"><i class="fas fa-user-plus"></i> Добавить клиента</button>
                </div>
                <div class="stat-grid">
                    <div class="stat-card"><i class="fas fa-users"></i><h3><?= count($clients) ?></h3><p>Всего</p></div>
                    <div class="stat-card"><i class="fas fa-money-bill-wave"></i><h3><?= formatPrice($clients_total_value) ?></h3><p>Общий бюджет</p></div>
                    <div class="stat-card"><i class="fas fa-star"></i><h3><?= count(array_filter($clients, fn($c) => !empty($c['is_vip']))) ?></h3><p>VIP</p></div>
                    <div class="stat-card"><i class="fas fa-home"></i><h3><?= array_sum(array_column($clients, 'property_count')) ?></h3><p>Объектов у клиентов</p></div>
                </div>
                <?php if ($conn_global): ?>
                    <?php if (!empty($clients)): ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ФИО</th>
                                    <th>Контакты</th>
                                    <th>Бюджет</th>
                                    <th>Статус</th>
                                    <th>Объектов</th>
                                    <th>Дата</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($clients as $c): ?>
                            <tr>
                                <td><?= $c['id'] ?></td>
                                <td>
                                    <strong><?= sanitize($c['full_name']) ?></strong>
                                    <?php if (!empty($c['is_vip'])): ?>
                                    <span style="color: gold; margin-left: 5px;"><i class="fas fa-crown"></i></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <i class="fas fa-phone"></i> <?= sanitize($c['phone']) ?><br>
                                    <i class="fas fa-envelope"></i> <?= sanitize($c['email']) ?>
                                </td>
                                <td><?= formatPrice($c['budget']) ?></td>
                                <td><span class="status-badge status-<?= $c['status'] ?>"><?= getClientStatus($c['status']) ?></span></td>
                                <td><?= $c['property_count'] ?></td>
                                <td><?= formatDate($c['created_at']) ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button onclick="viewClient(<?= $c['id'] ?>)" class="btn-sm btn-purple"><i class="fas fa-eye"></i></button>
                                        <button onclick="editClient(<?= $c['id'] ?>)" class="btn-sm btn-purple"><i class="fas fa-edit"></i></button>
                                        <button onclick="deleteClient(<?= $c['id'] ?>)" class="btn-sm btn-purple" style="background: rgba(244,67,54,0.8);"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="glass-card" style="text-align:center; padding:50px;">
                        <i class="fas fa-users fa-3x" style="color:rgba(255,255,255,0.3);"></i>
                        <h3>Клиентов не найдено</h3>
                        <button onclick="showAddClientModal()" class="btn-purple" style="margin-top:20px;">Добавить клиента</button>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="glass-card error">Ошибка подключения к базе данных</div>
                <?php endif; ?>
            </div>

            <!-- АГЕНТЫ -->
            <div id="agents" class="tab-content <?= $current_tab == 'agents' ? 'active' : '' ?>" style="display: <?= $current_tab == 'agents' ? 'block' : 'none' ?>;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2><i class="fas fa-user-tie"></i> Управление агентами</h2>
                    <a href="?tab=add_agent" class="btn-purple"><i class="fas fa-user-plus"></i> Добавить агента</a>
                </div>
                <?php if ($conn_global): ?>
                    <?php if (!empty($agents)): ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>ФИО</th>
                                    <th>Контакты</th>
                                    <th>Комиссия</th>
                                    <th>Клиентов</th>
                                    <th>Объектов</th>
                                    <th>Комиссия (всего)</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($agents as $a): ?>
                            <tr>
                                <td><?= $a['id'] ?></td>
                                <td><strong><?= sanitize($a['full_name']) ?></strong></td>
                                <td>
                                    <i class="fas fa-phone"></i> <?= sanitize($a['phone']) ?><br>
                                    <i class="fas fa-envelope"></i> <?= sanitize($a['email']) ?>
                                </td>
                                <td><?= $a['commission_rate'] ?>%</td>
                                <td><?= $a['client_count'] ?></td>
                                <td><?= $a['property_count'] ?></td>
                                <td><?= formatPrice($a['total_commission'] ?? 0) ?></td>
                                <td><span class="status-badge status-<?= $a['status'] ?>"><?= getAgentStatus($a['status']) ?></span></td>
                                <td>
                                    <div class="action-buttons">
                                        <button onclick="alert('Просмотр <?= $a['id'] ?>')" class="btn-sm btn-purple"><i class="fas fa-eye"></i></button>
                                        <button onclick="alert('Редактирование <?= $a['id'] ?>')" class="btn-sm btn-purple"><i class="fas fa-edit"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="glass-card" style="text-align:center; padding:50px;">
                        <i class="fas fa-user-tie fa-3x" style="color:rgba(255,255,255,0.3);"></i>
                        <h3>Агентов не найдено</h3>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="glass-card error">Ошибка подключения к базе данных</div>
                <?php endif; ?>
            </div>

            <!-- ДОГОВОРЫ (ПОЛНОСТЬЮ РЕАЛИЗОВАНО) -->
            <div id="contracts" class="tab-content <?= $current_tab == 'contracts' ? 'active' : '' ?>" style="display: <?= $current_tab == 'contracts' ? 'block' : 'none' ?>;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
                    <h2><i class="fas fa-file-contract"></i> Управление договорами</h2>
                    <button onclick="showAddContractModal()" class="btn-purple"><i class="fas fa-plus"></i> Добавить договор</button>
                </div>
                
                <div class="stat-grid" style="grid-template-columns: repeat(3, 1fr); margin-bottom: 25px;">
                    <div class="stat-card"><i class="fas fa-ruble-sign"></i><h3><?= formatPrice($contracts_stats['total_amount']) ?></h3><p>Общая сумма</p></div>
                    <div class="stat-card"><i class="fas fa-check-circle"></i><h3><?= $contracts_stats['active_count'] ?></h3><p>Активных</p></div>
                    <div class="stat-card"><i class="fas fa-check-double"></i><h3><?= $contracts_stats['completed_count'] ?></h3><p>Завершённых</p></div>
                </div>

                <?php if ($conn_global): ?>
                    <?php if (!empty($contracts)): ?>
                    <div class="table-container">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Клиент</th>
                                    <th>Агент</th>
                                    <th>Объект</th>
                                    <th>Тип</th>
                                    <th>Сумма</th>
                                    <th>Дата</th>
                                    <th>Статус</th>
                                    <th>Действия</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($contracts as $c): ?>
                            <tr>
                                <td><?= $c['id'] ?></td>
                                <td><?= sanitize($c['client_name'] ?? '—') ?></td>
                                <td><?= sanitize($c['agent_name'] ?? '—') ?></td>
                                <td><?= sanitize($c['property_title'] ?? '—') ?></td>
                                <td><?= $c['contract_type'] ?></td>
                                <td><?= formatPrice($c['amount']) ?></td>
                                <td><?= formatDate($c['contract_date']) ?></td>
                                <td><span class="status-badge status-<?= $c['status'] ?>"><?= getContractStatus($c['status']) ?></span></td>
                                <td>
                                    <div class="action-buttons">
                                        <button onclick="viewContract(<?= $c['id'] ?>)" class="btn-sm btn-purple"><i class="fas fa-eye"></i></button>
                                        <button onclick="deleteContract(<?= $c['id'] ?>)" class="btn-sm btn-purple" style="background: rgba(244,67,54,0.8);"><i class="fas fa-trash"></i></button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="glass-card" style="text-align:center; padding:50px;">
                        <i class="fas fa-file-contract fa-3x" style="color:rgba(255,255,255,0.3);"></i>
                        <h3>Договоров не найдено</h3>
                        <button onclick="showAddContractModal()" class="btn-purple" style="margin-top:20px;">Создать первый договор</button>
                    </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="glass-card error">Ошибка подключения к базе данных</div>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>

<!-- МОДАЛЬНОЕ ОКНО ДОБАВЛЕНИЯ КЛИЕНТА (без изменений) -->
<div id="addClientModal" class="modal-overlay">
    <div class="modal-content">
        <h3><i class="fas fa-user-plus"></i> Добавление нового клиента</h3>
        <form method="POST" action="request_handler.php">
            <input type="hidden" name="action" value="add_client">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                <div class="form-group"><label>ФИО *</label><input type="text" name="full_name" class="form-control" required></div>
                <div class="form-group"><label>Телефон *</label><input type="tel" name="phone" class="form-control" required></div>
                <div class="form-group"><label>Email</label><input type="email" name="email" class="form-control"></div>
                <div class="form-group"><label>Бюджет (₽)</label><input type="number" name="budget" class="form-control" min="0" step="1000"></div>
                <div style="grid-column: span 2;"><div class="form-group"><label>Предпочтения</label><textarea name="preferences" class="form-control" rows="3"></textarea></div></div>
                <div class="form-group"><label>Статус</label><select name="status" class="form-control"><option value="active">Активен</option><option value="inactive">Неактивен</option><option value="potential">Потенциальный</option></select></div>
                <div class="form-group"><label style="display: flex; align-items: center; gap: 10px;"><input type="checkbox" name="is_vip"> VIP клиент</label></div>
            </div>
            <div style="display: flex; gap: 15px; justify-content: flex-end; margin-top: 25px;">
                <button type="button" onclick="closeModal('addClientModal')" class="btn-secondary">Отмена</button>
                <button type="submit" class="btn-purple"><i class="fas fa-save"></i> Сохранить клиента</button>
            </div>
        </form>
    </div>
</div>

<!-- МОДАЛЬНОЕ ОКНО ДОБАВЛЕНИЯ ДОГОВОРА (НОВОЕ) -->
<div id="addContractModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 700px;">
        <h3><i class="fas fa-file-contract"></i> Добавление нового договора</h3>
        <form method="POST" action="request_handler.php">
            <input type="hidden" name="action" value="add_contract">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div class="form-group">
                    <label>Клиент *</label>
                    <select name="client_id" class="form-control" required>
                        <option value="">— Выберите клиента —</option>
                        <?php foreach ($clients_list as $client): ?>
                        <option value="<?= $client['id'] ?>"><?= sanitize($client['full_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Агент *</label>
                    <select name="agent_id" class="form-control" required>
                        <option value="">— Выберите агента —</option>
                        <?php foreach ($agents_list as $agent): ?>
                        <option value="<?= $agent['id'] ?>"><?= sanitize($agent['full_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Объект *</label>
                    <select name="property_id" class="form-control" required>
                        <option value="">— Выберите объект —</option>
                        <?php foreach ($properties_list as $prop): ?>
                        <option value="<?= $prop['id'] ?>" data-price="<?= $prop['price'] ?>">
                            <?= sanitize($prop['title']) ?> (<?= sanitize($prop['address']) ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Тип договора</label>
                    <select name="contract_type" class="form-control">
                        <option value="Купля-продажа">Купля-продажа</option>
                        <option value="Аренда">Аренда</option>
                        <option value="Брокерский">Брокерский</option>
                        <option value="Предварительный">Предварительный</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Сумма (₽) *</label>
                    <input type="number" name="amount" class="form-control" min="0" step="1000" required>
                </div>
                <div class="form-group">
                    <label>Дата договора *</label>
                    <input type="date" name="contract_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="form-group">
                    <label>Статус</label>
                    <select name="status" class="form-control">
                        <option value="active">Активен</option>
                        <option value="completed">Завершён</option>
                        <option value="cancelled">Отменён</option>
                        <option value="pending">В ожидании</option>
                    </select>
                </div>
            </div>
            
            <div style="display: flex; gap: 15px; justify-content: flex-end; margin-top: 30px;">
                <button type="button" onclick="closeModal('addContractModal')" class="btn-secondary">Отмена</button>
                <button type="submit" class="btn-purple"><i class="fas fa-save"></i> Сохранить договор</button>
            </div>
        </form>
    </div>
</div>

<script>
// Функции для модальных окон
function showAddClientModal() {
    document.getElementById('addClientModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function showAddContractModal() {
    document.getElementById('addContractModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Функции для работы с клиентами
function viewClient(id) { alert('Просмотр клиента ID: ' + id); }
function editClient(id) { alert('Редактирование клиента ID: ' + id); }
function deleteClient(id) {
    if (confirm('Удалить клиента?')) window.location.href = 'request_handler.php?delete_client=' + id;
}

// Функции для работы с договорами
function viewContract(id) { alert('Просмотр договора ID: ' + id); }
function deleteContract(id) {
    if (confirm('Удалить договор?')) window.location.href = 'request_handler.php?delete_contract=' + id;
}

// Закрытие по клику вне модального окна
window.onclick = function(e) {
    if (e.target.classList.contains('modal-overlay')) {
        closeModal(e.target.id);
    }
}

// Автоподстановка цены объекта при выборе (для модального окна договора)
document.addEventListener('DOMContentLoaded', function() {
    const propertySelect = document.querySelector('select[name="property_id"]');
    const amountInput = document.querySelector('input[name="amount"]');
    if (propertySelect && amountInput) {
        propertySelect.addEventListener('change', function() {
            const selected = this.options[this.selectedIndex];
            if (selected && selected.dataset.price) {
                amountInput.value = selected.dataset.price;
            }
        });
    }
});

// Графики
<?php if ($conn_global && $current_tab == 'dashboard'): ?>
window.addEventListener('load', function() {
    // Данные для статусов объектов
    <?php
    $status_stats = [];
    $status_result = $conn_global->query("SELECT status, COUNT(*) as cnt FROM properties GROUP BY status");
    while ($row = $status_result->fetch_assoc()) {
        $status_stats[$row['status']] = $row['cnt'];
    }
    $status_labels = json_encode(array_map('getPropertyStatus', array_keys($status_stats)));
    $status_counts = json_encode(array_values($status_stats));
    ?>
    new Chart(document.getElementById('propertyStatusChart'), {
        type: 'pie',
        data: {
            labels: <?= $status_labels ?>,
            datasets: [{
                data: <?= $status_counts ?>,
                backgroundColor: ['#4caf50', '#f44336', '#ff9800', '#2196f3']
            }]
        }
    });

    // Данные для типов объектов
    <?php
    $type_stats = [];
    $type_result = $conn_global->query("SELECT property_type, COUNT(*) as cnt FROM properties GROUP BY property_type");
    while ($row = $type_result->fetch_assoc()) {
        $type_stats[$row['property_type']] = $row['cnt'];
    }
    $type_labels = json_encode(array_map('getPropertyType', array_keys($type_stats)));
    $type_counts = json_encode(array_values($type_stats));
    ?>
    new Chart(document.getElementById('propertyTypeChart'), {
        type: 'doughnut',
        data: {
            labels: <?= $type_labels ?>,
            datasets: [{
                data: <?= $type_counts ?>,
                backgroundColor: ['#9d4edd', '#b983ff', '#c77dff', '#e0b3ff']
            }]
        }
    });
});
<?php endif; ?>
</script>
</body>
</html>