<?php
/**
 * ГЛАВНАЯ СТРАНИЦА СИСТЕМЫ УПРАВЛЕНИЯ
 * Двойная база данных - Глобальная + Локальная
 */

require_once 'config.php'; // В config.php уже есть session_start() с проверкой
require_once 'db_functions.php';

// Инициализация подключений
try {
    $conn_global = connectToGlobalDatabase();
    initGlobalDatabase($conn_global);
    $global_stats = getGlobalStats($conn_global);
    $properties = getGlobalProperties($conn_global);
} catch (Exception $e) {
    $global_error = $e->getMessage();
    $conn_global = null;
}

try {
    $conn_local = connectToLocalDatabase();
    $local_tables = getLocalTables($conn_local);
    $local_stats = getLocalStats($conn_local);
} catch (Exception $e) {
    $local_error = $e->getMessage();
    $conn_local = null;
}

// Получение дополнительных данных
if ($conn_global) {
    $clients = getClients($conn_global);
    $agents = getAgents($conn_global);
    $contracts = getContracts($conn_global);
} else {
    $clients = $agents = $contracts = [];
}

// Текущая вкладка
$current_tab = $_GET['tab'] ?? 'dashboard';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Двойная база данных - Глобальная + Локальная</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="app-card">
            <!-- Шапка -->
            <header class="header">
                <div class="header-top">
                    <div class="logo">
                        <div class="logo-icon">
                            <i class="fas fa-database"></i>
                        </div>
                        <div class="logo-text">
                            <h1>Двойная база данных</h1>
                            <p>Глобальная + Локальная система управления</p>
                        </div>
                    </div>
                    
                    <div class="db-info-container">
                        <div class="db-info global">
                            <i class="fas fa-globe"></i>
                            <div>
                                <strong>Глобальная БД:</strong><br>
                                <small><?php echo DB_GLOBAL_HOST; ?> | <?php echo DB_GLOBAL_NAME; ?></small><br>
                                <span class="connection-status <?php echo $conn_global ? 'status-connected' : 'status-disconnected'; ?>">
                                    <i class="fas fa-<?php echo $conn_global ? 'check-circle' : 'times-circle'; ?>"></i>
                                    <?php echo $conn_global ? 'Подключено' : 'Ошибка'; ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="db-info local">
                            <i class="fas fa-server"></i>
                            <div>
                                <strong>Локальная БД:</strong><br>
                                <small><?php echo DB_LOCAL_HOST; ?> | <?php echo DB_LOCAL_NAME; ?></small><br>
                                <span class="connection-status <?php echo $conn_local ? 'status-connected' : 'status-disconnected'; ?>">
                                    <i class="fas fa-<?php echo $conn_local ? 'check-circle' : 'times-circle'; ?>"></i>
                                    <?php echo $conn_local ? 'Подключено' : 'Ошибка'; ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Навигация -->
                <nav class="nav-tabs">
                    <a href="?tab=dashboard" class="nav-tab <?php echo $current_tab == 'dashboard' ? 'active' : ''; ?>">
                        <i class="fas fa-tachometer-alt"></i> <span>Главная панель</span>
                    </a>
                    <a href="?tab=properties" class="nav-tab <?php echo $current_tab == 'properties' ? 'active' : ''; ?>">
                        <i class="fas fa-home"></i> <span>Объекты недвижимости</span>
                        <span class="badge"><?php echo count($properties); ?></span>
                    </a>
                    <a href="?tab=clients" class="nav-tab <?php echo $current_tab == 'clients' ? 'active' : ''; ?>">
                        <i class="fas fa-users"></i> <span>Клиенты</span>
                        <span class="badge"><?php echo count($clients); ?></span>
                    </a>
                    <a href="?tab=agents" class="nav-tab <?php echo $current_tab == 'agents' ? 'active' : ''; ?>">
                        <i class="fas fa-user-tie"></i> <span>Агенты</span>
                        <span class="badge"><?php echo count($agents); ?></span>
                    </a>
                    <a href="?tab=contracts" class="nav-tab <?php echo $current_tab == 'contracts' ? 'active' : ''; ?>">
                        <i class="fas fa-file-contract"></i> <span>Договоры</span>
                        <span class="badge"><?php echo count($contracts); ?></span>
                    </a>
                    <a href="?tab=tables" class="nav-tab <?php echo $current_tab == 'tables' ? 'active' : ''; ?>">
                        <i class="fas fa-table"></i> <span>Управление таблицами</span>
                        <span class="badge"><?php echo count($local_tables); ?></span>
                    </a>
                    <a href="tests.php" class="nav-tab">
                        <i class="fas fa-vial"></i> <span>Тестирование</span>
                    </a>
                    <a href="?tab=settings" class="nav-tab <?php echo $current_tab == 'settings' ? 'active' : ''; ?>">
                        <i class="fas fa-cog"></i> <span>Настройки</span>
                    </a>
                </nav>
            </header>

            <!-- Уведомления -->
            <?php if (isset($_SESSION['flash_message'])): ?>
            <div class="notification <?php echo $_SESSION['flash_type']; ?>">
                <i class="fas fa-<?php echo $_SESSION['flash_type'] == 'success' ? 'check-circle' : 'exclamation-triangle'; ?>"></i>
                <span><?php echo $_SESSION['flash_message']; ?></span>
            </div>
            <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
            <?php endif; ?>

            <!-- Основной контент -->
            <main class="content-tabs">
                <!-- Вкладка: Главная панель -->
                <div id="dashboard" class="tab-content <?php echo $current_tab == 'dashboard' ? 'active' : ''; ?>">
                    <h2><i class="fas fa-tachometer-alt"></i> Главная панель</h2>
                    
                    <!-- Статистика -->
                    <div class="stat-grid">
                        <div class="stat-card">
                            <i class="fas fa-database"></i>
                            <h3><?php echo ($conn_global ? 1 : 0) + ($conn_local ? 1 : 0); ?>/2</h3>
                            <p>Подключенных БД</p>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-home"></i>
                            <h3><?php echo count($properties); ?></h3>
                            <p>Объектов недвижимости</p>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-users"></i>
                            <h3><?php echo count($clients); ?></h3>
                            <p>Клиентов</p>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-user-tie"></i>
                            <h3><?php echo count($agents); ?></h3>
                            <p>Агентов</p>
                        </div>
                    </div>
                    
                    <!-- Быстрые действия -->
                    <div class="glass-card">
                        <h3><i class="fas fa-bolt"></i> Быстрые действия</h3>
                        <div class="quick-actions">
                            <a href="?tab=add_property" class="btn btn-purple">
                                <i class="fas fa-plus"></i> Добавить объект
                            </a>
                            <a href="?tab=tables" class="btn btn-purple">
                                <i class="fas fa-table"></i> Управление таблицами
                            </a>
                            <a href="tests.php" class="btn btn-purple">
                                <i class="fas fa-vial"></i> Запустить тесты
                            </a>
                            <a href="?tab=settings" class="btn btn-purple">
                                <i class="fas fa-cog"></i> Настройки
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Вкладка: Объекты недвижимости -->
                <div id="properties" class="tab-content <?php echo $current_tab == 'properties' ? 'active' : ''; ?>">
                    <h2><i class="fas fa-home"></i> Объекты недвижимости</h2>
                    
                    <?php if ($conn_global): ?>
                        <?php if (!empty($properties)): ?>
                            <div class="table-container">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Название</th>
                                            <th>Адрес</th>
                                            <th>Цена</th>
                                            <th>Тип</th>
                                            <th>Статус</th>
                                            <th>Действия</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($properties as $property): ?>
                                        <tr>
                                            <td><?php echo $property['id']; ?></td>
                                            <td><?php echo htmlspecialchars($property['title']); ?></td>
                                            <td><?php echo htmlspecialchars($property['address']); ?></td>
                                            <td><?php echo number_format($property['price'], 0, ',', ' ') . ' ₽'; ?></td>
                                            <td><?php echo getPropertyType($property['property_type']); ?></td>
                                            <td>
                                                <span class="status-badge status-<?php echo $property['status']; ?>">
                                                    <?php echo getPropertyStatus($property['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-purple">Просмотр</button>
                                                <button class="btn btn-sm btn-purple">Редактировать</button>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="glass-card">
                                <p>Нет объектов недвижимости</p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="glass-card error">
                            <p>Ошибка подключения к глобальной БД</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Вкладка: Клиенты -->
                <div id="clients" class="tab-content <?php echo $current_tab == 'clients' ? 'active' : ''; ?>">
                    <h2><i class="fas fa-users"></i> Клиенты</h2>
                    
                    <?php if ($conn_global): ?>
                        <?php if (!empty($clients)): ?>
                            <div class="table-container">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>ФИО</th>
                                            <th>Телефон</th>
                                            <th>Email</th>
                                            <th>Бюджет</th>
                                            <th>Статус</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($clients as $client): ?>
                                        <tr>
                                            <td><?php echo $client['id']; ?></td>
                                            <td><?php echo htmlspecialchars($client['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($client['phone']); ?></td>
                                            <td><?php echo htmlspecialchars($client['email']); ?></td>
                                            <td><?php echo number_format($client['budget'], 0, ',', ' ') . ' ₽'; ?></td>
                                            <td>
                                                <span class="status-badge status-<?php echo $client['status']; ?>">
                                                    <?php echo getClientStatus($client['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="glass-card">
                                <p>Нет клиентов</p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="glass-card error">
                            <p>Ошибка подключения к глобальной БД</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Вкладка: Агенты -->
                <div id="agents" class="tab-content <?php echo $current_tab == 'agents' ? 'active' : ''; ?>">
                    <h2><i class="fas fa-user-tie"></i> Агенты</h2>
                    
                    <?php if ($conn_global): ?>
                        <?php if (!empty($agents)): ?>
                            <div class="table-container">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>ФИО</th>
                                            <th>Телефон</th>
                                            <th>Email</th>
                                            <th>Комиссия</th>
                                            <th>Статус</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($agents as $agent): ?>
                                        <tr>
                                            <td><?php echo $agent['id']; ?></td>
                                            <td><?php echo htmlspecialchars($agent['full_name']); ?></td>
                                            <td><?php echo htmlspecialchars($agent['phone']); ?></td>
                                            <td><?php echo htmlspecialchars($agent['email']); ?></td>
                                            <td><?php echo $agent['commission_rate']; ?>%</td>
                                            <td>
                                                <span class="status-badge status-<?php echo $agent['status']; ?>">
                                                    <?php echo getAgentStatus($agent['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="glass-card">
                                <p>Нет агентов</p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="glass-card error">
                            <p>Ошибка подключения к глобальной БД</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Вкладка: Договоры -->
                <div id="contracts" class="tab-content <?php echo $current_tab == 'contracts' ? 'active' : ''; ?>">
                    <h2><i class="fas fa-file-contract"></i> Договоры</h2>
                    
                    <?php if ($conn_global): ?>
                        <?php if (!empty($contracts)): ?>
                            <div class="table-container">
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Клиент</th>
                                            <th>Агент</th>
                                            <th>Объект</th>
                                            <th>Тип</th>
                                            <th>Сумма</th>
                                            <th>Дата</th>
                                            <th>Статус</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($contracts as $contract): ?>
                                        <tr>
                                            <td><?php echo $contract['id']; ?></td>
                                            <td><?php echo htmlspecialchars($contract['client_name']); ?></td>
                                            <td><?php echo htmlspecialchars($contract['agent_name']); ?></td>
                                            <td><?php echo htmlspecialchars($contract['property_title']); ?></td>
                                            <td><?php echo htmlspecialchars($contract['contract_type']); ?></td>
                                            <td><?php echo number_format($contract['amount'], 0, ',', ' ') . ' ₽'; ?></td>
                                            <td><?php echo $contract['contract_date']; ?></td>
                                            <td>
                                                <span class="status-badge status-<?php echo $contract['status']; ?>">
                                                    <?php echo getContractStatus($contract['status']); ?>
                                                </span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="glass-card">
                                <p>Нет договоров</p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="glass-card error">
                            <p>Ошибка подключения к глобальной БД</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Вкладка: Управление таблицами -->
                <div id="tables" class="tab-content <?php echo $current_tab == 'tables' ? 'active' : ''; ?>">
                    <h2><i class="fas fa-table"></i> Управление таблицами</h2>
                    
                    <?php if ($conn_local): ?>
                        <?php if (!empty($local_tables)): ?>
                            <div class="tables-grid">
                                <?php foreach ($local_tables as $table): ?>
                                <div class="table-card">
                                    <i class="fas fa-table"></i>
                                    <h4><?php echo htmlspecialchars($table); ?></h4>
                                    <div class="table-actions">
                                        <button class="btn btn-sm btn-purple">Просмотр</button>
                                        <button class="btn btn-sm btn-purple">Удалить</button>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="glass-card">
                                <p>Нет таблиц в локальной БД</p>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="glass-card error">
                            <p>Ошибка подключения к локальной БД</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Вкладка: Настройки -->
                <div id="settings" class="tab-content <?php echo $current_tab == 'settings' ? 'active' : ''; ?>">
                    <h2><i class="fas fa-cog"></i> Настройки системы</h2>
                    
                    <div class="glass-card">
                        <h3>Настройки подключения к базам данных</h3>
                        
                        <div class="settings-grid">
                            <div class="setting-group">
                                <h4><i class="fas fa-globe"></i> Глобальная база данных</h4>
                                <p><strong>Хост:</strong> <?php echo DB_GLOBAL_HOST; ?></p>
                                <p><strong>База данных:</strong> <?php echo DB_GLOBAL_NAME; ?></p>
                                <p><strong>Пользователь:</strong> <?php echo DB_GLOBAL_USER; ?></p>
                                <p><strong>Пароль:</strong> <?php echo DB_GLOBAL_PASS; ?></p>
                                <p><strong>Статус:</strong> 
                                    <span class="<?php echo $conn_global ? 'status-connected' : 'status-disconnected'; ?>">
                                        <?php echo $conn_global ? 'Подключено' : 'Ошибка'; ?>
                                    </span>
                                </p>
                            </div>
                            
                            <div class="setting-group">
                                <h4><i class="fas fa-server"></i> Локальная база данных</h4>
                                <p><strong>Хост:</strong> <?php echo DB_LOCAL_HOST; ?></p>
                                <p><strong>База данных:</strong> <?php echo DB_LOCAL_NAME; ?></p>
                                <p><strong>Пользователь:</strong> <?php echo DB_LOCAL_USER; ?></p>
                                <p><strong>Пароль:</strong> <?php echo DB_LOCAL_PASS; ?></p>
                                <p><strong>Статус:</strong> 
                                    <span class="<?php echo $conn_local ? 'status-connected' : 'status-disconnected'; ?>">
                                        <?php echo $conn_local ? 'Подключено' : 'Ошибка'; ?>
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Футер -->
            <footer style="padding: 20px; background: #f8f9fa; text-align: center;">
                <p>Двойная база данных - Глобальная + Локальная © <?php echo date('Y'); ?></p>
                <p>Версия: <?php echo APP_VERSION; ?></p>
            </footer>
        </div>
    </div>

    <script>
        // Простая навигация по вкладкам
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('.nav-tab');
            const contents = document.querySelectorAll('.tab-content');
            
            tabs.forEach(tab => {
                tab.addEventListener('click', function(e) {
                    if (this.getAttribute('href').startsWith('?')) {
                        e.preventDefault();
                        
                        // Удаляем активный класс у всех вкладок
                        tabs.forEach(t => t.classList.remove('active'));
                        contents.forEach(c => c.classList.remove('active'));
                        
                        // Добавляем активный класс текущей вкладке
                        this.classList.add('active');
                        
                        // Показываем соответствующий контент
                        const tabId = this.getAttribute('href').split('=')[1];
                        const content = document.getElementById(tabId);
                        if (content) {
                            content.classList.add('active');
                        }
                    }
                });
            });
        });
    </script>
</body>
</html>