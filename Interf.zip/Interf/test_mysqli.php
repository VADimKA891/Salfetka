<?php
echo "<h2>Проверка PHP и MySQL</h2>";
echo "PHP Version: " . phpversion() . "<br><br>";

echo "Загруженные расширения:<br>";
echo "<pre>";
$extensions = get_loaded_extensions();
foreach ($extensions as $ext) {
    echo "- $ext<br>";
}
echo "</pre>";

echo "<br>mysqli загружен? ";
echo extension_loaded('mysqli') ? '✓ ДА' : '✗ НЕТ';
echo "<br>";

echo "PDO загружен? ";
echo extension_loaded('pdo') ? '✓ ДА' : '✗ НЕТ';
echo "<br>";

echo "pdo_mysql загружен? ";
echo extension_loaded('pdo_mysql') ? '✓ ДА' : '✗ НЕТ';
?>