<?php
/**
 * ЗАПУСК ТЕСТОВ ЧЕРЕЗ ВЕБ-ИНТЕРФЕЙС
 * Операции с недвижимостью
 */

require_once 'config.php';

// Проверка наличия Python
$python_available = false;
if (function_exists('shell_exec')) {
    $python_check = shell_exec('python3 --version 2>&1');
    if (strpos($python_check, 'Python') !== false) {
        $python_available = true;
    }
}

if (!$python_available) {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Python3 не установлен'
    ]);
    exit;
}

// Запуск тестов
$script_path = __DIR__ . '/selenium_test.py';
$command = escapeshellcmd("python3 " . $script_path . " 2>&1");
$output = shell_exec($command);

// Сохранение результатов
$result_file = __DIR__ . '/test_results_' . date('Ymd_His') . '.txt';
file_put_contents($result_file, $output);

// Возвращаем результаты
header('Content-Type: application/json');
echo json_encode([
    'status' => 'completed',
    'message' => 'Тестирование завершено',
    'output' => $output
]);