<?php
/**
 * ОБЩИЕ МОДАЛЬНЫЕ ОКНА
 * Двойная база данных - Глобальная + Локальная
 */
?>

<!-- Модальное окно создания таблицы -->
<div id="createTableModal" class="modal-overlay">
    <div class="modal-content">
        <h3><i class="fas fa-plus-circle"></i> Создание новой таблицы</h3>
        <form method="POST" action="">
            <input type="hidden" name="action" value="create_table">
            
            <div class="form-group">
                <label>Название таблицы *</label>
                <input type="text" name="table_name" class="form-control" required
                       placeholder="Введите название таблицы (латинские буквы и цифры)">
            </div>
            
            <p style="color: #666; font-size: 0.9rem; margin-bottom: 20px;">
                <i class="fas fa-info-circle"></i> Таблица будет создана в локальной базе данных
            </p>
            
            <div style="display: flex; gap: 15px; justify-content: flex-end;">
                <button type="button" onclick="closeModal('createTableModal')" class="btn btn-purple" style="background: #6c757d;">
                    Отмена
                </button>
                <button type="submit" class="btn btn-purple">
                    <i class="fas fa-plus"></i> Создать таблицу
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Модальное окно подтверждения удаления -->
<div id="confirmDeleteModal" class="modal-overlay">
    <div class="modal-content">
        <h3><i class="fas fa-exclamation-triangle" style="color: #f44336;"></i> Подтверждение удаления</h3>
        <p id="confirmDeleteMessage">Вы уверены, что хотите удалить этот элемент?</p>
        
        <div style="display: flex; gap: 15px; justify-content: flex-end; margin-top: 20px;">
            <button onclick="closeModal('confirmDeleteModal')" class="btn btn-purple" style="background: #6c757d;">
                Отмена
            </button>
            <button id="confirmDeleteButton" class="btn btn-purple" style="background: #f44336;">
                <i class="fas fa-trash"></i> Удалить
            </button>
        </div>
    </div>
</div>

<script>
// Глобальные функции для модальных окон
function showCreateTableModal() {
    document.getElementById('createTableModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function showConfirmDeleteModal(message, deleteUrl) {
    document.getElementById('confirmDeleteMessage').textContent = message;
    document.getElementById('confirmDeleteButton').onclick = function() {
        window.location.href = deleteUrl;
    };
    document.getElementById('confirmDeleteModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto';
}

// Закрытие модальных окон при нажатии Escape
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        const modals = document.querySelectorAll('.modal-overlay');
        modals.forEach(modal => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        });
    }
});
</script>