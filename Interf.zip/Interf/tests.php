<?php
/**
 * ВЕБ-ИНТЕРФЕЙС ДЛЯ ТЕСТИРОВАНИЯ
 * Операции с недвижимостью
 */

require_once 'config.php';

// Проверка Python (работает на Windows/Linux/Mac)
$python_available = false;
$python_version = '';
if (function_exists('shell_exec')) {
    $python_candidates = ['python3', 'python', 'py'];
    foreach ($python_candidates as $cmd) {
        $test = shell_exec($cmd . ' --version 2>&1');
        if (strpos($test, 'Python') !== false) {
            $python_available = true;
            $python_version = trim($test);
            define('PYTHON_CMD', $cmd);
            break;
        }
    }
}

// Проверка Selenium
$selenium_available = false;
if ($python_available) {
    $selenium_check = shell_exec(PYTHON_CMD . ' -c "import selenium; print(\"ok\")" 2>&1');
    $selenium_available = (strpos($selenium_check, 'ok') !== false);
}

// Обработка запуска тестов (упрощённо)
$test_output = '';
if (isset($_GET['run']) && $python_available && $selenium_available) {
    $script = __DIR__ . '/selenium_test.py';
    $test_output = shell_exec(PYTHON_CMD . ' ' . escapeshellarg($script) . ' 2>&1');
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тестирование – Операции с недвижимостью</title>
    <link rel="icon" href="https://static.vecteezy.com/system/resources/previews/024/787/838/non_2x/home-icon-design-template-free-vector.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <style>
        .status-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px,1fr)); gap: 20px; margin: 30px 0; }
        .status-item { background: rgba(255,255,255,0.08); backdrop-filter: blur(10px); border-radius: 20px; padding: 25px; border:1px solid rgba(255,255,255,0.15); }
        .status-item.ok { border-top: 4px solid #4caf50; }
        .status-item.error { border-top: 4px solid #f44336; }
        .pre-box { background: #1e1e2f; border-radius: 12px; padding: 20px; overflow-x: auto; margin-top: 20px; }
        .btn { margin-right: 15px; }
    </style>
</head>
<body>
<div class="container">
    <div class="app-card" style="padding: 30px;">
        <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 20px;">
            <a href="index.php" class="btn btn-purple"><i class="fas fa-arrow-left"></i> На главную</a>
            <h1><i class="fas fa-vial" style="color: #b983ff;"></i> Автоматизированное тестирование</h1>
        </div>

        <!-- Статус окружения -->
        <div class="status-grid">
            <div class="status-item <?= $python_available ? 'ok' : 'error' ?>">
                <h3><i class="fas fa-code"></i> Python</h3>
                <p style="font-size: 1.2rem;"><?= $python_available ? '✓ Доступен' : '✗ Не найден' ?></p>
                <?php if ($python_version): ?><small><?= $python_version ?></small><?php endif; ?>
            </div>
            <div class="status-item <?= $selenium_available ? 'ok' : 'error' ?>">
                <h3><i class="fas fa-robot"></i> Selenium</h3>
                <p style="font-size: 1.2rem;"><?= $selenium_available ? '✓ Установлен' : '✗ Не установлен' ?></p>
                <?php if (!$selenium_available && $python_available): ?>
                <small>Выполните: pip install selenium</small>
                <?php endif; ?>
            </div>
            <div class="status-item <?= $selenium_available && $python_available ? 'ok' : 'error' ?>">
                <h3><i class="fas fa-flask"></i> Готовность</h3>
                <p style="font-size: 1.2rem;"><?= ($selenium_available && $python_available) ? '✓ Можно запускать' : '✗ Настройте окружение' ?></p>
            </div>
        </div>

        <!-- Кнопка запуска -->
        <div style="margin: 30px 0;">
            <?php if ($python_available && $selenium_available): ?>
                <a href="?run=1" class="btn btn-purple"><i class="fas fa-play"></i> Запустить тесты</a>
                <p style="margin-top: 10px; color: rgba(255,255,255,0.7);">
                    <i class="fas fa-info-circle"></i> Тесты запустятся в браузере Chrome. Убедитесь, что chromedriver доступен в PATH.
                </p>
            <?php else: ?>
                <button class="btn btn-purple" disabled style="opacity:0.6;"><i class="fas fa-ban"></i> Запуск недоступен</button>
            <?php endif; ?>
        </div>

        <!-- Результаты тестов -->
        <?php if ($test_output): ?>
        <div class="glass-card" style="padding: 25px; margin-top: 20px;">
            <h3><i class="fas fa-clipboard-list"></i> Результаты тестирования</h3>
            <div class="pre-box">
                <pre style="color: #fff; margin:0;"><?= htmlspecialchars($test_output) ?></pre>
            </div>
        </div>
        <?php endif; ?>

        <!-- Инструкция (всегда видна) -->
        <div class="glass-card" style="padding: 25px; margin-top: 30px;">
            <h3><i class="fas fa-cog"></i> Настройка окружения</h3>
            <ul style="list-style: none; padding: 0;">
                <li style="margin-bottom: 10px;">1. Установите Python 3 с <a href="https://python.org" target="_blank">python.org</a></li>
                <li style="margin-bottom: 10px;">2. Установите Selenium: <code style="background: #000; padding: 3px 8px; border-radius: 6px;">pip install selenium</code></li>
                <li style="margin-bottom: 10px;">3. Скачайте <a href="https://chromedriver.chromium.org/" target="_blank">ChromeDriver</a> и поместите в PATH</li>
                <li style="margin-bottom: 10px;">4. Убедитесь, что проект открывается по URL <strong>http://localhost/ваша_папка/</strong> – при необходимости поправьте в файле selenium_test.py переменную BASE_URL</li>
            </ul>
        </div>
    </div>
</div>
</body>
</html>