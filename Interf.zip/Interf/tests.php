<?php
/**
 * ВЕБ-ИНТЕРФЕЙС ДЛЯ ТЕСТИРОВАНИЯ
 * Двойная база данных - Глобальная + Локальная
 */

require_once 'config.php'; // В config.php уже есть session_start() с проверкой

// Проверка наличия Python
$python_available = false;
$python_version = '';
if (function_exists('shell_exec')) {
    $python_check = shell_exec('python3 --version 2>&1');
    if (strpos($python_check, 'Python') !== false) {
        $python_available = true;
        $python_version = trim($python_check);
    }
}

// Проверка наличия Selenium
$selenium_available = false;
if ($python_available) {
    $selenium_check = shell_exec('python3 -c "import selenium; print(\"Selenium установлен\")" 2>&1');
    if (strpos($selenium_check, 'Selenium установлен') !== false) {
        $selenium_available = true;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Тестирование системы</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            min-height: 100vh;
            padding: 20px;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .card {
            background: white;
            border-radius: 20px;
            padding: 30px;
            margin-bottom: 20px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        
        h1 {
            color: #333;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .status-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .status-item {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            border-left: 4px solid #ccc;
        }
        
        .status-item.ok {
            border-left-color: #4CAF50;
        }
        
        .status-item.error {
            border-left-color: #f44336;
        }
        
        .test-button {
            background: linear-gradient(135deg, #9d4edd, #7b2cbf);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 10px;
            font-size: 16px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.3s;
            text-decoration: none;
            margin-right: 10px;
            margin-bottom: 10px;
        }
        
        .test-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(157, 78, 221, 0.4);
        }
        
        .test-results {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-top: 30px;
            max-height: 500px;
            overflow-y: auto;
            font-family: monospace;
            white-space: pre-wrap;
        }
        
        .test-summary {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .summary-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .summary-card.passed {
            border-top: 4px solid #4CAF50;
        }
        
        .summary-card.failed {
            border-top: 4px solid #f44336;
        }
        
        .summary-card.total {
            border-top: 4px solid #2196F3;
        }
        
        .back-link {
            display: inline-block;
            margin-top: 20px;
            color: #9d4edd;
            text-decoration: none;
            font-weight: bold;
        }
        
        pre {
            background: #2c3e50;
            color: white;
            padding: 15px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <h1><i class="fas fa-vial"></i> Автоматизированное тестирование системы</h1>
            
            <div class="status-grid">
                <div class="status-item <?php echo $python_available ? 'ok' : 'error'; ?>">
                    <h3>Python 3</h3>
                    <p><?php echo $python_available ? '✓ Доступно' : '✗ Недоступно'; ?></p>
                    <?php if ($python_version): ?>
                    <small><?php echo $python_version; ?></small>
                    <?php endif; ?>
                </div>
                
                <div class="status-item <?php echo $selenium_available ? 'ok' : 'error'; ?>">
                    <h3>Selenium</h3>
                    <p><?php echo $selenium_available ? '✓ Установлен' : '✗ Не установлен'; ?></p>
                </div>
                
                <div class="status-item ok">
                    <h3>Система управления</h3>
                    <p>✓ Готова к тестированию</p>
                </div>
            </div>
            
            <h3>Запуск тестов:</h3>
            <div>
                <a href="index.php" class="test-button">
                    <i class="fas fa-arrow-left"></i> Вернуться в систему
                </a>
                
                <?php if ($python_available && $selenium_available): ?>
                <a href="run_tests.php" class="test-button" onclick="return confirm('Запустить автоматические тесты?')">
                    <i class="fas fa-play"></i> Запустить все тесты
                </a>
                <?php else: ?>
                <button class="test-button" disabled>
                    <i class="fas fa-times"></i> Недоступно (установите зависимости)
                </button>
                <?php endif; ?>
            </div>
            
            <div class="test-results" id="testResults">
                <h3>Результаты тестирования:</h3>
                <p>Для просмотра результатов запустите тесты.</p>
            </div>
        </div>
        
        <div class="card">
            <h2><i class="fas fa-info-circle"></i> Инструкция по установке</h2>
            
            <h3>Для Ubuntu/Debian:</h3>
            <pre>
# 1. Установить Python3 и pip
sudo apt update
sudo apt install python3 python3-pip

# 2. Установить зависимости
pip3 install selenium webdriver-manager

# 3. Установить Chrome
sudo apt install google-chrome-stable

# 4. Установить ChromeDriver
sudo apt install chromium-chromedriver
            </pre>
            
            <h3>Для Windows:</h3>
            <pre>
# 1. Установить Python с python.org
# 2. Установить зависимости в командной строке:
pip install selenium webdriver-manager

# 3. Установить Chrome браузер
# 4. ChromeDriver установится автоматически
            </pre>
            
            <h3>Для запуска тестов вручную:</h3>
            <pre>
cd /путь/к/проекту
chmod +x run_tests.sh
./run_tests.sh
            </pre>
        </div>
    </div>
    
    <script>
        // Автоматическое обновление статуса
        function checkTestStatus() {
            fetch('check_tests.php')
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'running') {
                        document.getElementById('testResults').innerHTML = 
                            '<h3>Тестирование выполняется...</h3>' +
                            '<p>' + data.message + '</p>';
                        setTimeout(checkTestStatus, 2000);
                    } else if (data.status === 'completed') {
                        document.getElementById('testResults').innerHTML = 
                            '<h3>Результаты тестирования:</h3>' +
                            '<p>' + data.message + '</p>' +
                            '<pre>' + data.output + '</pre>';
                    }
                });
        }
        
        // Если есть параметр запуска тестов
        if (window.location.search.includes('run_tests')) {
            checkTestStatus();
        }
    </script>
</body>
</html>