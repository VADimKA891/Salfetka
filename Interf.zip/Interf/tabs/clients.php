<?php
/**
 * ВКЛАДКА: УПРАВЛЕНИЕ КЛИЕНТАМИ
 * Операции с недвижимостью
 */

// Получение данных клиентов
$clients = [];
$clients_total_value = 0;
if ($conn_global) {
    $clients = getClients($conn_global);
    $clients_total_value = calculateClientsTotalValue($conn_global);
}
?>

<div id="clients" class="tab-content <?php echo $current_tab == 'clients' ? 'active' : ''; ?>">
    <div class="tab-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px;">
        <h2><i class="fas fa-users"></i> Управление клиентами</h2>
        <div class="tab-actions">
            <button onclick="showAddClientModal()" class="btn btn-purple">
                <i class="fas fa-user-plus"></i> Добавить клиента
            </button>
        </div>
    </div>
    
    <!-- Статистика клиентов -->
    <div class="stat-grid">
        <div class="stat-card">
            <i class="fas fa-users"></i>
            <h3><?php echo count($clients); ?></h3>
            <p>Всего клиентов</p>
        </div>
        <div class="stat-card">
            <i class="fas fa-money-bill-wave"></i>
            <h3><?php echo formatPrice($clients_total_value); ?></h3>
            <p>Общий бюджет</p>
        </div>
        <div class="stat-card">
            <i class="fas fa-star"></i>
            <h3><?php echo count(array_filter($clients, function($c) { return !empty($c['is_vip']) && $c['is_vip']; })); ?></h3>
            <p>VIP клиентов</p>
        </div>
        <div class="stat-card">
            <i class="fas fa-home"></i>
            <h3><?php echo array_sum(array_column($clients, 'property_count')); ?></h3>
            <p>Объектов у клиентов</p>
        </div>
    </div>
    
    <!-- Таблица клиентов -->
    <div class="table-section">
        <h3 style="margin-bottom: 20px;">Список клиентов</h3>
        
        <?php if ($conn_global): ?>
            <?php if (!empty($clients)): ?>
                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>ФИО</th>
                                <th>Контактная информация</th>
                                <th>Бюджет</th>
                                <th>Статус</th>
                                <th>Объектов</th>
                                <th>Дата регистрации</th>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($clients as $client): ?>
                            <tr>
                                <td><?php echo $client['id']; ?></td>
                                <td>
                                    <strong><?php echo sanitize($client['full_name']); ?></strong>
                                    <?php if (!empty($client['is_vip']) && $client['is_vip']): ?>
                                    <span style="color: gold; margin-left: 5px;"><i class="fas fa-crown"></i></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div><i class="fas fa-phone"></i> <?php echo sanitize($client['phone']); ?></div>
                                    <div><i class="fas fa-envelope"></i> <?php echo sanitize($client['email']); ?></div>
                                </td>
                                <td><?php echo formatPrice($client['budget']); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo $client['status']; ?>">
                                        <?php echo getClientStatus($client['status']); ?>
                                    </span>
                                </td>
                                <td><?php echo $client['property_count']; ?></td>
                                <td><?php echo formatDate($client['created_at']); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button onclick="viewClient(<?php echo $client['id']; ?>)" class="btn btn-sm btn-purple">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button onclick="editClient(<?php echo $client['id']; ?>)" class="btn btn-sm btn-purple">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button onclick="deleteClient(<?php echo $client['id']; ?>)" class="btn btn-sm btn-purple" style="background: #f44336;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="glass-card" style="text-align: center; padding: 50px;">
                    <i class="fas fa-users fa-3x" style="color: #ccc; margin-bottom: 20px;"></i>
                    <h3>Клиентов не найдено</h3>
                    <p>Добавьте первого клиента в систему</p>
                    <button onclick="showAddClientModal()" class="btn btn-purple" style="margin-top: 20px;">
                        <i class="fas fa-user-plus"></i> Добавить клиента
                    </button>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="glass-card error" style="background: #f8d7da; color: #721c24; border-left: 4px solid #f44336;">
                <i class="fas fa-exclamation-triangle"></i>
                <strong>Ошибка подключения к базе данных</strong>
                <p>Невозможно загрузить данные клиентов</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Модальное окно добавления клиента -->
<div id="addClientModal" class="modal-overlay">
    <div class="modal-content">
        <h3><i class="fas fa-user-plus"></i> Добавление нового клиента</h3>
        <form id="clientForm" method="POST" action="?tab=clients">
            <input type="hidden" name="action" value="add_client">
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 20px;">
                <div class="form-group">
                    <label>ФИО *</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Телефон *</label>
                    <input type="tel" name="phone" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control">
                </div>
                <div class="form-group">
                    <label>Бюджет (₽)</label>
                    <input type="number" name="budget" class="form-control" min="0" step="1000">
                </div>
                <div class="form-group" style="grid-column: span 2;">
                    <label>Предпочтения</label>
                    <textarea name="preferences" class="form-control" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label>Статус</label>
                    <select name="status" class="form-control">
                        <option value="active">Активен</option>
                        <option value="inactive">Неактивен</option>
                        <option value="potential">Потенциальный</option>
                    </select>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="is_vip"> VIP клиент
                    </label>
                </div>
            </div>
            
            <div style="display: flex; gap: 15px; justify-content: flex-end;">
                <button type="button" onclick="closeModal('addClientModal')" class="btn btn-purple" style="background: #6c757d;">
                    Отмена
                </button>
                <button type="submit" class="btn btn-purple">
                    <i class="fas fa-save"></i> Сохранить клиента
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Функции для работы с клиентами
function showAddClientModal() {
    document.getElementById('addClientModal').style.display = 'flex';
    document.body.style.overflow = 'hidden';
}

function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
    document.body.style.overflow = 'auto';
}

function viewClient(clientId) {
    alert('Просмотр клиента ID: ' + clientId);
}

function editClient(clientId) {
    alert('Редактирование клиента ID: ' + clientId);
}

function deleteClient(clientId) {
    if (confirm('Вы уверены, что хотите удалить клиента?')) {
        window.location.href = 'request_handler.php?delete_client=' + clientId;
    }
}

window.onclick = function(event) {
    const modals = document.querySelectorAll('.modal-overlay');
    modals.forEach(modal => {
        if (event.target === modal) {
            closeModal(modal.id);
        }
    });
}
</script>