<?php
/**
 * ПРОВЕРКА СТАТУСА ТЕСТОВ
 */

$status_file = __DIR__ . '/test_status.json';

if (file_exists($status_file)) {
    $status = json_decode(file_get_contents($status_file), true);
} else {
    $status = [
        'status' => 'idle',
        'message' => 'Тесты не запущены'
    ];
}

header('Content-Type: application/json');
echo json_encode($status);
?>