<?php
/**
 * ФУНКЦИИ ДЛЯ РАБОТЫ С БАЗАМИ ДАННЫХ
 * Двойная база данных - Глобальная + Локальная
 */

require_once 'config.php';

/**
 * Логирование событий (временная реализация, если нет в config.php)
 */
if (!function_exists('logEvent')) {
    function logEvent($message, $level = "INFO", $category = "application") {
        // Простая реализация - запись в файл
        $log_file = __DIR__ . '/app.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] [$level] [$category] $message\n";
        file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);
        
        // Дополнительный вывод в консоль для отладки
        if (defined('APP_DEBUG') && APP_DEBUG && php_sapi_name() === 'cli') {
            echo $log_message;
        }
    }
}

// Остальной код файла...

/**
 * Подключение к глобальной базе данных
 */
function connectToGlobalDatabase() {
    try {
        $connection = new mysqli(
            DB_GLOBAL_HOST, 
            DB_GLOBAL_USER, 
            DB_GLOBAL_PASS_REAL, 
            DB_GLOBAL_NAME
        );
        
        if ($connection->connect_error) {
            throw new Exception("Ошибка подключения к глобальной БД: " . $connection->connect_error);
        }
        
        $connection->set_charset("utf8mb4");
        logEvent("Успешное подключение к глобальной БД", "INFO", "database");
        return $connection;
        
    } catch (Exception $e) {
        logEvent("Ошибка подключения к глобальной БД: " . $e->getMessage(), "ERROR", "database");
        throw $e;
    }
}

/**
 * Подключение к локальной базе данных
 */
function connectToLocalDatabase() {
    try {
        // Сначала пытаемся подключиться к серверу
        $connection = new mysqli(
            DB_LOCAL_HOST, 
            DB_LOCAL_USER, 
            DB_LOCAL_PASS_REAL
        );
        
        if ($connection->connect_error) {
            throw new Exception("Ошибка подключения к локальному серверу: " . $connection->connect_error);
        }
        
        // Пытаемся выбрать базу данных
        if (!$connection->select_db(DB_LOCAL_NAME)) {
            // Создаем базу данных если не существует
            $create_db = $connection->query("CREATE DATABASE IF NOT EXISTS " . DB_LOCAL_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            if (!$create_db) {
                throw new Exception("Не удалось создать базу данных: " . $connection->error);
            }
            $connection->select_db(DB_LOCAL_NAME);
        }
        
        $connection->set_charset("utf8mb4");
        logEvent("Успешное подключение к локальной БД", "INFO", "database");
        return $connection;
        
    } catch (Exception $e) {
        logEvent("Ошибка подключения к локальной БД: " . $e->getMessage(), "ERROR", "database");
        throw $e;
    }
}

/**
 * Создание основных таблиц в глобальной БД
 */
function initGlobalDatabase($connection) {
    try {
        // Таблица объектов недвижимости
        $sql = "CREATE TABLE IF NOT EXISTS properties (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            address VARCHAR(500),
            price DECIMAL(12,2),
            area DECIMAL(8,2),
            rooms INT,
            bathrooms INT,
            property_type VARCHAR(50),
            status VARCHAR(20) DEFAULT 'available',
            client_id INT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $connection->query($sql);
        
        // Таблица клиентов
        $sql = "CREATE TABLE IF NOT EXISTS clients (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(200) NOT NULL,
            phone VARCHAR(20),
            email VARCHAR(100),
            budget DECIMAL(12,2),
            preferences TEXT,
            status VARCHAR(20) DEFAULT 'active',
            is_vip BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $connection->query($sql);
        
        // Таблица агентов
        $sql = "CREATE TABLE IF NOT EXISTS agents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(200) NOT NULL,
            phone VARCHAR(20),
            email VARCHAR(100),
            commission_rate DECIMAL(5,2),
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $connection->query($sql);
        
        // Таблица договоров
        $sql = "CREATE TABLE IF NOT EXISTS contracts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            client_id INT,
            agent_id INT,
            property_id INT,
            contract_type VARCHAR(50),
            amount DECIMAL(12,2),
            contract_date DATE,
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        $connection->query($sql);
        
        // Проверяем, есть ли тестовые данные в таблице properties
        $result = $connection->query("SELECT COUNT(*) as count FROM properties");
        $row = $result->fetch_assoc();
        
        if ($row['count'] == 0) {
            // Добавляем тестовые данные
            $test_data = [
                ['Квартира в центре Москвы', 'Просторная 3-комнатная квартира с евроремонтом', 'ул. Тверская, 10', 25000000, 85.5, 3, 2, 'apartment', 'available'],
                ['Загородный дом в Подмосковье', 'Кирпичный дом на участке 10 соток', 'пос. Дачный, 25', 15000000, 120, 4, 3, 'house', 'available'],
                ['Офисное помещение', 'Офис класса А с отдельным входом', 'ул. Ленинградская, 35', 50000, 65, 0, 1, 'commercial', 'rented']
            ];
            
            $stmt = $connection->prepare("INSERT INTO properties (title, description, address, price, area, rooms, bathrooms, property_type, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            foreach ($test_data as $data) {
                $stmt->bind_param("sssddiiss", $data[0], $data[1], $data[2], $data[3], $data[4], $data[5], $data[6], $data[7], $data[8]);
                $stmt->execute();
            }
        }
        
        // Проверяем тестовые данные в таблице clients
        $result = $connection->query("SELECT COUNT(*) as count FROM clients");
        $row = $result->fetch_assoc();
        
        if ($row['count'] == 0) {
            // Добавляем тестовых клиентов
            $test_clients = [
                ['Иванов Иван Иванович', '+7 (999) 123-45-67', 'ivanov@example.com', 50000000, 'Ищет квартиру в центре', 'active', 1],
                ['Петрова Мария Сергеевна', '+7 (999) 987-65-43', 'petrova@example.com', 35000000, 'Интересует загородный дом', 'active', 0],
                ['Сидоров Алексей Владимирович', '+7 (999) 456-78-90', 'sidorov@example.com', 100000000, 'Коммерческая недвижимость', 'potential', 1]
            ];
            
            $stmt = $connection->prepare("INSERT INTO clients (full_name, phone, email, budget, preferences, status, is_vip) VALUES (?, ?, ?, ?, ?, ?, ?)");
            
            foreach ($test_clients as $client) {
                $stmt->bind_param("sssdssi", $client[0], $client[1], $client[2], $client[3], $client[4], $client[5], $client[6]);
                $stmt->execute();
            }
        }
        
        // Проверяем тестовые данные в таблице agents
        $result = $connection->query("SELECT COUNT(*) as count FROM agents");
        $row = $result->fetch_assoc();
        
        if ($row['count'] == 0) {
            // Добавляем тестовых агентов
            $test_agents = [
                ['Смирнова Ольга Петровна', '+7 (999) 111-22-33', 'smirnova@example.com', 3.5, 'active'],
                ['Кузнецов Дмитрий Алексеевич', '+7 (999) 222-33-44', 'kuznetsov@example.com', 4.0, 'active'],
                ['Васильева Анна Игоревна', '+7 (999) 333-44-55', 'vasileva@example.com', 3.0, 'inactive']
            ];
            
            $stmt = $connection->prepare("INSERT INTO agents (full_name, phone, email, commission_rate, status) VALUES (?, ?, ?, ?, ?)");
            
            foreach ($test_agents as $agent) {
                $stmt->bind_param("sssds", $agent[0], $agent[1], $agent[2], $agent[3], $agent[4]);
                $stmt->execute();
            }
        }
        
        logEvent("База данных успешно инициализирована", "INFO", "database");
        return true;
        
    } catch (Exception $e) {
        logEvent("Ошибка инициализации БД: " . $e->getMessage(), "ERROR", "database");
        throw $e;
    }
}

/**
 * Получение объектов из глобальной БД
 */
function getGlobalProperties($connection) {
    $properties = [];
    $sql = "SELECT * FROM properties ORDER BY id DESC";
    $result = $connection->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $properties[] = $row;
        }
    }
    
    return $properties;
}

/**
 * Получение списка таблиц из локальной БД
 */
function getLocalTables($connection) {
    $tables = [];
    $result = $connection->query("SHOW TABLES");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    }
    
    return $tables;
}

/**
 * Получение количества клиентов
 */
function getClientsCount($connection) {
    if (!$connection) return 0;
    
    $result = $connection->query("SELECT COUNT(*) as count FROM clients");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    
    return 0;
}

/**
 * Получение количества агентов
 */
function getAgentsCount($connection) {
    if (!$connection) return 0;
    
    $result = $connection->query("SELECT COUNT(*) as count FROM agents");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    
    return 0;
}

/**
 * Получение количества договоров
 */
function getContractsCount($connection) {
    if (!$connection) return 0;
    
    $result = $connection->query("SELECT COUNT(*) as count FROM contracts");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    
    return 0;
}

/**
 * Получение статистики по глобальной БД
 */
function getGlobalStats($connection) {
    $stats = [];
    
    $result = $connection->query("SELECT COUNT(*) as total FROM properties");
    $stats['total_properties'] = $result->fetch_assoc()['total'];
    
    $result = $connection->query("SELECT COUNT(*) as available FROM properties WHERE status = 'available'");
    $stats['available_properties'] = $result->fetch_assoc()['available'];
    
    $result = $connection->query("SELECT SUM(price) as total_value FROM properties WHERE status = 'available'");
    $row = $result->fetch_assoc();
    $stats['total_value'] = $row['total_value'] ?: 0;
    
    $result = $connection->query("SELECT AVG(price) as avg_price FROM properties WHERE status = 'available'");
    $row = $result->fetch_assoc();
    $stats['avg_price'] = $row['avg_price'] ?: 0;
    
    $result = $connection->query("SELECT COUNT(*) as total FROM clients");
    $stats['total_clients'] = $result->fetch_assoc()['total'];
    
    $result = $connection->query("SELECT COUNT(*) as total FROM agents");
    $stats['total_agents'] = $result->fetch_assoc()['total'];
    
    $result = $connection->query("SELECT COUNT(*) as total FROM contracts");
    $stats['total_contracts'] = $result->fetch_assoc()['total'];
    
    return $stats;
}

/**
 * Получение статистики по локальной БД
 */
function getLocalStats($connection) {
    $stats = [];
    
    $result = $connection->query("SELECT COUNT(*) as total FROM information_schema.tables WHERE table_schema = DATABASE()");
    $stats['total_tables'] = $result->fetch_assoc()['total'];
    
    $result = $connection->query("SELECT SUM(data_length + index_length) / 1024 / 1024 as size_mb FROM information_schema.tables WHERE table_schema = DATABASE()");
    $row = $result->fetch_assoc();
    $stats['db_size_mb'] = round($row['size_mb'] ?? 0, 2);
    
    return $stats;
}

/**
 * Создание таблицы в локальной БД
 */
function createLocalTable($connection, $table_name) {
    $table_name = $connection->real_escape_string($table_name);
    
    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id INT AUTO_INCREMENT PRIMARY KEY,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    
    return $connection->query($sql);
}

/**
 * Удаление таблицы из локальной БД
 */
function dropLocalTable($connection, $table_name) {
    $table_name = $connection->real_escape_string($table_name);
    return $connection->query("DROP TABLE IF EXISTS $table_name");
}

/**
 * Получение структуры таблицы из локальной БД
 */
function getLocalTableStructure($connection, $table_name) {
    $structure = [];
    $table_name = $connection->real_escape_string($table_name);
    $result = $connection->query("DESCRIBE $table_name");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $structure[] = $row;
        }
    }
    
    return $structure;
}

/**
 * Получение данных из таблицы локальной БД
 */
function getLocalTableData($connection, $table_name, $limit = 50) {
    $data = [];
    $table_name = $connection->real_escape_string($table_name);
    $result = $connection->query("SELECT * FROM $table_name LIMIT $limit");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    return $data;
}

/**
 * Добавление столбца в таблицу локальной БД
 */
function addColumnToLocalTable($connection, $table_name, $column_name, $column_type, $column_length = null) {
    $table_name = $connection->real_escape_string($table_name);
    $column_name = $connection->real_escape_string($column_name);
    
    $length_str = $column_length ? "($column_length)" : "";
    $sql = "ALTER TABLE $table_name ADD COLUMN $column_name $column_type$length_str";
    
    return $connection->query($sql);
}

/**
 * Удаление столбца из таблицы локальной БД
 */
function dropColumnFromLocalTable($connection, $table_name, $column_name) {
    $table_name = $connection->real_escape_string($table_name);
    $column_name = $connection->real_escape_string($column_name);
    
    $sql = "ALTER TABLE $table_name DROP COLUMN $column_name";
    return $connection->query($sql);
}

/**
 * Получение клиентов из БД
 */
function getClients($connection) {
    $clients = [];
    $sql = "SELECT c.*, COUNT(p.id) as property_count 
            FROM clients c 
            LEFT JOIN properties p ON c.id = p.client_id 
            GROUP BY c.id 
            ORDER BY c.created_at DESC";
    
    $result = $connection->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $clients[] = $row;
        }
    }
    
    return $clients;
}

/**
 * Получение агентов из БД
 */
function getAgents($connection) {
    $agents = [];
    $sql = "SELECT a.*, 
            COUNT(DISTINCT c.id) as client_count, 
            COUNT(DISTINCT p.id) as property_count,
            SUM(CASE WHEN ct.status = 'completed' THEN ct.amount * a.commission_rate / 100 ELSE 0 END) as total_commission
            FROM agents a 
            LEFT JOIN contracts ct ON a.id = ct.agent_id
            LEFT JOIN clients c ON ct.client_id = c.id
            LEFT JOIN properties p ON ct.property_id = p.id
            GROUP BY a.id 
            ORDER BY a.created_at DESC";
    
    $result = $connection->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $agents[] = $row;
        }
    }
    
    return $agents;
}

/**
 * Получение договоров из БД
 */
function getContracts($connection) {
    $contracts = [];
    $sql = "SELECT ct.*, 
            c.full_name as client_name, 
            a.full_name as agent_name,
            p.title as property_title
            FROM contracts ct
            LEFT JOIN clients c ON ct.client_id = c.id
            LEFT JOIN agents a ON ct.agent_id = a.id
            LEFT JOIN properties p ON ct.property_id = p.id
            ORDER BY ct.contract_date DESC, ct.created_at DESC";
    
    $result = $connection->query($sql);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $contracts[] = $row;
        }
    }
    
    return $contracts;
}

/**
 * Получение информации о клиенте по ID
 */
function getClientById($connection, $client_id) {
    $sql = "SELECT * FROM clients WHERE id = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("i", $client_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

/**
 * Добавление нового клиента
 */
function addClient($connection, $data) {
    $sql = "INSERT INTO clients (full_name, phone, email, budget, preferences, status, is_vip) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("sssdssi", 
        $data['full_name'],
        $data['phone'],
        $data['email'],
        $data['budget'],
        $data['preferences'],
        $data['status'],
        $data['is_vip']
    );
    
    return $stmt->execute();
}

/**
 * Обновление клиента
 */
function updateClient($connection, $client_id, $data) {
    $sql = "UPDATE clients SET 
            full_name = ?, 
            phone = ?, 
            email = ?, 
            budget = ?, 
            preferences = ?, 
            status = ?, 
            is_vip = ?,
            updated_at = CURRENT_TIMESTAMP
            WHERE id = ?";
    
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("sssdssii", 
        $data['full_name'],
        $data['phone'],
        $data['email'],
        $data['budget'],
        $data['preferences'],
        $data['status'],
        $data['is_vip'],
        $client_id
    );
    
    return $stmt->execute();
}

/**
 * Удаление клиента
 */
function deleteClient($connection, $client_id) {
    $sql = "DELETE FROM clients WHERE id = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("i", $client_id);
    
    return $stmt->execute();
}
?>