<?php
/**
 * ФУНКЦИИ ДЛЯ РАБОТЫ С БАЗАМИ ДАННЫХ
 * Операции с недвижимостью
 */

require_once 'config.php';

if (!function_exists('logEvent')) {
    function logEvent($message, $level = "INFO", $category = "application") {
        $log_file = __DIR__ . '/app.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_message = "[$timestamp] [$level] [$category] $message\n";
        file_put_contents($log_file, $log_message, FILE_APPEND | LOCK_EX);
        if (defined('APP_DEBUG') && APP_DEBUG && php_sapi_name() === 'cli') {
            echo $log_message;
        }
    }
}

// ============================================
// ПОДКЛЮЧЕНИЕ К БАЗАМ ДАННЫХ
// ============================================

function connectToGlobalDatabase() {
    try {
        $connection = new mysqli(
            DB_GLOBAL_HOST, 
            DB_GLOBAL_USER, 
            DB_GLOBAL_PASS_REAL, 
            DB_GLOBAL_NAME
        );
        if ($connection->connect_error) {
            throw new Exception("Ошибка подключения к глобальной БД: " . $connection->connect_error);
        }
        $connection->set_charset("utf8mb4");
        logEvent("Успешное подключение к глобальной БД", "INFO", "database");
        return $connection;
    } catch (Exception $e) {
        logEvent("Ошибка подключения к глобальной БД: " . $e->getMessage(), "ERROR", "database");
        throw $e;
    }
}

function connectToLocalDatabase() {
    try {
        $connection = new mysqli(
            DB_LOCAL_HOST, 
            DB_LOCAL_USER, 
            DB_LOCAL_PASS_REAL
        );
        if ($connection->connect_error) {
            throw new Exception("Ошибка подключения к локальному серверу: " . $connection->connect_error);
        }
        if (!$connection->select_db(DB_LOCAL_NAME)) {
            $create_db = $connection->query("CREATE DATABASE IF NOT EXISTS " . DB_LOCAL_NAME . " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
            if (!$create_db) {
                throw new Exception("Не удалось создать базу данных: " . $connection->error);
            }
            $connection->select_db(DB_LOCAL_NAME);
        }
        $connection->set_charset("utf8mb4");
        logEvent("Успешное подключение к локальной БД", "INFO", "database");
        return $connection;
    } catch (Exception $e) {
        logEvent("Ошибка подключения к локальной БД: " . $e->getMessage(), "ERROR", "database");
        throw $e;
    }
}

// ============================================
// ИНИЦИАЛИЗАЦИЯ ГЛОБАЛЬНОЙ БД (ТАБЛИЦЫ + ТЕСТОВЫЕ ДАННЫЕ)
// ============================================

function initGlobalDatabase($connection) {
    try {
        // Таблица объектов недвижимости
        $sql = "CREATE TABLE IF NOT EXISTS properties (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(200) NOT NULL,
            description TEXT,
            address VARCHAR(500),
            price DECIMAL(12,2),
            area DECIMAL(8,2),
            rooms INT,
            bathrooms INT,
            property_type VARCHAR(50),
            status VARCHAR(20) DEFAULT 'available',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $connection->query($sql);
        
        // Таблица клиентов
        $sql = "CREATE TABLE IF NOT EXISTS clients (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(200) NOT NULL,
            phone VARCHAR(20),
            email VARCHAR(100),
            budget DECIMAL(12,2),
            preferences TEXT,
            status VARCHAR(20) DEFAULT 'active',
            is_vip BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $connection->query($sql);
        
        // Таблица агентов
        $sql = "CREATE TABLE IF NOT EXISTS agents (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(200) NOT NULL,
            phone VARCHAR(20),
            email VARCHAR(100),
            commission_rate DECIMAL(5,2),
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $connection->query($sql);
        
        // Таблица договоров
        $sql = "CREATE TABLE IF NOT EXISTS contracts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            client_id INT,
            agent_id INT,
            property_id INT,
            contract_type VARCHAR(50),
            amount DECIMAL(12,2),
            contract_date DATE,
            status VARCHAR(20) DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE SET NULL,
            FOREIGN KEY (agent_id) REFERENCES agents(id) ON DELETE SET NULL,
            FOREIGN KEY (property_id) REFERENCES properties(id) ON DELETE SET NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        $connection->query($sql);
        
        // --- ТЕСТОВЫЕ ДАННЫЕ: ОБЪЕКТЫ ---
        $result = $connection->query("SELECT COUNT(*) as count FROM properties");
        $row = $result->fetch_assoc();
        if ($row['count'] == 0) {
            $test_data = [
                ['Квартира в центре Москвы', 'Просторная 3-комнатная квартира с евроремонтом', 'ул. Тверская, 10', 25000000, 85.5, 3, 2, 'apartment', 'available'],
                ['Загородный дом в Подмосковье', 'Кирпичный дом на участке 10 соток', 'пос. Дачный, 25', 15000000, 120, 4, 3, 'house', 'available'],
                ['Офисное помещение', 'Офис класса А с отдельным входом', 'ул. Ленинградская, 35', 50000000, 65, 0, 1, 'commercial', 'rented'],
                ['Земельный участок', 'Участок под ИЖС, коммуникации рядом', 'СНТ Берёзка, уч. 12', 3500000, 15, 0, 0, 'land', 'available']
            ];
            $stmt = $connection->prepare("INSERT INTO properties (title, description, address, price, area, rooms, bathrooms, property_type, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            foreach ($test_data as $data) {
                $stmt->bind_param("sssddiiss", $data[0], $data[1], $data[2], $data[3], $data[4], $data[5], $data[6], $data[7], $data[8]);
                $stmt->execute();
            }
        }
        
        // --- ТЕСТОВЫЕ ДАННЫЕ: КЛИЕНТЫ ---
        $result = $connection->query("SELECT COUNT(*) as count FROM clients");
        $row = $result->fetch_assoc();
        if ($row['count'] == 0) {
            $test_clients = [
                ['Иванов Иван Иванович', '+7 (999) 123-45-67', 'ivanov@example.com', 50000000, 'Ищет квартиру в центре', 'active', 1],
                ['Петрова Мария Сергеевна', '+7 (999) 987-65-43', 'petrova@example.com', 35000000, 'Интересует загородный дом', 'active', 0],
                ['Сидоров Алексей Владимирович', '+7 (999) 456-78-90', 'sidorov@example.com', 100000000, 'Коммерческая недвижимость', 'potential', 1],
                ['Козлова Елена Дмитриевна', '+7 (999) 222-33-44', 'kozlova@example.com', 7000000, 'Земельный участок', 'active', 0]
            ];
            $stmt = $connection->prepare("INSERT INTO clients (full_name, phone, email, budget, preferences, status, is_vip) VALUES (?, ?, ?, ?, ?, ?, ?)");
            foreach ($test_clients as $client) {
                $stmt->bind_param("sssdssi", $client[0], $client[1], $client[2], $client[3], $client[4], $client[5], $client[6]);
                $stmt->execute();
            }
        }
        
        // --- ТЕСТОВЫЕ ДАННЫЕ: АГЕНТЫ ---
        $result = $connection->query("SELECT COUNT(*) as count FROM agents");
        $row = $result->fetch_assoc();
        if ($row['count'] == 0) {
            $test_agents = [
                ['Смирнова Ольга Петровна', '+7 (999) 111-22-33', 'smirnova@example.com', 3.5, 'active'],
                ['Кузнецов Дмитрий Алексеевич', '+7 (999) 222-33-44', 'kuznetsov@example.com', 4.0, 'active'],
                ['Васильева Анна Игоревна', '+7 (999) 333-44-55', 'vasileva@example.com', 3.0, 'inactive']
            ];
            $stmt = $connection->prepare("INSERT INTO agents (full_name, phone, email, commission_rate, status) VALUES (?, ?, ?, ?, ?)");
            foreach ($test_agents as $agent) {
                $stmt->bind_param("sssds", $agent[0], $agent[1], $agent[2], $agent[3], $agent[4]);
                $stmt->execute();
            }
        }
        
        // --- ТЕСТОВЫЕ ДАННЫЕ: ДОГОВОРЫ ---
        $result = $connection->query("SELECT COUNT(*) as count FROM contracts");
        $row = $result->fetch_assoc();
        if ($row['count'] == 0) {
            // Получим ID существующих записей
            $clients_res = $connection->query("SELECT id FROM clients LIMIT 3");
            $clients_ids = [];
            while ($c = $clients_res->fetch_assoc()) $clients_ids[] = $c['id'];
            
            $agents_res = $connection->query("SELECT id FROM agents LIMIT 3");
            $agents_ids = [];
            while ($a = $agents_res->fetch_assoc()) $agents_ids[] = $a['id'];
            
            $props_res = $connection->query("SELECT id, price FROM properties LIMIT 3");
            $props = [];
            while ($p = $props_res->fetch_assoc()) $props[] = $p;
            
            if (!empty($clients_ids) && !empty($agents_ids) && !empty($props)) {
                $test_contracts = [
                    [
                        'client_id' => $clients_ids[0],
                        'agent_id'  => $agents_ids[0],
                        'property_id' => $props[0]['id'],
                        'contract_type' => 'Купля-продажа',
                        'amount' => $props[0]['price'] * 0.95,
                        'contract_date' => date('Y-m-d', strtotime('-5 days')),
                        'status' => 'active'
                    ],
                    [
                        'client_id' => $clients_ids[1] ?? $clients_ids[0],
                        'agent_id'  => $agents_ids[1] ?? $agents_ids[0],
                        'property_id' => $props[1]['id'],
                        'contract_type' => 'Аренда',
                        'amount' => round($props[1]['price'] * 0.1 / 12, 0),
                        'contract_date' => date('Y-m-d', strtotime('-10 days')),
                        'status' => 'active'
                    ],
                    [
                        'client_id' => $clients_ids[2] ?? $clients_ids[0],
                        'agent_id'  => $agents_ids[2] ?? $agents_ids[0],
                        'property_id' => $props[2]['id'],
                        'contract_type' => 'Купля-продажа',
                        'amount' => $props[2]['price'],
                        'contract_date' => date('Y-m-d', strtotime('-20 days')),
                        'status' => 'completed'
                    ]
                ];
                
                $stmt = $connection->prepare("INSERT INTO contracts (client_id, agent_id, property_id, contract_type, amount, contract_date, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
                foreach ($test_contracts as $c) {
                    $stmt->bind_param("iiisdss", 
                        $c['client_id'], 
                        $c['agent_id'], 
                        $c['property_id'], 
                        $c['contract_type'], 
                        $c['amount'], 
                        $c['contract_date'], 
                        $c['status']
                    );
                    $stmt->execute();
                }
                logEvent("Добавлены тестовые договоры", "INFO", "database");
            }
        }
        
        logEvent("База данных успешно инициализирована", "INFO", "database");
        return true;
        
    } catch (Exception $e) {
        logEvent("Ошибка инициализации БД: " . $e->getMessage(), "ERROR", "database");
        throw $e;
    }
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С ОБЪЕКТАМИ НЕДВИЖИМОСТИ
// ============================================

function getGlobalProperties($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении объектов", "ERROR", "database");
        return [];
    }
    $properties = [];
    $sql = "SELECT * FROM properties ORDER BY id DESC";
    $result = $connection->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $properties[] = $row;
        }
    }
    return $properties;
}

function getGlobalStats($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении статистики", "ERROR", "database");
        return [];
    }
    $stats = [];
    $result = $connection->query("SELECT COUNT(*) as total FROM properties");
    $stats['total_properties'] = $result->fetch_assoc()['total'];
    $result = $connection->query("SELECT COUNT(*) as available FROM properties WHERE status = 'available'");
    $stats['available_properties'] = $result->fetch_assoc()['available'];
    $result = $connection->query("SELECT SUM(price) as total_value FROM properties WHERE status = 'available'");
    $row = $result->fetch_assoc();
    $stats['total_value'] = $row['total_value'] ?: 0;
    $result = $connection->query("SELECT AVG(price) as avg_price FROM properties WHERE status = 'available'");
    $row = $result->fetch_assoc();
    $stats['avg_price'] = $row['avg_price'] ?: 0;
    $result = $connection->query("SELECT COUNT(*) as total FROM clients");
    $stats['total_clients'] = $result->fetch_assoc()['total'];
    $result = $connection->query("SELECT COUNT(*) as total FROM agents");
    $stats['total_agents'] = $result->fetch_assoc()['total'];
    $result = $connection->query("SELECT COUNT(*) as total FROM contracts");
    $stats['total_contracts'] = $result->fetch_assoc()['total'];
    return $stats;
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С КЛИЕНТАМИ
// ============================================

function getClients($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении клиентов", "ERROR", "database");
        return [];
    }
    $clients = [];
    $column_check = $connection->query("SHOW COLUMNS FROM properties LIKE 'client_id'");
    $has_client_id_column = $column_check && $column_check->num_rows > 0;
    if ($has_client_id_column) {
        $sql = "SELECT c.*, COUNT(p.id) as property_count 
                FROM clients c 
                LEFT JOIN properties p ON c.id = p.client_id 
                GROUP BY c.id 
                ORDER BY c.created_at DESC";
    } else {
        $sql = "SELECT c.*, 0 as property_count 
                FROM clients c 
                ORDER BY c.created_at DESC";
    }
    $result = $connection->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $clients[] = $row;
        }
    }
    return $clients;
}

function getClientsCount($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return 0;
    }
    $result = $connection->query("SELECT COUNT(*) as count FROM clients");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    return 0;
}

function getClientById($connection, $client_id) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении клиента по ID", "ERROR", "database");
        return null;
    }
    $sql = "SELECT * FROM clients WHERE id = ?";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return null;
    $stmt->bind_param("i", $client_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function addClient($connection, $data) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при добавлении клиента", "ERROR", "database");
        return false;
    }
    $sql = "INSERT INTO clients (full_name, phone, email, budget, preferences, status, is_vip) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("sssdssi", 
        $data['full_name'],
        $data['phone'],
        $data['email'],
        $data['budget'],
        $data['preferences'],
        $data['status'],
        $data['is_vip']
    );
    return $stmt->execute();
}

function updateClient($connection, $client_id, $data) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при обновлении клиента", "ERROR", "database");
        return false;
    }
    $sql = "UPDATE clients SET 
            full_name = ?, 
            phone = ?, 
            email = ?, 
            budget = ?, 
            preferences = ?, 
            status = ?, 
            is_vip = ?,
            updated_at = CURRENT_TIMESTAMP
            WHERE id = ?";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("sssdssii", 
        $data['full_name'],
        $data['phone'],
        $data['email'],
        $data['budget'],
        $data['preferences'],
        $data['status'],
        $data['is_vip'],
        $client_id
    );
    return $stmt->execute();
}

function deleteClient($connection, $client_id) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при удалении клиента", "ERROR", "database");
        return false;
    }
    $sql = "DELETE FROM clients WHERE id = ?";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("i", $client_id);
    return $stmt->execute();
}

function getClientsList($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return [];
    }
    $clients = [];
    $result = $connection->query("SELECT id, full_name FROM clients ORDER BY full_name");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $clients[] = $row;
        }
    }
    return $clients;
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С АГЕНТАМИ
// ============================================

function getAgents($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении агентов", "ERROR", "database");
        return [];
    }
    $agents = [];
    $tables_exist = true;
    $check = $connection->query("SHOW TABLES LIKE 'contracts'");
    if (!$check || $check->num_rows == 0) {
        $tables_exist = false;
    }
    if ($tables_exist) {
        $sql = "SELECT a.*, 
                COUNT(DISTINCT c.id) as client_count, 
                COUNT(DISTINCT p.id) as property_count,
                SUM(CASE WHEN ct.status = 'completed' THEN ct.amount * a.commission_rate / 100 ELSE 0 END) as total_commission
                FROM agents a 
                LEFT JOIN contracts ct ON a.id = ct.agent_id
                LEFT JOIN clients c ON ct.client_id = c.id
                LEFT JOIN properties p ON ct.property_id = p.id
                GROUP BY a.id 
                ORDER BY a.created_at DESC";
    } else {
        $sql = "SELECT a.*, 0 as client_count, 0 as property_count, 0 as total_commission
                FROM agents a 
                ORDER BY a.created_at DESC";
    }
    $result = $connection->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $agents[] = $row;
        }
    }
    return $agents;
}

function getAgentsCount($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return 0;
    }
    $result = $connection->query("SELECT COUNT(*) as count FROM agents");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    return 0;
}

function getAgentsList($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return [];
    }
    $agents = [];
    $result = $connection->query("SELECT id, full_name FROM agents WHERE status = 'active' ORDER BY full_name");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $agents[] = $row;
        }
    }
    return $agents;
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С ДОГОВОРАМИ
// ============================================

function getContracts($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении договоров", "ERROR", "database");
        return [];
    }
    $contracts = [];
    $tables_exist = true;
    $check = $connection->query("SHOW TABLES LIKE 'clients'");
    if (!$check || $check->num_rows == 0) {
        $tables_exist = false;
    }
    if ($tables_exist) {
        $sql = "SELECT ct.*, 
                c.full_name as client_name, 
                a.full_name as agent_name,
                p.title as property_title
                FROM contracts ct
                LEFT JOIN clients c ON ct.client_id = c.id
                LEFT JOIN agents a ON ct.agent_id = a.id
                LEFT JOIN properties p ON ct.property_id = p.id
                ORDER BY ct.contract_date DESC, ct.created_at DESC";
    } else {
        $sql = "SELECT ct.*, 
                'Неизвестно' as client_name, 
                'Неизвестно' as agent_name,
                'Неизвестно' as property_title
                FROM contracts ct
                ORDER BY ct.contract_date DESC, ct.created_at DESC";
    }
    $result = $connection->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $contracts[] = $row;
        }
    }
    return $contracts;
}

function getContractsCount($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return 0;
    }
    $result = $connection->query("SELECT COUNT(*) as count FROM contracts");
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    return 0;
}

function getContractById($connection, $contract_id) {
    if (!$connection || !($connection instanceof mysqli)) {
        return null;
    }
    $sql = "SELECT ct.*, 
            c.full_name as client_name, 
            a.full_name as agent_name,
            p.title as property_title
            FROM contracts ct
            LEFT JOIN clients c ON ct.client_id = c.id
            LEFT JOIN agents a ON ct.agent_id = a.id
            LEFT JOIN properties p ON ct.property_id = p.id
            WHERE ct.id = ?";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return null;
    $stmt->bind_param("i", $contract_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

function addContract($connection, $data) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при добавлении договора", "ERROR", "database");
        return false;
    }
    $sql = "INSERT INTO contracts (client_id, agent_id, property_id, contract_type, amount, contract_date, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("iiisdss", 
        $data['client_id'],
        $data['agent_id'],
        $data['property_id'],
        $data['contract_type'],
        $data['amount'],
        $data['contract_date'],
        $data['status']
    );
    return $stmt->execute();
}

function updateContract($connection, $contract_id, $data) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при обновлении договора", "ERROR", "database");
        return false;
    }
    $sql = "UPDATE contracts SET 
            client_id = ?, 
            agent_id = ?, 
            property_id = ?, 
            contract_type = ?, 
            amount = ?, 
            contract_date = ?, 
            status = ?,
            updated_at = CURRENT_TIMESTAMP
            WHERE id = ?";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("iiisdssi", 
        $data['client_id'],
        $data['agent_id'],
        $data['property_id'],
        $data['contract_type'],
        $data['amount'],
        $data['contract_date'],
        $data['status'],
        $contract_id
    );
    return $stmt->execute();
}

function deleteContract($connection, $contract_id) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при удалении договора", "ERROR", "database");
        return false;
    }
    $sql = "DELETE FROM contracts WHERE id = ?";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return false;
    $stmt->bind_param("i", $contract_id);
    return $stmt->execute();
}

function getRecentContracts($connection, $limit = 5) {
    if (!$connection || !($connection instanceof mysqli)) {
        return [];
    }
    $contracts = [];
    $sql = "SELECT ct.*, 
            c.full_name as client_name, 
            a.full_name as agent_name,
            p.title as property_title
            FROM contracts ct
            LEFT JOIN clients c ON ct.client_id = c.id
            LEFT JOIN agents a ON ct.agent_id = a.id
            LEFT JOIN properties p ON ct.property_id = p.id
            ORDER BY ct.contract_date DESC, ct.created_at DESC
            LIMIT ?";
    $stmt = $connection->prepare($sql);
    if (!$stmt) return [];
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $contracts[] = $row;
        }
    }
    return $contracts;
}

function getContractsStats($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return ['total_amount' => 0, 'active_count' => 0, 'completed_count' => 0];
    }
    $stats = [];
    $result = $connection->query("SELECT SUM(amount) as total_amount FROM contracts");
    $row = $result->fetch_assoc();
    $stats['total_amount'] = $row['total_amount'] ?? 0;
    
    $result = $connection->query("SELECT COUNT(*) as active_count FROM contracts WHERE status = 'active'");
    $row = $result->fetch_assoc();
    $stats['active_count'] = $row['active_count'] ?? 0;
    
    $result = $connection->query("SELECT COUNT(*) as completed_count FROM contracts WHERE status = 'completed'");
    $row = $result->fetch_assoc();
    $stats['completed_count'] = $row['completed_count'] ?? 0;
    
    return $stats;
}

function getPropertiesList($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return [];
    }
    $properties = [];
    $result = $connection->query("SELECT id, title, address, price FROM properties WHERE status = 'available' ORDER BY title");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $properties[] = $row;
        }
    }
    return $properties;
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С ЛОКАЛЬНОЙ БД (ТАБЛИЦЫ)
// ============================================

function getLocalStats($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении статистики локальной БД", "ERROR", "database");
        return [];
    }
    $stats = [];
    $result = $connection->query("SELECT COUNT(*) as total FROM information_schema.tables WHERE table_schema = DATABASE()");
    $stats['total_tables'] = $result->fetch_assoc()['total'];
    $result = $connection->query("SELECT SUM(data_length + index_length) / 1024 / 1024 as size_mb FROM information_schema.tables WHERE table_schema = DATABASE()");
    $row = $result->fetch_assoc();
    $stats['db_size_mb'] = round($row['size_mb'] ?? 0, 2);
    return $stats;
}

function getLocalTables($connection) {
    if (!$connection || !($connection instanceof mysqli)) {
        return [];
    }
    $tables = [];
    $result = $connection->query("SHOW TABLES");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    }
    return $tables;
}

function createLocalTable($connection, $table_name) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при создании таблицы", "ERROR", "database");
        return false;
    }
    // Нельзя использовать подготовленное выражение для имени таблицы, поэтому экранируем
    $safe_table_name = $connection->real_escape_string($table_name);
    $sql = "CREATE TABLE IF NOT EXISTS `$safe_table_name` (
        id INT AUTO_INCREMENT PRIMARY KEY,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
    return $connection->query($sql);
}

function dropLocalTable($connection, $table_name) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при удалении таблицы", "ERROR", "database");
        return false;
    }
    $safe_table_name = $connection->real_escape_string($table_name);
    $sql = "DROP TABLE IF EXISTS `$safe_table_name`";
    return $connection->query($sql);
}

function getLocalTableStructure($connection, $table_name) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при получении структуры таблицы", "ERROR", "database");
        return [];
    }
    $structure = [];
    $safe_table_name = $connection->real_escape_string($table_name);
    $result = $connection->query("DESCRIBE `$safe_table_name`");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $structure[] = $row;
        }
    }
    return $structure;
}

function addColumnToLocalTable($connection, $table_name, $column_name, $column_type, $column_length = null) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при добавлении столбца", "ERROR", "database");
        return false;
    }
    $length_str = $column_length ? "($column_length)" : "";
    $safe_table_name = $connection->real_escape_string($table_name);
    $safe_column_name = $connection->real_escape_string($column_name);
    $sql = "ALTER TABLE `$safe_table_name` ADD COLUMN `$safe_column_name` $column_type$length_str";
    return $connection->query($sql);
}

function dropColumnFromLocalTable($connection, $table_name, $column_name) {
    if (!$connection || !($connection instanceof mysqli)) {
        logEvent("Неверное соединение при удалении столбца", "ERROR", "database");
        return false;
    }
    $safe_table_name = $connection->real_escape_string($table_name);
    $safe_column_name = $connection->real_escape_string($column_name);
    $sql = "ALTER TABLE `$safe_table_name` DROP COLUMN `$safe_column_name`";
    return $connection->query($sql);
}

?>