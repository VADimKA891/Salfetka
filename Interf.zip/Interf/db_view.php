<?php
/**
 * ИНСТРУМЕНТ ДЛЯ ПРОСМОТРА СТРУКТУРЫ БАЗ ДАННЫХ
 * Автор: Система управления недвижимостью PRO
 * Версия: 2.5
 * Дата создания: 2024
 * 
 * Описание: Расширенный просмотр всех таблиц в обеих базах данных
 * 
 * Функционал:
 * - Просмотр структуры всех таблиц
 * - Просмотр данных в таблицах
 * - Экспорт структуры таблиц
 */

session_start();

// Параметры для обеих баз данных
$db_global_host = "134.90.167.42:10306";
$db_global_name = "project_Raslovets";
$db_global_user = "Raslovets";
$db_global_pass = "H)GcnttO]vG2Yy5i";

$db_local_host = "localhost";
$db_local_name = "Tablica";
$db_local_user = "admin";
$db_local_pass = "admin";

// Подключения
$conn_global = null;
$conn_local = null;
$global_tables = [];
$local_tables = [];

// Подключение к глобальной БД
try {
    $conn_global = new mysqli($db_global_host, $db_global_user, $db_global_pass, $db_global_name);
    if ($conn_global->connect_error) {
        throw new Exception("Ошибка подключения к глобальной БД: " . $conn_global->connect_error);
    }
    
    // Получаем таблицы из глобальной БД
    $result = $conn_global->query("SHOW TABLES");
    while ($row = $result->fetch_array()) {
        $global_tables[] = $row[0];
    }
} catch (Exception $e) {
    $global_error = $e->getMessage();
}

// Подключение к локальной БД
try {
    $conn_local = new mysqli($db_local_host, $db_local_user, $db_local_pass, $db_local_name);
    if ($conn_local->connect_error) {
        throw new Exception("Ошибка подключения к локальной БД: " . $conn_local->connect_error);
    }
    
    // Получаем таблицы из локальной БД
    $result = $conn_local->query("SHOW TABLES");
    while ($row = $result->fetch_array()) {
        $local_tables[] = $row[0];
    }
} catch (Exception $e) {
    $local_error = $e->getMessage();
}

// Функция для получения информации о таблице
function getTableInfo($connection, $table_name) {
    $info = [];
    
    // Структура таблицы
    $structure = $connection->query("DESCRIBE $table_name");
    $info['structure'] = [];
    while ($row = $structure->fetch_assoc()) {
        $info['structure'][] = $row;
    }
    
    // Количество записей
    $result = $connection->query("SELECT COUNT(*) as count FROM $table_name");
    $info['row_count'] = $result->fetch_assoc()['count'];
    
    // Размер таблицы
    $result = $connection->query("SELECT 
        ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as size_mb
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table_name'");
    $info['size_mb'] = $result->fetch_assoc()['size_mb'];
    
    return $info;
}

// Функция для получения данных из таблицы
function getTableData($connection, $table_name, $limit = 50) {
    $data = [];
    $result = $connection->query("SELECT * FROM $table_name LIMIT $limit");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    return $data;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр баз данных - Инструмент администратора</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            min-height: 100vh;
            color: #333;
            padding: 20px;
        }
        
        .container {
            max-width: 1800px;
            margin: 0 auto;
        }
        
        .main-card {
            background: rgba(255, 255, 255, 0.97);
            backdrop-filter: blur(20px);
            border-radius: 25px;
            box-shadow: 0 25px 75px rgba(0,0,0,0.3);
            overflow: hidden;
            padding: 30px;
        }
        
        .header {
            margin-bottom: 40px;
        }
        
        .header h1 {
            font-size: 2.5rem;
            color: #333;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .header h1 i {
            color: #9d4edd;
        }
        
        .header p {
            color: #666;
            font-size: 1.1rem;
        }
        
        .db-sections {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(600px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .db-section {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            border: 2px solid transparent;
        }
        
        .db-section.global {
            border-color: #4CAF50;
        }
        
        .db-section.local {
            border-color: #FF9800;
        }
        
        .db-section h2 {
            font-size: 1.5rem;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .db-section.global h2 {
            color: #4CAF50;
            border-color: #4CAF50;
        }
        
        .db-section.local h2 {
            color: #FF9800;
            border-color: #FF9800;
        }
        
        .table-list {
            list-style: none;
            padding: 0;
        }
        
        .table-item {
            background: #f8f9fa;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 10px;
            border: 1px solid #e0e0e0;
            transition: all 0.3s;
        }
        
        .table-item:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        
        .table-name {
            font-weight: 700;
            font-size: 1.1rem;
            color: #333;
        }
        
        .table-stats {
            display: flex;
            gap: 10px;
            font-size: 0.85rem;
            color: #666;
        }
        
        .table-stats span {
            background: rgba(0,0,0,0.05);
            padding: 3px 8px;
            border-radius: 4px;
        }
        
        .table-structure {
            margin-top: 15px;
            overflow-x: auto;
        }
        
        .structure-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        
        .structure-table th {
            background: #f1f3f4;
            padding: 10px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid #ddd;
        }
        
        .structure-table td {
            padding: 8px 10px;
            border-bottom: 1px solid #eee;
        }
        
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            padding: 12px 25px;
            background: linear-gradient(135deg, #9d4edd, #7b2cbf);
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
            margin-top: 30px;
        }
        
        .back-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(157, 78, 221, 0.3);
        }
        
        .table-data {
            margin-top: 15px;
            overflow-x: auto;
        }
        
        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
        }
        
        .data-table th {
            background: #e3f2fd;
            padding: 8px;
            text-align: left;
            font-weight: 600;
        }
        
        .data-table td {
            padding: 8px;
            border-bottom: 1px solid #eee;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            border-left: 4px solid #f44336;
        }
        
        .status-indicator {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-bottom: 20px;
        }
        
        .status-connected {
            background: #d4edda;
            color: #155724;
        }
        
        .status-disconnected {
            background: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-card">
            <div class="header">
                <h1><i class="fas fa-database"></i> Инструмент просмотра баз данных</h1>
                <p>Подробный просмотр структуры и данных таблиц в обеих базах данных</p>
            </div>
            
            <div class="db-sections">
                <!-- Секция глобальной БД -->
                <div class="db-section global">
                    <h2><i class="fas fa-globe"></i> Глобальная база данных</h2>
                    
                    <?php if (!$conn_global): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-triangle"></i> 
                        Ошибка подключения к глобальной БД: <?php echo isset($global_error) ? htmlspecialchars($global_error) : 'Неизвестная ошибка'; ?>
                    </div>
                    <?php else: ?>
                    <div class="status-indicator status-connected">
                        <i class="fas fa-check-circle"></i>
                        Подключено к <?php echo htmlspecialchars($db_global_name); ?> на <?php echo htmlspecialchars($db_global_host); ?>
                    </div>
                    
                    <?php if (empty($global_tables)): ?>
                    <p style="color: #666; padding: 20px; text-align: center;">
                        <i class="fas fa-info-circle"></i> В глобальной базе данных нет таблиц
                    </p>
                    <?php else: ?>
                    <ul class="table-list">
                        <?php foreach ($global_tables as $table): ?>
                        <?php 
                            $table_info = getTableInfo($conn_global, $table);
                            $table_data = getTableData($conn_global, $table, 5);
                        ?>
                        <li class="table-item">
                            <div class="table-header">
                                <div class="table-name"><?php echo htmlspecialchars($table); ?></div>
                                <div class="table-stats">
                                    <span><i class="fas fa-columns"></i> <?php echo count($table_info['structure']); ?> столбцов</span>
                                    <span><i class="fas fa-list"></i> <?php echo $table_info['row_count']; ?> записей</span>
                                    <span><i class="fas fa-weight"></i> <?php echo $table_info['size_mb']; ?> MB</span>
                                </div>
                            </div>
                            
                            <!-- Структура таблицы -->
                            <div class="table-structure">
                                <h4 style="color: #666; margin-bottom: 10px; font-size: 0.9rem;">
                                    <i class="fas fa-code"></i> Структура таблицы:
                                </h4>
                                <table class="structure-table">
                                    <thead>
                                        <tr>
                                            <th>Поле</th>
                                            <th>Тип</th>
                                            <th>Null</th>
                                            <th>Ключ</th>
                                            <th>По умолчанию</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($table_info['structure'] as $column): ?>
                                        <tr>
                                            <td><strong><?php echo htmlspecialchars($column['Field']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($column['Type']); ?></td>
                                            <td><?php echo htmlspecialchars($column['Null']); ?></td>
                                            <td><?php echo htmlspecialchars($column['Key']); ?></td>
                                            <td><?php echo htmlspecialchars($column['Default'] ?? 'NULL'); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Пример данных -->
                            <?php if (!empty($table_data)): ?>
                            <div class="table-data">
                                <h4 style="color: #666; margin: 15px 0 10px 0; font-size: 0.9rem;">
                                    <i class="fas fa-database"></i> Пример данных (первые 5 записей):
                                </h4>
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <?php if (!empty($table_data)): ?>
                                                <?php foreach (array_keys($table_data[0]) as $column): ?>
                                                <th><?php echo htmlspecialchars($column); ?></th>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($table_data as $row): ?>
                                        <tr>
                                            <?php foreach ($row as $value): ?>
                                            <td>
                                                <?php 
                                                    if (is_string($value) && strlen($value) > 30) {
                                                        echo htmlspecialchars(mb_strimwidth($value, 0, 30, '...'));
                                                    } else {
                                                        echo htmlspecialchars($value);
                                                    }
                                                ?>
                                            </td>
                                            <?php endforeach; ?>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
                
                <!-- Секция локальной БД -->
                <div class="db-section local">
                    <h2><i class="fas fa-server"></i> Локальная база данных</h2>
                    
                    <?php if (!$conn_local): ?>
                    <div class="error-message">
                        <i class="fas fa-exclamation-triangle"></i> 
                        Ошибка подключения к локальной БД: <?php echo isset($local_error) ? htmlspecialchars($local_error) : 'Неизвестная ошибка'; ?>
                    </div>
                    <?php else: ?>
                    <div class="status-indicator status-connected">
                        <i class="fas fa-check-circle"></i>
                        Подключено к <?php echo htmlspecialchars($db_local_name); ?> на <?php echo htmlspecialchars($db_local_host); ?>
                    </div>
                    
                    <?php if (empty($local_tables)): ?>
                    <p style="color: #666; padding: 20px; text-align: center;">
                        <i class="fas fa-info-circle"></i> В локальной базе данных нет таблиц
                    </p>
                    <?php else: ?>
                    <ul class="table-list">
                        <?php foreach ($local_tables as $table): ?>
                        <?php 
                            $table_info = getTableInfo($conn_local, $table);
                            $table_data = getTableData($conn_local, $table, 5);
                        ?>
                        <li class="table-item">
                            <div class="table-header">
                                <div class="table-name"><?php echo htmlspecialchars($table); ?></div>
                                <div class="table-stats">
                                    <span><i class="fas fa-columns"></i> <?php echo count($table_info['structure']); ?> столбцов</span>
                                    <span><i class="fas fa-list"></i> <?php echo $table_info['row_count']; ?> записей</span>
                                    <span><i class="fas fa-weight"></i> <?php echo $table_info['size_mb'] ?? '0.00'; ?> MB</span>
                                </div>
                            </div>
                            
                            <!-- Структура таблицы -->
                            <div class="table-structure">
                                <h4 style="color: #666; margin-bottom: 10px; font-size: 0.9rem;">
                                    <i class="fas fa-code"></i> Структура таблицы:
                                </h4>
                                <table class="structure-table">
                                    <thead>
                                        <tr>
                                            <th>Поле</th>
                                            <th>Тип</th>
                                            <th>Null</th>
                                            <th>Ключ</th>
                                            <th>По умолчанию</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($table_info['structure'] as $column): ?>
                                        <tr>
                                            <td><strong><?php echo htmlspecialchars($column['Field']); ?></strong></td>
                                            <td><?php echo htmlspecialchars($column['Type']); ?></td>
                                            <td><?php echo htmlspecialchars($column['Null']); ?></td>
                                            <td><?php echo htmlspecialchars($column['Key']); ?></td>
                                            <td><?php echo htmlspecialchars($column['Default'] ?? 'NULL'); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            
                            <!-- Пример данных -->
                            <?php if (!empty($table_data)): ?>
                            <div class="table-data">
                                <h4 style="color: #666; margin: 15px 0 10px 0; font-size: 0.9rem;">
                                    <i class="fas fa-database"></i> Пример данных (первые 5 записей):
                                </h4>
                                <table class="data-table">
                                    <thead>
                                        <tr>
                                            <?php if (!empty($table_data)): ?>
                                                <?php foreach (array_keys($table_data[0]) as $column): ?>
                                                <th><?php echo htmlspecialchars($column); ?></th>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($table_data as $row): ?>
                                        <tr>
                                            <?php foreach ($row as $value): ?>
                                            <td>
                                                <?php 
                                                    if (is_string($value) && strlen($value) > 30) {
                                                        echo htmlspecialchars(mb_strimwidth($value, 0, 30, '...'));
                                                    } else {
                                                        echo htmlspecialchars($value);
                                                    }
                                                ?>
                                            </td>
                                            <?php endforeach; ?>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Кнопки действий -->
            <div style="display: flex; gap: 15px; margin-top: 30px; flex-wrap: wrap;">
                <a href="index.php" class="back-link">
                    <i class="fas fa-arrow-left"></i> Вернуться к интерфейсу управления
                </a>
                
                <?php if ($conn_global): ?>
                <a href="export.php?type=global" class="back-link" style="background: linear-gradient(135deg, #4CAF50, #2E7D32);">
                    <i class="fas fa-download"></i> Экспорт глобальной БД
                </a>
                <?php endif; ?>
                
                <?php if ($conn_local): ?>
                <a href="export.php?type=local" class="back-link" style="background: linear-gradient(135deg, #FF9800, #F57C00);">
                    <i class="fas fa-download"></i> Экспорт локальной БД
                </a>
                <?php endif; ?>
                
                <a href="javascript:window.print()" class="back-link" style="background: linear-gradient(135deg, #2196F3, #1976D2);">
                    <i class="fas fa-print"></i> Распечатать отчет
                </a>
            </div>
        </div>
    </div>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/js/all.min.js"></script>
</body>
</html>

<?php
// Закрытие соединений
if ($conn_global) $conn_global->close();
if ($conn_local) $conn_local->close();
?>