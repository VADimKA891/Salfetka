<?php
/**
 * ИНСТРУМЕНТ ПРОСМОТРА СТРУКТУРЫ БАЗ ДАННЫХ
 * Версия: 2.5
 * Стиль: фиолетовый glassmorphism
 */

session_start();

// Параметры глобальной БД
$db_global_host = "134.90.167.42:10306";
$db_global_name = "project_Raslovets";
$db_global_user = "Raslovets";
$db_global_pass = "H)GcnttO]vG2Yy5i";

// Параметры локальной БД
$db_local_host = "localhost";
$db_local_name = "tablica";
$db_local_user = "root";
$db_local_pass = "";

// Подключения
$conn_global = null;
$conn_local  = null;
$global_tables = [];
$local_tables  = [];

// Подключение к глобальной БД
try {
    $conn_global = new mysqli($db_global_host, $db_global_user, $db_global_pass, $db_global_name);
    if ($conn_global->connect_error) {
        throw new Exception("Ошибка подключения к глобальной БД: " . $conn_global->connect_error);
    }
    $result = $conn_global->query("SHOW TABLES");
    while ($row = $result->fetch_array()) {
        $global_tables[] = $row[0];
    }
} catch (Exception $e) {
    $global_error = $e->getMessage();
}

// Подключение к локальной БД
try {
    $conn_local = new mysqli($db_local_host, $db_local_user, $db_local_pass, $db_local_name);
    if ($conn_local->connect_error) {
        throw new Exception("Ошибка подключения к локальной БД: " . $conn_local->connect_error);
    }
    $result = $conn_local->query("SHOW TABLES");
    while ($row = $result->fetch_array()) {
        $local_tables[] = $row[0];
    }
} catch (Exception $e) {
    $local_error = $e->getMessage();
}

/**
 * Получить информацию о таблице
 */
function getTableInfo($connection, $table_name) {
    $info = [];
    $structure = $connection->query("DESCRIBE `$table_name`");
    $info['structure'] = [];
    while ($row = $structure->fetch_assoc()) {
        $info['structure'][] = $row;
    }
    $result = $connection->query("SELECT COUNT(*) as count FROM `$table_name`");
    $info['row_count'] = $result->fetch_assoc()['count'];
    $result = $connection->query("SELECT 
        ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) as size_mb
        FROM information_schema.TABLES 
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table_name'");
    $info['size_mb'] = $result->fetch_assoc()['size_mb'] ?? 0;
    return $info;
}

/**
 * Получить данные из таблицы
 */
function getTableData($connection, $table_name, $limit = 5) {
    $data = [];
    $result = $connection->query("SELECT * FROM `$table_name` LIMIT $limit");
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    return $data;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Просмотр БД – Операции с недвижимостью</title>
    <link rel="icon" type="image/jpeg" href="https://static.vecteezy.com/system/resources/previews/024/787/838/non_2x/home-icon-design-template-free-vector.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* ===== Пурпурный глясс-морфизм ===== */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at 20% 30%, #1a0b2e, #0f0719);
            min-height: 100vh;
            padding: 20px;
            color: #fff;
        }
        .container { max-width: 1800px; margin: 0 auto; }
        .main-card {
            background: rgba(255,255,255,0.1);
            backdrop-filter: blur(15px);
            -webkit-backdrop-filter: blur(15px);
            border: 1px solid rgba(255,255,255,0.2);
            border-radius: 32px;
            padding: 30px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.4);
        }
        h1, h2, h3 { color: white; }
        .db-sections {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(600px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        .db-section {
            background: rgba(255,255,255,0.08);
            backdrop-filter: blur(12px);
            border-radius: 24px;
            padding: 25px;
            border: 1px solid rgba(255,255,255,0.15);
        }
        .db-section.global { border-top: 4px solid #b983ff; }
        .db-section.local  { border-top: 4px solid #c77dff; }
        .table-item {
            background: rgba(0,0,0,0.2);
            backdrop-filter: blur(8px);
            border-radius: 20px;
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
        }
        .table-name { font-size: 1.3rem; font-weight: 600; color: #e0b3ff; }
        .table-stats span {
            background: rgba(255,255,255,0.1);
            padding: 5px 12px;
            border-radius: 30px;
            margin-left: 8px;
            font-size: 0.8rem;
        }
        .structure-table, .data-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            color: white;
        }
        .structure-table th, .data-table th {
            background: rgba(157,78,221,0.3);
            padding: 10px;
            text-align: left;
        }
        .structure-table td, .data-table td {
            padding: 8px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .back-link {
            display: inline-flex;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
            padding: 12px 28px;
            background: linear-gradient(145deg, rgba(157,78,221,0.9), rgba(106,13,173,0.9));
            border: 1px solid rgba(255,255,255,0.3);
            border-radius: 40px;
            color: white;
            text-decoration: none;
            font-weight: 600;
            transition: 0.2s;
        }
        .back-link:hover {
            background: rgba(183,110,255,0.9);
            border-color: white;
            transform: scale(1.02);
            box-shadow: 0 12px 30px rgba(157,78,221,0.5);
        }
        .error-message {
            background: rgba(244,67,54,0.2);
            backdrop-filter: blur(8px);
            border-left: 4px solid #f44336;
            padding: 15px;
            border-radius: 12px;
        }
        .status-connected {
            background: rgba(76,175,80,0.2);
            color: #b9f6ca;
            padding: 6px 16px;
            border-radius: 30px;
            border: 1px solid #4caf50;
        }
        @media (max-width: 768px) {
            .db-sections { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="main-card">
        <div class="header">
            <h1><i class="fas fa-home" style="color: #b983ff;"></i> Просмотр баз данных</h1>
            <p style="color: rgba(255,255,255,0.7);">Детальная структура и данные таблиц</p>
        </div>

        <div class="db-sections">
            <!-- Глобальная БД -->
            <div class="db-section global">
                <h2><i class="fas fa-globe"></i> Глобальная база данных</h2>
                <?php if (!$conn_global): ?>
                    <div class="error-message"><?= htmlspecialchars($global_error ?? 'Неизвестная ошибка') ?></div>
                <?php else: ?>
                    <div class="status-connected"><i class="fas fa-check-circle"></i> Подключено к <?= htmlspecialchars($db_global_name) ?></div>
                    <?php if (empty($global_tables)): ?>
                        <p style="padding: 20px; text-align: center;">Нет таблиц</p>
                    <?php else: ?>
                        <?php foreach ($global_tables as $table): 
                            $info = getTableInfo($conn_global, $table);
                            $data = getTableData($conn_global, $table);
                        ?>
                        <div class="table-item">
                            <div class="table-header">
                                <span class="table-name"><?= htmlspecialchars($table) ?></span>
                                <div class="table-stats">
                                    <span><i class="fas fa-columns"></i> <?= count($info['structure']) ?></span>
                                    <span><i class="fas fa-list"></i> <?= $info['row_count'] ?></span>
                                    <span><i class="fas fa-weight"></i> <?= $info['size_mb'] ?> MB</span>
                                </div>
                            </div>
                            <!-- структура -->
                            <h4 style="margin-top:15px;">Структура</h4>
                            <table class="structure-table">
                                <thead><tr><th>Поле</th><th>Тип</th><th>Null</th><th>Ключ</th><th>По умолч.</th></tr></thead>
                                <tbody>
                                <?php foreach ($info['structure'] as $col): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($col['Field']) ?></strong></td>
                                    <td><?= htmlspecialchars($col['Type']) ?></td>
                                    <td><?= $col['Null'] ?></td>
                                    <td><?= $col['Key'] ?></td>
                                    <td><?= htmlspecialchars($col['Default'] ?? 'NULL') ?></td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <!-- данные -->
                            <?php if (!empty($data)): ?>
                            <h4 style="margin-top:20px;">Пример данных (5)</h4>
                            <table class="data-table">
                                <thead>
                                <tr><?php foreach (array_keys($data[0]) as $col): ?><th><?= htmlspecialchars($col) ?></th><?php endforeach; ?></tr>
                                </thead>
                                <tbody>
                                <?php foreach ($data as $row): ?>
                                <tr><?php foreach ($row as $val): ?><td><?= htmlspecialchars(mb_strimwidth($val??'',0,30,'...')) ?></td><?php endforeach; ?></tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- Локальная БД -->
            <div class="db-section local">
                <h2><i class="fas fa-server"></i> Локальная база данных</h2>
                <?php if (!$conn_local): ?>
                    <div class="error-message"><?= htmlspecialchars($local_error ?? 'Неизвестная ошибка') ?></div>
                <?php else: ?>
                    <div class="status-connected"><i class="fas fa-check-circle"></i> Подключено к <?= htmlspecialchars($db_local_name) ?></div>
                    <?php if (empty($local_tables)): ?>
                        <p style="padding: 20px; text-align: center;">Нет таблиц</p>
                    <?php else: ?>
                        <?php foreach ($local_tables as $table): 
                            $info = getTableInfo($conn_local, $table);
                            $data = getTableData($conn_local, $table);
                        ?>
                        <div class="table-item">
                            <div class="table-header">
                                <span class="table-name"><?= htmlspecialchars($table) ?></span>
                                <div class="table-stats">
                                    <span><i class="fas fa-columns"></i> <?= count($info['structure']) ?></span>
                                    <span><i class="fas fa-list"></i> <?= $info['row_count'] ?></span>
                                    <span><i class="fas fa-weight"></i> <?= $info['size_mb'] ?> MB</span>
                                </div>
                            </div>
                            <h4 style="margin-top:15px;">Структура</h4>
                            <table class="structure-table">
                                <thead><tr><th>Поле</th><th>Тип</th><th>Null</th><th>Ключ</th><th>По умолч.</th></tr></thead>
                                <tbody>
                                <?php foreach ($info['structure'] as $col): ?>
                                <tr>
                                    <td><strong><?= htmlspecialchars($col['Field']) ?></strong></td>
                                    <td><?= htmlspecialchars($col['Type']) ?></td>
                                    <td><?= $col['Null'] ?></td>
                                    <td><?= $col['Key'] ?></td>
                                    <td><?= htmlspecialchars($col['Default'] ?? 'NULL') ?></td>
                                </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php if (!empty($data)): ?>
                            <h4 style="margin-top:20px;">Пример данных (5)</h4>
                            <table class="data-table">
                                <thead>
                                <tr><?php foreach (array_keys($data[0]) as $col): ?><th><?= htmlspecialchars($col) ?></th><?php endforeach; ?></tr>
                                </thead>
                                <tbody>
                                <?php foreach ($data as $row): ?>
                                <tr><?php foreach ($row as $val): ?><td><?= htmlspecialchars(mb_strimwidth($val??'',0,30,'...')) ?></td><?php endforeach; ?></tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <a href="index.php" class="back-link"><i class="fas fa-arrow-left"></i> Вернуться в систему</a>
    </div>
</div>
<?php
if ($conn_global) $conn_global->close();
if ($conn_local)  $conn_local->close();
?>
</body>
</html>