<?php
/**
 * ЭКСПОРТ ДАННЫХ ИЗ БАЗ ДАННЫХ
 * Операции с недвижимостью
 * Поддерживаемые форматы: CSV, JSON, SQL
 */

$export_type = $_GET['type'] ?? 'global';
$format      = $_GET['format'] ?? 'csv';
$table_name  = $_GET['table'] ?? 'all';

// Параметры глобальной БД
$db_global_host = "134.90.167.42:10306";
$db_global_name = "project_Raslovets";
$db_global_user = "Raslovets";
$db_global_pass = "H)GcnttO]vG2Yy5i";

// Параметры локальной БД
$db_local_host = "localhost";
$db_local_name = "tablica";
$db_local_user = "root";
$db_local_pass = "";

// Выбор БД
if ($export_type === 'global') {
    $db_host = $db_global_host;
    $db_name = $db_global_name;
    $db_user = $db_global_user;
    $db_pass = $db_global_pass;
} else {
    $db_host = $db_local_host;
    $db_name = $db_local_name;
    $db_user = $db_local_user;
    $db_pass = $db_local_pass;
}

$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

function getTables($connection) {
    $tables = [];
    $result = $connection->query("SHOW TABLES");
    while ($row = $result->fetch_array()) $tables[] = $row[0];
    return $tables;
}

function getTableData($connection, $table_name) {
    $data = [];
    $result = $connection->query("SELECT * FROM `$table_name`");
    while ($row = $result->fetch_assoc()) $data[] = $row;
    return $data;
}

function getTableStructure($connection, $table_name) {
    $structure = [];
    $result = $connection->query("DESCRIBE `$table_name`");
    while ($row = $result->fetch_assoc()) $structure[] = $row;
    return $structure;
}

function exportToCSV($connection, $tables, $table_name = 'all') {
    $filename = "export_" . date('Y-m-d_H-i-s') . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    $output = fopen('php://output', 'w');
    if ($table_name !== 'all' && in_array($table_name, $tables)) {
        $data = getTableData($connection, $table_name);
        if (!empty($data)) {
            fputcsv($output, array_keys($data[0]), ';');
            foreach ($data as $row) fputcsv($output, $row, ';');
        }
    } else {
        foreach ($tables as $table) {
            fputcsv($output, ["Таблица: $table"], ';');
            $data = getTableData($connection, $table);
            if (!empty($data)) {
                fputcsv($output, array_keys($data[0]), ';');
                foreach ($data as $row) fputcsv($output, $row, ';');
            }
            fputcsv($output, [], ';');
        }
    }
    fclose($output);
}

function exportToJSON($connection, $tables, $table_name = 'all') {
    $filename = "export_" . date('Y-m-d_H-i-s') . ".json";
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    $export = [
        'export_date' => date('Y-m-d H:i:s'),
        'database'    => $GLOBALS['db_name'],
        'tables'      => []
    ];
    if ($table_name !== 'all' && in_array($table_name, $tables)) {
        $export['tables'][$table_name] = [
            'structure' => getTableStructure($connection, $table_name),
            'data'      => getTableData($connection, $table_name)
        ];
    } else {
        foreach ($tables as $table) {
            $export['tables'][$table] = [
                'structure' => getTableStructure($connection, $table),
                'data'      => getTableData($connection, $table)
            ];
        }
    }
    echo json_encode($export, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

function exportToSQL($connection, $tables, $table_name = 'all') {
    $filename = "export_" . date('Y-m-d_H-i-s') . ".sql";
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    echo "-- Экспорт БД: " . $GLOBALS['db_name'] . "\n";
    echo "-- Дата: " . date('Y-m-d H:i:s') . "\n\n";
    if ($table_name !== 'all' && in_array($table_name, $tables)) {
        $tables = [$table_name];
    }
    foreach ($tables as $table) {
        echo "-- Структура: $table\n";
        $structure = getTableStructure($connection, $table);
        echo "CREATE TABLE IF NOT EXISTS `$table` (\n";
        $cols = [];
        foreach ($structure as $col) {
            $def = "  `{$col['Field']}` {$col['Type']}";
            if ($col['Null'] == 'NO') $def .= " NOT NULL";
            if ($col['Default'] !== null) $def .= " DEFAULT '" . $connection->real_escape_string($col['Default']) . "'";
            if ($col['Extra']) $def .= " {$col['Extra']}";
            $cols[] = $def;
        }
        echo implode(",\n", $cols) . "\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n\n";
        $data = getTableData($connection, $table);
        if (!empty($data)) {
            echo "-- Данные: $table\n";
            foreach ($data as $row) {
                $vals = array_map(function($v) use ($connection) {
                    return "'" . $connection->real_escape_string($v) . "'";
                }, array_values($row));
                echo "INSERT INTO `$table` VALUES (" . implode(', ', $vals) . ");\n";
            }
            echo "\n";
        }
    }
}

$tables = getTables($conn);
switch ($format) {
    case 'json': exportToJSON($conn, $tables, $table_name); break;
    case 'sql':  exportToSQL($conn, $tables, $table_name); break;
    default:     exportToCSV($conn, $tables, $table_name); break;
}
$conn->close();