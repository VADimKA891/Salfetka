<?php
/**
 * ФАЙЛ ДЛЯ ЭКСПОРТА ДАННЫХ ИЗ БАЗ ДАННЫХ
 * Автор: Система управления недвижимостью PRO
 * Версия: 2.0
 * Дата создания: 2024
 * 
 * Описание: Экспорт данных в форматах CSV, JSON и SQL
 * 
 * Поддерживаемые операции:
 * - Экспорт всей базы данных
 * - Экспорт отдельных таблиц
 * - Экспорт в разных форматах
 */

// Определяем тип экспорта
$export_type = $_GET['type'] ?? 'global'; // global или local
$format = $_GET['format'] ?? 'csv'; // csv, json или sql
$table_name = $_GET['table'] ?? 'all'; // имя таблицы или 'all'

// Параметры подключения
$db_global_host = "134.90.167.42:10306";
$db_global_name = "project_Raslovets";
$db_global_user = "Raslovets";
$db_global_pass = "H)GcnttO]vG2Yy5i";

$db_local_host = "localhost";
$db_local_name = "Tablica";
$db_local_user = "admin";
$db_local_pass = "admin";

// Выбираем нужную базу данных
if ($export_type === 'global') {
    $db_host = $db_global_host;
    $db_name = $db_global_name;
    $db_user = $db_global_user;
    $db_pass = $db_global_pass;
} else {
    $db_host = $db_local_host;
    $db_name = $db_local_name;
    $db_user = $db_local_user;
    $db_pass = $db_local_pass;
}

// Подключение к базе данных
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

// Функция для получения списка таблиц
function getTables($connection) {
    $tables = [];
    $result = $connection->query("SHOW TABLES");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_array()) {
            $tables[] = $row[0];
        }
    }
    
    return $tables;
}

// Функция для получения данных таблицы
function getTableData($connection, $table_name) {
    $data = [];
    $result = $connection->query("SELECT * FROM $table_name");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    return $data;
}

// Функция для получения структуры таблицы
function getTableStructure($connection, $table_name) {
    $structure = [];
    $result = $connection->query("DESCRIBE $table_name");
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $structure[] = $row;
        }
    }
    
    return $structure;
}

// Функция для экспорта в CSV
function exportToCSV($connection, $tables, $table_name = 'all') {
    $filename = "export_" . date('Y-m-d_H-i-s') . ".csv";
    
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    $output = fopen('php://output', 'w');
    
    if ($table_name !== 'all' && in_array($table_name, $tables)) {
        // Экспорт одной таблицы
        $data = getTableData($connection, $table_name);
        
        if (!empty($data)) {
            // Заголовки CSV
            fputcsv($output, array_keys($data[0]), ';');
            
            // Данные
            foreach ($data as $row) {
                fputcsv($output, $row, ';');
            }
        }
    } else {
        // Экспорт всех таблиц
        foreach ($tables as $table) {
            fputcsv($output, ["Таблица: $table"], ';');
            
            $data = getTableData($connection, $table);
            
            if (!empty($data)) {
                fputcsv($output, array_keys($data[0]), ';');
                
                foreach ($data as $row) {
                    fputcsv($output, $row, ';');
                }
            }
            
            fputcsv($output, [], ';'); // Пустая строка между таблицами
        }
    }
    
    fclose($output);
}

// Функция для экспорта в JSON
function exportToJSON($connection, $tables, $table_name = 'all') {
    $filename = "export_" . date('Y-m-d_H-i-s') . ".json";
    
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    $export_data = [
        'export_date' => date('Y-m-d H:i:s'),
        'database' => $GLOBALS['db_name'],
        'tables' => []
    ];
    
    if ($table_name !== 'all' && in_array($table_name, $tables)) {
        // Экспорт одной таблицы
        $export_data['tables'][$table_name] = [
            'structure' => getTableStructure($connection, $table_name),
            'data' => getTableData($connection, $table_name)
        ];
    } else {
        // Экспорт всех таблиц
        foreach ($tables as $table) {
            $export_data['tables'][$table] = [
                'structure' => getTableStructure($connection, $table),
                'data' => getTableData($connection, $table)
            ];
        }
    }
    
    echo json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}

// Функция для экспорта в SQL
function exportToSQL($connection, $tables, $table_name = 'all') {
    $filename = "export_" . date('Y-m-d_H-i-s') . ".sql";
    
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    
    echo "-- Экспорт базы данных: " . $GLOBALS['db_name'] . "\n";
    echo "-- Дата экспорта: " . date('Y-m-d H:i:s') . "\n";
    echo "-- Экспортировано таблиц: " . count($tables) . "\n\n";
    
    if ($table_name !== 'all' && in_array($table_name, $tables)) {
        $tables = [$table_name];
    }
    
    foreach ($tables as $table) {
        echo "-- Структура таблицы: $table\n";
        
        // Получаем структуру таблицы
        $structure = getTableStructure($connection, $table);
        
        echo "CREATE TABLE IF NOT EXISTS `$table` (\n";
        $columns = [];
        foreach ($structure as $column) {
            $column_def = "  `{$column['Field']}` {$column['Type']}";
            if ($column['Null'] == 'NO') {
                $column_def .= " NOT NULL";
            }
            if ($column['Default'] !== null) {
                $column_def .= " DEFAULT '{$column['Default']}'";
            }
            if ($column['Extra']) {
                $column_def .= " {$column['Extra']}";
            }
            $columns[] = $column_def;
        }
        echo implode(",\n", $columns) . "\n";
        echo ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;\n\n";
        
        // Получаем данные таблицы
        $data = getTableData($connection, $table);
        
        if (!empty($data)) {
            echo "-- Данные таблицы: $table\n";
            foreach ($data as $row) {
                $columns = array_map(function($col) use ($connection) {
                    return "'" . $connection->real_escape_string($col) . "'";
                }, array_values($row));
                
                echo "INSERT INTO `$table` VALUES (" . implode(', ', $columns) . ");\n";
            }
            echo "\n";
        }
    }
}

// Получаем список таблиц
$tables = getTables($conn);

// Выполняем экспорт в выбранном формате
switch ($format) {
    case 'json':
        exportToJSON($conn, $tables, $table_name);
        break;
    case 'sql':
        exportToSQL($conn, $tables, $table_name);
        break;
    case 'csv':
    default:
        exportToCSV($conn, $tables, $table_name);
        break;
}

// Закрываем соединение
$conn->close();
?>