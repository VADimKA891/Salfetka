<?php
/**
 * ОБРАБОТЧИК ЗАПРОСОВ
 * Двойная база данных - Глобальная + Локальная
 */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Обработка добавления клиента
    if (isset($_POST['action']) && $_POST['action'] === 'add_client' && $conn_global) {
        $data = [
            'full_name' => trim($_POST['full_name'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'budget' => floatval($_POST['budget'] ?? 0),
            'preferences' => trim($_POST['preferences'] ?? ''),
            'status' => $_POST['status'] ?? 'active',
            'is_vip' => isset($_POST['is_vip']) ? 1 : 0
        ];
        
        if (addClient($conn_global, $data)) {
            $_SESSION['flash_message'] = "Клиент успешно добавлен";
            $_SESSION['flash_type'] = 'success';
        } else {
            $_SESSION['flash_message'] = "Ошибка при добавлении клиента";
            $_SESSION['flash_type'] = 'error';
        }
        
        header("Location: ?tab=clients");
        exit;
    }
    
    // Обработка создания таблицы
    if (isset($_POST['action']) && $_POST['action'] === 'create_table' && $conn_local) {
        $table_name = trim($_POST['table_name'] ?? '');
        
        if (!empty($table_name)) {
            if (createLocalTable($conn_local, $table_name)) {
                $_SESSION['flash_message'] = "Таблица '$table_name' успешно создана";
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = "Ошибка при создании таблицы";
                $_SESSION['flash_type'] = 'error';
            }
            
            header("Location: ?tab=tables");
            exit;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Обработка удаления клиента
    if (isset($_GET['delete_client']) && $conn_global) {
        $client_id = intval($_GET['delete_client']);
        
        if ($client_id > 0) {
            if (deleteClient($conn_global, $client_id)) {
                $_SESSION['flash_message'] = "Клиент успешно удален";
                $_SESSION['flash_type'] = 'success';
            } else {
                $_SESSION['flash_message'] = "Ошибка при удалении клиента";
                $_SESSION['flash_type'] = 'error';
            }
            
            header("Location: ?tab=clients");
            exit;
        }
    }
    
    // Обработка удаления таблицы
    if (isset($_GET['delete_table']) && $conn_local) {
        $table_name = $_GET['delete_table'];
        
        if (dropLocalTable($conn_local, $table_name)) {
            $_SESSION['flash_message'] = "Таблица успешно удалена";
            $_SESSION['flash_type'] = 'success';
        } else {
            $_SESSION['flash_message'] = "Ошибка при удалении таблицы";
            $_SESSION['flash_type'] = 'error';
        }
        
        header("Location: ?tab=tables");
        exit;
    }
}
?>