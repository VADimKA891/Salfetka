#!/usr/bin/env python3
"""
АВТОМАТИЗИРОВАННОЕ ТЕСТИРОВАНИЕ НА PYTHON
Двойная база данных - Глобальная + Локальная
Версия: 3.0
"""

import os
import sys
import json
import time
import datetime
import subprocess
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import logging

# Настройка логирования
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('test_results.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class RealEstateTestSystem:
    """Система автоматизированного тестирования недвижимости"""
    
    def __init__(self, headless=False):
        """Инициализация тестовой системы"""
        self.base_url = "http://localhost/realestate"
        self.results = []
        self.screenshots_dir = "test_screenshots"
        self.reports_dir = "test_reports"
        
        # Создание директорий
        os.makedirs(self.screenshots_dir, exist_ok=True)
        os.makedirs(self.reports_dir, exist_ok=True)
        
        # Настройка Chrome
        chrome_options = Options()
        if headless:
            chrome_options.add_argument("--headless")
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--window-size=1920,1080")
        chrome_options.add_argument("--start-maximized")
        
        try:
            # Автоматическое определение драйвера
            service = Service()
            self.driver = webdriver.Chrome(service=service, options=chrome_options)
            self.wait = WebDriverWait(self.driver, 10)
            self.driver.implicitly_wait(5)
            logger.info("WebDriver успешно инициализирован")
        except Exception as e:
            logger.error(f"Ошибка инициализации WebDriver: {e}")
            raise
    
    def take_screenshot(self, test_name):
        """Сделать скриншот"""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.screenshots_dir}/{test_name}_{timestamp}.png"
        self.driver.save_screenshot(filename)
        logger.info(f"Скриншот сохранен: {filename}")
        return filename
    
    def log_test_result(self, test_name, status, message=""):
        """Записать результат теста"""
        result = {
            "test": test_name,
            "status": status,
            "message": message,
            "timestamp": datetime.datetime.now().isoformat()
        }
        self.results.append(result)
        
        if status == "passed":
            logger.info(f"✓ Тест '{test_name}' пройден: {message}")
        else:
            logger.error(f"✗ Тест '{test_name}' провален: {message}")
    
    def wait_for_element(self, selector, timeout=10):
        """Ожидание элемента"""
        try:
            element = self.wait.until(
                EC.presence_of_element_located((By.CSS_SELECTOR, selector))
            )
            return element
        except TimeoutException:
            return None
    
    def test_database_connections(self):
        """Тест подключения к базам данных"""
        try:
            self.driver.get(self.base_url)
            time.sleep(2)
            
            # Проверка статуса глобальной БД
            global_db = self.wait_for_element(".db-info.global")
            if global_db and "Подключено" in global_db.text:
                self.log_test_result(
                    "test_database_connections_global",
                    "passed",
                    "Глобальная БД подключена"
                )
            else:
                self.log_test_result(
                    "test_database_connections_global",
                    "failed",
                    "Глобальная БД не подключена"
                )
            
            # Проверка статуса локальной БД
            local_db = self.wait_for_element(".db-info.local")
            if local_db and "Подключено" in local_db.text:
                self.log_test_result(
                    "test_database_connections_local",
                    "passed",
                    "Локальная БД подключена"
                )
            else:
                self.log_test_result(
                    "test_database_connections_local",
                    "failed",
                    "Локальная БД не подключена"
                )
            
            return True
        except Exception as e:
            self.log_test_result(
                "test_database_connections",
                "failed",
                f"Ошибка: {str(e)}"
            )
            return False
    
    def test_navigation(self):
        """Тест навигации по вкладкам"""
        try:
            tabs_to_test = [
                ("dashboard", "Главная панель"),
                ("properties", "Объекты недвижимости"),
                ("clients", "Клиенты"),
                ("agents", "Агенты"),
                ("tables", "Управление таблицами"),
                ("settings", "Настройки")
            ]
            
            for tab_id, tab_name in tabs_to_test:
                try:
                    # Найти и кликнуть на вкладку
                    tab = self.driver.find_element(By.CSS_SELECTOR, f'[href*="tab={tab_id}"]')
                    tab.click()
                    time.sleep(1)
                    
                    # Проверить, что контент вкладки отображается
                    content = self.wait_for_element(f"#{tab_id}")
                    if content and content.is_displayed():
                        self.log_test_result(
                            f"test_navigation_{tab_id}",
                            "passed",
                            f"Вкладка '{tab_name}' работает"
                        )
                    else:
                        self.log_test_result(
                            f"test_navigation_{tab_id}",
                            "failed",
                            f"Вкладка '{tab_name}' не отображается"
                        )
                except Exception as e:
                    self.log_test_result(
                        f"test_navigation_{tab_id}",
                        "failed",
                        f"Ошибка при переходе на вкладку '{tab_name}': {str(e)}"
                    )
            
            return True
        except Exception as e:
            self.log_test_result(
                "test_navigation",
                "failed",
                f"Ошибка навигации: {str(e)}"
            )
            return False
    
    def test_property_crud(self):
        """Тест CRUD операций с объектами недвижимости"""
        try:
            # Перейти на вкладку объектов
            self.driver.get(f"{self.base_url}/index.php?tab=properties")
            time.sleep(2)
            
            # 1. Добавление объекта
            add_button = self.wait_for_element('[href*="tab=add_property"]')
            if add_button:
                add_button.click()
                time.sleep(1)
                
                # Заполнить форму
                self.driver.find_element(By.NAME, "title").send_keys("Тестовая квартира")
                self.driver.find_element(By.NAME, "price").send_keys("10000000")
                self.driver.find_element(By.NAME, "area").send_keys("75.5")
                
                # Выбрать тип объекта
                select = Select(self.driver.find_element(By.NAME, "property_type"))
                select.select_by_value("apartment")
                
                # Отправить форму
                submit_button = self.driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
                submit_button.click()
                time.sleep(2)
                
                # Проверить уведомление об успехе
                notification = self.wait_for_element(".notification.success")
                if notification:
                    self.log_test_result(
                        "test_property_create",
                        "passed",
                        "Объект успешно добавлен"
                    )
                else:
                    self.log_test_result(
                        "test_property_create",
                        "failed",
                        "Не удалось добавить объект"
                    )
            
            return True
        except Exception as e:
            self.log_test_result(
                "test_property_crud",
                "failed",
                f"Ошибка CRUD операций: {str(e)}"
            )
            return False
    
    def test_tables_management(self):
        """Тест управления таблицами"""
        try:
            # Перейти на вкладку таблиц
            self.driver.get(f"{self.base_url}/index.php?tab=tables")
            time.sleep(2)
            
            # Создать таблицу через модальное окно
            create_button = self.wait_for_element('[onclick*="showCreateTableModal"]')
            if create_button:
                create_button.click()
                time.sleep(1)
                
                # Заполнить форму в модальном окне
                modal = self.wait_for_element("#createTableModal")
                if modal and modal.is_displayed():
                    table_name = f"test_table_{int(time.time())}"
                    self.driver.find_element(By.NAME, "table_name").send_keys(table_name)
                    
                    # Нажать кнопку создания
                    submit_button = modal.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
                    submit_button.click()
                    time.sleep(2)
                    
                    # Проверить уведомление
                    notification = self.wait_for_element(".notification.success")
                    if notification and "успешно создана" in notification.text:
                        self.log_test_result(
                            "test_table_creation",
                            "passed",
                            f"Таблица '{table_name}' создана"
                        )
                    else:
                        self.log_test_result(
                            "test_table_creation",
                            "failed",
                            "Не удалось создать таблицу"
                        )
            
            return True
        except Exception as e:
            self.log_test_result(
                "test_tables_management",
                "failed",
                f"Ошибка управления таблицами: {str(e)}"
            )
            return False
    
    def test_form_validation(self):
        """Тест валидации форм"""
        try:
            # Тест формы добавления объекта
            self.driver.get(f"{self.base_url}/index.php?tab=add_property")
            time.sleep(1)
            
            # Попытаться отправить пустую форму
            submit_button = self.driver.find_element(By.CSS_SELECTOR, 'button[type="submit"]')
            submit_button.click()
            time.sleep(1)
            
            # Проверить наличие сообщений об ошибках
            errors = self.driver.find_elements(By.CSS_SELECTOR, ".error-message, [required]:invalid")
            if errors:
                self.log_test_result(
                    "test_form_validation",
                    "passed",
                    "Валидация форм работает"
                )
            else:
                self.log_test_result(
                    "test_form_validation",
                    "failed",
                    "Валидация форм не работает"
                )
            
            return True
        except Exception as e:
            self.log_test_result(
                "test_form_validation",
                "failed",
                f"Ошибка валидации: {str(e)}"
            )
            return False
    
    def test_backup_functionality(self):
        """Тест резервного копирования"""
        try:
            # Перейти на вкладку резервного копирования
            self.driver.get(f"{self.base_url}/index.php?tab=backup")
            time.sleep(2)
            
            # Проверить наличие элементов
            elements_to_check = [
                ("#createGlobalBackup", "Кнопка создания бэкапа глобальной БД"),
                ("#createLocalBackup", "Кнопка создания бэкапа локальной БД"),
                (".backup-list", "Список бэкапов")
            ]
            
            all_found = True
            for selector, description in elements_to_check:
                element = self.wait_for_element(selector)
                if element:
                    logger.info(f"Найден элемент: {description}")
                else:
                    logger.warning(f"Не найден элемент: {description}")
                    all_found = False
            
            if all_found:
                self.log_test_result(
                    "test_backup_interface",
                    "passed",
                    "Интерфейс резервного копирования работает"
                )
            else:
                self.log_test_result(
                    "test_backup_interface",
                    "failed",
                    "Не все элементы интерфейса найдены"
                )
            
            return True
        except Exception as e:
            self.log_test_result(
                "test_backup_functionality",
                "failed",
                f"Ошибка тестирования резервного копирования: {str(e)}"
            )
            return False
    
    def test_performance(self):
        """Тест производительности"""
        try:
            start_time = time.time()
            
            # Загрузка главной страницы
            self.driver.get(self.base_url)
            load_time = time.time() - start_time
            
            # Проверить время загрузки
            if load_time < 5:  # Менее 5 секунд
                self.log_test_result(
                    "test_performance_load",
                    "passed",
                    f"Время загрузки: {load_time:.2f} сек"
                )
            else:
                self.log_test_result(
                    "test_performance_load",
                    "failed",
                    f"Слишком долгая загрузка: {load_time:.2f} сек"
                )
            
            # Скриншот для отчета
            self.take_screenshot("performance_test")
            
            return True
        except Exception as e:
            self.log_test_result(
                "test_performance",
                "failed",
                f"Ошибка тестирования производительности: {str(e)}"
            )
            return False
    
    def run_all_tests(self):
        """Запуск всех тестов"""
        logger.info("=" * 60)
        logger.info("ЗАПУСК АВТОМАТИЗИРОВАННЫХ ТЕСТОВ")
        logger.info("=" * 60)
        
        tests = [
            ("test_database_connections", "Тест подключений к БД"),
            ("test_navigation", "Тест навигации"),
            ("test_property_crud", "Тест CRUD операций"),
            ("test_tables_management", "Тест управления таблицами"),
            ("test_form_validation", "Тест валидации форм"),
            ("test_backup_functionality", "Тест резервного копирования"),
            ("test_performance", "Тест производительности")
        ]
        
        for test_method, test_name in tests:
            try:
                logger.info(f"\nЗапуск теста: {test_name}")
                getattr(self, test_method)()
                time.sleep(1)
            except Exception as e:
                logger.error(f"Ошибка при запуске теста {test_name}: {e}")
        
        return self.generate_report()
    
    def generate_report(self):
        """Генерация отчета"""
        report = {
            "timestamp": datetime.datetime.now().isoformat(),
            "total_tests": len(self.results),
            "passed_tests": sum(1 for r in self.results if r["status"] == "passed"),
            "failed_tests": sum(1 for r in self.results if r["status"] == "failed"),
            "success_rate": 0,
            "tests": self.results
        }
        
        if report["total_tests"] > 0:
            report["success_rate"] = (report["passed_tests"] / report["total_tests"]) * 100
        
        # Сохранение отчета в JSON
        report_file = f"{self.reports_dir}/test_report_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        # Вывод сводки
        logger.info("\n" + "=" * 60)
        logger.info("ИТОГИ ТЕСТИРОВАНИЯ")
        logger.info("=" * 60)
        logger.info(f"Всего тестов: {report['total_tests']}")
        logger.info(f"Успешных: {report['passed_tests']}")
        logger.info(f"Проваленных: {report['failed_tests']}")
        logger.info(f"Успешность: {report['success_rate']:.1f}%")
        logger.info(f"Отчет сохранен: {report_file}")
        
        return report
    
    def close(self):
        """Завершение работы"""
        if hasattr(self, 'driver'):
            self.driver.quit()
            logger.info("WebDriver закрыт")

def main():
    """Основная функция"""
    print("""
    ███████╗███████╗██╗     ███████╗███╗   ██╗██╗██╗   ██╗███╗   ███╗
    ██╔════╝██╔════╝██║     ██╔════╝████╗  ██║██║██║   ██║████╗ ████║
    ███████╗█████╗  ██║     █████╗  ██╔██╗ ██║██║██║   ██║██╔████╔██║
    ╚════██║██╔══╝  ██║     ██╔══╝  ██║╚██╗██║██║██║   ██║██║╚██╔╝██║
    ███████║███████╗███████╗███████╗██║ ╚████║██║╚██████╔╝██║ ╚═╝ ██║
    ╚══════╝╚══════╝╚══════╝╚══════╝╚═╝  ╚═══╝╚═╝ ╚═════╝ ╚═╝     ╚═╝
    
    Автоматизированное тестирование системы управления недвижимостью
    Двойная база данных - Глобальная + Локальная
    """)
    
    # Проверка зависимостей
    try:
        import selenium
        print("✓ Selenium установлен")
    except ImportError:
        print("✗ Selenium не установлен. Установите: pip install selenium")
        return
    
    try:
        # Запуск тестов
        test_system = RealEstateTestSystem(headless=False)  # headless=True для сервера
        
        print("\nНастройки тестирования:")
        print(f"URL: {test_system.base_url}")
        print(f"Режим: {'Headless' if False else 'С браузером'}")
        print(f"Скриншоты: {test_system.screenshots_dir}")
        print(f"Отчеты: {test_system.reports_dir}")
        
        input("\nНажмите Enter для запуска тестов...")
        
        report = test_system.run_all_tests()
        
        # Закрыть браузер
        test_system.close()
        
        # Вывод результатов
        print("\n" + "="*60)
        print("РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ:")
        print("="*60)
        
        for test in report["tests"]:
            status_icon = "✓" if test["status"] == "passed" else "✗"
            print(f"{status_icon} {test['test']}: {test['message']}")
        
        print(f"\nВсего тестов: {report['total_tests']}")
        print(f"Успешно: {report['passed_tests']}")
        print(f"Провалено: {report['failed_tests']}")
        print(f"Успешность: {report['success_rate']:.1f}%")
        
        if report["failed_tests"] > 0:
            print("\n⚠️ Некоторые тесты провалены. Проверьте логи и скриншоты.")
        
    except KeyboardInterrupt:
        print("\n\nТестирование прервано пользователем")
    except Exception as e:
        print(f"\n❌ Ошибка при запуске тестов: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()