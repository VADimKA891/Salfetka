#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import os
import sys
import time
import json
import datetime
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from selenium.common.exceptions import TimeoutException, NoSuchElementException

# ---------- НАСТРОЙКИ ----------
# Автоматически определяем URL (папка, где лежит скрипт)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_URL = f"file://{BASE_DIR}/index.php"  # Для локального теста без сервера
# Если сайт работает через веб-сервер, раскомментируйте и укажите свой адрес:
# BASE_URL = "http://localhost/realestate/index.php"   # <-- ИЗМЕНИТЕ ПРИ НЕОБХОДИМОСТИ
# ---------------------------------

class RealEstateTestSystem:
    def __init__(self, headless=False):
        options = webdriver.ChromeOptions()
        if headless:
            options.add_argument("--headless")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=1920,1080")
        self.driver = webdriver.Chrome(options=options)
        self.wait = WebDriverWait(self.driver, 10)
        self.results = []
        self.screenshots_dir = "test_screenshots"
        os.makedirs(self.screenshots_dir, exist_ok=True)
    
    def log(self, test_name, status, message):
        self.results.append({
            "test": test_name,
            "status": status,
            "message": message,
            "timestamp": datetime.datetime.now().isoformat()
        })
        print(f"{'✓' if status=='passed' else '✗'} {test_name}: {message}")
    
    def take_screenshot(self, name):
        filename = f"{self.screenshots_dir}/{name}_{datetime.datetime.now():%Y%m%d_%H%M%S}.png"
        self.driver.save_screenshot(filename)
        print(f"📸 Скриншот: {filename}")
    
    def wait_for_element(self, css, timeout=10):
        try:
            return WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, css))
            )
        except TimeoutException:
            return None
    
    def test_home_page_loads(self):
        """Проверка загрузки главной страницы"""
        try:
            self.driver.get(BASE_URL)
            time.sleep(2)
            self.take_screenshot("home_page")
            # Проверяем заголовок
            if "Операции с недвижимостью" in self.driver.title:
                self.log("home_page_load", "passed", "Страница загружена")
                return True
            else:
                self.log("home_page_load", "failed", "Неверный заголовок")
                return False
        except Exception as e:
            self.log("home_page_load", "failed", f"Исключение: {e}")
            return False
    
    def test_navigation_tabs(self):
        """Проверка переключения вкладок"""
        try:
            tabs = [
                ("dashboard", "Панель"),
                ("properties", "Объекты"),
                ("clients", "Клиенты"),
                ("agents", "Агенты"),
                ("contracts", "Договоры")
            ]
            for tab_id, tab_name in tabs:
                try:
                    # Ищем ссылку на вкладку
                    link = self.driver.find_element(By.CSS_SELECTOR, f'a[href*="tab={tab_id}"]')
                    link.click()
                    time.sleep(1)
                    content = self.wait_for_element(f'#{tab_id}')
                    if content and content.is_displayed():
                        self.log(f"nav_{tab_id}", "passed", f"Вкладка {tab_name} открыта")
                    else:
                        self.log(f"nav_{tab_id}", "failed", f"Контент {tab_name} не отображается")
                except Exception as e:
                    self.log(f"nav_{tab_id}", "failed", f"Ошибка: {e}")
            return True
        except Exception as e:
            self.log("navigation", "failed", str(e))
            return False
    
    def test_database_indicators(self):
        """Проверка наличия индикаторов БД (статистика)"""
        try:
            # Проверяем, что есть карточки статистики (признак работы с БД)
            stat_cards = self.driver.find_elements(By.CSS_SELECTOR, ".stat-card")
            if len(stat_cards) >= 4:
                self.log("db_indicators", "passed", f"Найдено {len(stat_cards)} карточек статистики")
                return True
            else:
                self.log("db_indicators", "failed", "Карточки статистики не найдены")
                return False
        except Exception as e:
            self.log("db_indicators", "failed", str(e))
            return False
    
    def run_all(self):
        print("\n🚀 Запуск тестов...")
        self.test_home_page_loads()
        self.test_navigation_tabs()
        self.test_database_indicators()
        self.driver.quit()
        return self.results

if __name__ == "__main__":
    tester = RealEstateTestSystem(headless=False)
    results = tester.run_all()
    
    print("\n" + "="*50)
    print("ИТОГИ")
    print("="*50)
    passed = sum(1 for r in results if r['status'] == 'passed')
    failed = sum(1 for r in results if r['status'] == 'failed')
    print(f"✅ Успешно: {passed}")
    print(f"❌ Провалено: {failed}")
    print(f"Всего: {len(results)}")
    
    # Сохраняем отчёт в JSON
    report_file = f"test_report_{datetime.datetime.now():%Y%m%d_%H%M%S}.json"
    with open(report_file, "w", encoding="utf-8") as f:
        json.dump({"results": results, "passed": passed, "failed": failed}, f, ensure_ascii=False, indent=2)
    print(f"📄 Отчёт сохранён: {report_file}")
    
    sys.exit(1 if failed > 0 else 0)